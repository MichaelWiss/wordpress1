# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------


#
# Delete any existing table `wp_ai_contact`
#

DROP TABLE IF EXISTS `wp_ai_contact`;


#
# Table structure of table `wp_ai_contact`
#

CREATE TABLE `wp_ai_contact` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `contact_date` date DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_ai_contact (6 records)
#
 
INSERT INTO `wp_ai_contact` VALUES (1, 'Michael', 'michael.wiss@gmail.com', '2013-11-08') ; 
INSERT INTO `wp_ai_contact` VALUES (2, 'michael', 'michael.wiss1@facebook.com', '2013-11-08') ; 
INSERT INTO `wp_ai_contact` VALUES (3, 'Michael', 'm@gmail.com', '2013-11-08') ; 
INSERT INTO `wp_ai_contact` VALUES (4, 'michael.wiss%40gmail.com', 'michael.wiss@gmail.com', '2013-11-08') ; 
INSERT INTO `wp_ai_contact` VALUES (5, 'michael.wiss%40gmail.com', 'michael.wiss@gmail.com', '2013-11-08') ; 
INSERT INTO `wp_ai_contact` VALUES (6, 'michael.wiss%40gmail.com', 'michael.wiss@gmail.com', '2013-11-08') ;
#
# End of data contents of table wp_ai_contact
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------


#
# Delete any existing table `wp_cntctfrm_field`
#

DROP TABLE IF EXISTS `wp_cntctfrm_field`;


#
# Table structure of table `wp_cntctfrm_field`
#

CREATE TABLE `wp_cntctfrm_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_cntctfrm_field (13 records)
#
 
INSERT INTO `wp_cntctfrm_field` VALUES (1, 'name') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (2, 'email') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (3, 'subject') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (4, 'message') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (5, 'address') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (6, 'phone') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (7, 'attachment') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (8, 'attachment_explanations') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (9, 'send_copy') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (10, 'sent_from') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (11, 'date_time') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (12, 'coming_from') ; 
INSERT INTO `wp_cntctfrm_field` VALUES (13, 'user_agent') ;
#
# End of data contents of table wp_cntctfrm_field
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (2 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2013-09-18 23:45:13', '2013-09-18 23:45:13', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (2, 53, 'admin', 'michael.wiss@gmail.com', '', '::1', '2013-10-06 02:33:11', '2013-10-06 02:33:11', 'nice campaign', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.69 Safari/537.36', '', 0, 1) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_customcontactforms_field_options`
#

DROP TABLE IF EXISTS `wp_customcontactforms_field_options`;


#
# Table structure of table `wp_customcontactforms_field_options`
#

CREATE TABLE `wp_customcontactforms_field_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_slug` varchar(100) NOT NULL,
  `option_label` varchar(200) NOT NULL,
  `option_value` varchar(100) NOT NULL,
  `option_dead` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_customcontactforms_field_options (0 records)
#

#
# End of data contents of table wp_customcontactforms_field_options
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------


#
# Delete any existing table `wp_customcontactforms_fields`
#

DROP TABLE IF EXISTS `wp_customcontactforms_fields`;


#
# Table structure of table `wp_customcontactforms_fields`
#

CREATE TABLE `wp_customcontactforms_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_slug` varchar(50) NOT NULL,
  `field_label` mediumtext NOT NULL,
  `field_type` varchar(25) NOT NULL,
  `field_value` mediumtext NOT NULL,
  `field_maxlength` int(5) NOT NULL DEFAULT '0',
  `user_field` int(1) NOT NULL DEFAULT '1',
  `field_instructions` mediumtext NOT NULL,
  `field_options` mediumtext NOT NULL,
  `field_required` int(1) NOT NULL DEFAULT '0',
  `field_class` varchar(50) NOT NULL,
  `field_error` varchar(300) NOT NULL,
  `field_max_upload_size` int(11) NOT NULL,
  `field_allowed_file_extensions` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_customcontactforms_fields (9 records)
#
 
INSERT INTO `wp_customcontactforms_fields` VALUES (1, 'captcha', 'Type the numbers.', 'Text', '', 100, 0, 'Type the numbers displayed in the image above.', '', 0, '', '', 0, '') ; 
INSERT INTO `wp_customcontactforms_fields` VALUES (2, 'recaptcha', '', 'Text', '', 100, 0, 'Type the numbers displayed in the image above.', '', 0, '', '', 0, '') ; 
INSERT INTO `wp_customcontactforms_fields` VALUES (3, 'usaStates', 'Select a State', 'Dropdown', '', 0, 0, '', '', 0, '', '', 0, '') ; 
INSERT INTO `wp_customcontactforms_fields` VALUES (4, 'allCountries', 'Select a Country', 'Dropdown', '', 0, 0, '', '', 0, '', '', 0, '') ; 
INSERT INTO `wp_customcontactforms_fields` VALUES (5, 'ishuman', 'Check if you are human.', 'Checkbox', '1', 0, 0, 'This helps us prevent spam.', '', 0, '', '', 0, '') ; 
INSERT INTO `wp_customcontactforms_fields` VALUES (6, 'fixedEmail', 'Your Email', 'Text', '', 100, 0, 'Please enter your email address.', '', 1, '', '', 0, '') ; 
INSERT INTO `wp_customcontactforms_fields` VALUES (7, 'fixedWebsite', 'Your Website', 'Text', '', 200, 0, 'Please enter your website.', '', 1, '', '', 0, '') ; 
INSERT INTO `wp_customcontactforms_fields` VALUES (8, 'emailSubject', 'Email Subject', 'Text', '', 200, 0, 'Please enter a subject for the email.', '', 1, '', '', 0, '') ; 
INSERT INTO `wp_customcontactforms_fields` VALUES (9, 'resetButton', '', 'Reset', 'Reset Form', 0, 0, '', '', 0, '', '', 0, '') ;
#
# End of data contents of table wp_customcontactforms_fields
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------


#
# Delete any existing table `wp_customcontactforms_forms`
#

DROP TABLE IF EXISTS `wp_customcontactforms_forms`;


#
# Table structure of table `wp_customcontactforms_forms`
#

CREATE TABLE `wp_customcontactforms_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_slug` varchar(100) NOT NULL,
  `form_title` varchar(200) NOT NULL,
  `form_action` mediumtext NOT NULL,
  `form_method` varchar(4) NOT NULL,
  `form_fields` mediumtext NOT NULL,
  `submit_button_text` varchar(200) NOT NULL,
  `custom_code` mediumtext NOT NULL,
  `form_style` int(10) NOT NULL DEFAULT '0',
  `form_email` mediumtext NOT NULL,
  `form_success_message` mediumtext NOT NULL,
  `form_thank_you_page` varchar(200) NOT NULL,
  `form_success_title` varchar(150) NOT NULL DEFAULT 'Form Success!',
  `form_access` mediumtext NOT NULL,
  `form_email_subject` varchar(250) NOT NULL,
  `form_email_name` varchar(100) NOT NULL,
  `form_pages` varchar(400) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_customcontactforms_forms (1 records)
#
 
INSERT INTO `wp_customcontactforms_forms` VALUES (1, 'first', '', '', '', '', 'E mail', '', 0, 'michael.wiss@gmail.com', 'Thank you', '', '', 'a:11:{i:0;s:13:"Administrator";i:1;s:6:"Editor";i:2;s:6:"Author";i:3;s:11:"Contributor";i:4;s:10:"Subscriber";i:5;s:12:"Shop Manager";i:6;s:15:"Shop Accountant";i:7;s:11:"Shop Worker";i:8;s:11:"Shop Vendor";i:9;s:20:"Campaign Contributor";i:10;s:19:"Non-Registered User";}', 'michael.wiss@gmail.com', 'michael.wiss@gmail.com', '') ;
#
# End of data contents of table wp_customcontactforms_forms
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------


#
# Delete any existing table `wp_customcontactforms_styles`
#

DROP TABLE IF EXISTS `wp_customcontactforms_styles`;


#
# Table structure of table `wp_customcontactforms_styles`
#

CREATE TABLE `wp_customcontactforms_styles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `style_slug` varchar(30) NOT NULL,
  `input_width` varchar(10) NOT NULL DEFAULT '200px',
  `textarea_width` varchar(10) NOT NULL DEFAULT '200px',
  `textarea_height` varchar(10) NOT NULL DEFAULT '100px',
  `form_borderwidth` varchar(10) NOT NULL DEFAULT '0px',
  `label_width` varchar(10) NOT NULL DEFAULT '200px',
  `form_width` varchar(10) NOT NULL DEFAULT '100%',
  `submit_width` varchar(10) NOT NULL DEFAULT 'auto',
  `submit_height` varchar(10) NOT NULL DEFAULT '40px',
  `label_fontsize` varchar(10) NOT NULL DEFAULT '1em',
  `title_fontsize` varchar(10) NOT NULL DEFAULT '1.2em',
  `field_fontsize` varchar(10) NOT NULL DEFAULT '1.3em',
  `submit_fontsize` varchar(10) NOT NULL DEFAULT '1.1em',
  `field_bordercolor` varchar(10) NOT NULL DEFAULT '999999',
  `form_borderstyle` varchar(30) NOT NULL DEFAULT 'none',
  `form_bordercolor` varchar(20) NOT NULL DEFAULT '',
  `field_fontcolor` varchar(20) NOT NULL DEFAULT '333333',
  `label_fontcolor` varchar(20) NOT NULL DEFAULT '333333',
  `title_fontcolor` varchar(20) NOT NULL DEFAULT '333333',
  `submit_fontcolor` varchar(20) NOT NULL DEFAULT '333333',
  `form_fontfamily` varchar(150) NOT NULL DEFAULT 'Tahoma, Verdana, Arial',
  `field_backgroundcolor` varchar(20) NOT NULL DEFAULT 'f5f5f5',
  `field_borderstyle` varchar(20) NOT NULL DEFAULT 'solid',
  `form_padding` varchar(20) NOT NULL DEFAULT '8px',
  `form_margin` varchar(20) NOT NULL DEFAULT '7px',
  `title_margin` varchar(20) NOT NULL DEFAULT '4px',
  `label_margin` varchar(20) NOT NULL DEFAULT '6px',
  `textarea_backgroundcolor` varchar(20) NOT NULL DEFAULT 'f5f5f5',
  `success_popover_bordercolor` varchar(20) NOT NULL DEFAULT 'efefef',
  `dropdown_width` varchar(20) NOT NULL DEFAULT 'auto',
  `success_popover_fontsize` varchar(20) NOT NULL DEFAULT '12px',
  `submit_background` varchar(200) NOT NULL,
  `submit_background_repeat` varchar(25) NOT NULL,
  `success_popover_title_fontsize` varchar(20) NOT NULL DEFAULT '1.3em',
  `success_popover_height` varchar(20) NOT NULL DEFAULT '200px',
  `success_popover_fontcolor` varchar(20) NOT NULL DEFAULT '333333',
  `success_popover_title_fontcolor` varchar(20) NOT NULL DEFAULT '333333',
  `form_backgroundcolor` varchar(20) NOT NULL DEFAULT 'ffffff',
  `field_borderround` varchar(20) NOT NULL DEFAULT '6px',
  `tooltip_backgroundcolor` varchar(20) NOT NULL DEFAULT '000000',
  `tooltip_fontsize` varchar(20) NOT NULL DEFAULT '12px',
  `tooltip_fontcolor` varchar(20) NOT NULL DEFAULT 'ffffff',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_customcontactforms_styles (0 records)
#

#
# End of data contents of table wp_customcontactforms_styles
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------


#
# Delete any existing table `wp_customcontactforms_user_data`
#

DROP TABLE IF EXISTS `wp_customcontactforms_user_data`;


#
# Table structure of table `wp_customcontactforms_user_data`
#

CREATE TABLE `wp_customcontactforms_user_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_time` int(11) NOT NULL DEFAULT '0',
  `data_formid` int(11) NOT NULL,
  `data_formpage` varchar(250) NOT NULL,
  `data_value` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_customcontactforms_user_data (1 records)
#
 
INSERT INTO `wp_customcontactforms_user_data` VALUES (1, 1383942766, 1, 'localhost/wordpress1/?codekitCB=405630216.151150', '') ;
#
# End of data contents of table wp_customcontactforms_user_data
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1609 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (213 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/wordpress1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'MICHAEL WISS', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', 'Just another WordPress site', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'michael.wiss@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'closed', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'closed', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'comment_moderation', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (35, 'active_plugins', 'a:5:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:23:"revslider/revslider.php";i:3;s:41:"search-and-replace/search-and-replace.php";i:4;s:31:"wp-google-maps/wpGoogleMaps.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'home', 'http://localhost/wordpress1', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'recently_edited', 'a:2:{i:0;s:70:"/Applications/MAMP/htdocs/wordpress1/wp-content/themes/Roots/style.css";i:2;s:0:"";}', 'no') ; 
INSERT INTO `wp_options` VALUES (44, 'template', 'Roots', 'yes') ; 
INSERT INTO `wp_options` VALUES (45, 'stylesheet', 'Roots', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (48, 'comment_registration', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'db_version', '26691', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'uploads_use_yearmonth_folders', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'upload_path', 'media', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_avatars', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'close_comments_for_old_posts', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'page_comments', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'uninstall_plugins', 'a:4:{s:47:"interactive-world-map/freeworldcontinentmap.php";s:41:"free_world_continent_map_plugin_uninstall";s:36:"contact-form-plugin/contact_form.php";s:23:"cntctfrm_delete_options";s:54:"responsive-contact-form/ai-responsive-contact-form.php";s:25:"ai_contact_form_uninstall";s:67:"comprehensive-google-map-plugin/comprehensive-google-map-plugin.php";s:22:"cgmp_on_uninstall_hook";}', 'no') ; 
INSERT INTO `wp_options` VALUES (86, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'page_on_front', '4', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'initial_db_version', '24448', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'wp_user_roles', 'a:10:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:119:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:13:"edit_campaign";b:1;s:17:"view_shop_reports";b:1;s:24:"view_shop_sensitive_data";b:1;s:19:"export_shop_reports";b:1;s:21:"manage_shop_discounts";b:1;s:20:"manage_shop_settings";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:17:"edit_shop_payment";b:1;s:17:"read_shop_payment";b:1;s:19:"delete_shop_payment";b:1;s:18:"edit_shop_payments";b:1;s:25:"edit_others_shop_payments";b:1;s:21:"publish_shop_payments";b:1;s:26:"read_private_shop_payments";b:1;s:20:"delete_shop_payments";b:1;s:28:"delete_private_shop_payments";b:1;s:30:"delete_published_shop_payments";b:1;s:27:"delete_others_shop_payments";b:1;s:26:"edit_private_shop_payments";b:1;s:28:"edit_published_shop_payments";b:1;s:25:"manage_shop_payment_terms";b:1;s:23:"edit_shop_payment_terms";b:1;s:25:"delete_shop_payment_terms";b:1;s:25:"assign_shop_payment_terms";b:1;s:18:"edit_shop_discount";b:1;s:18:"read_shop_discount";b:1;s:20:"delete_shop_discount";b:1;s:19:"edit_shop_discounts";b:1;s:26:"edit_others_shop_discounts";b:1;s:22:"publish_shop_discounts";b:1;s:27:"read_private_shop_discounts";b:1;s:21:"delete_shop_discounts";b:1;s:29:"delete_private_shop_discounts";b:1;s:31:"delete_published_shop_discounts";b:1;s:28:"delete_others_shop_discounts";b:1;s:27:"edit_private_shop_discounts";b:1;s:29:"edit_published_shop_discounts";b:1;s:26:"manage_shop_discount_terms";b:1;s:24:"edit_shop_discount_terms";b:1;s:26:"delete_shop_discount_terms";b:1;s:26:"assign_shop_discount_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:13:"edit_campaign";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:11:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:13:"edit_campaign";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:13:"edit_campaign";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:3:{s:4:"read";b:1;s:7:"level_0";b:1;s:13:"edit_campaign";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:84:{s:4:"read";b:1;s:10:"edit_posts";b:1;s:12:"delete_posts";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:19:"delete_others_pages";b:1;s:19:"delete_others_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:17:"edit_others_pages";b:1;s:17:"edit_others_posts";b:1;s:10:"edit_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:20:"edit_published_pages";b:1;s:20:"edit_published_posts";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:13:"publish_pages";b:1;s:13:"publish_posts";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:17:"view_shop_reports";b:1;s:24:"view_shop_sensitive_data";b:1;s:19:"export_shop_reports";b:1;s:20:"manage_shop_settings";b:1;s:21:"manage_shop_discounts";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:17:"edit_shop_payment";b:1;s:17:"read_shop_payment";b:1;s:19:"delete_shop_payment";b:1;s:18:"edit_shop_payments";b:1;s:25:"edit_others_shop_payments";b:1;s:21:"publish_shop_payments";b:1;s:26:"read_private_shop_payments";b:1;s:20:"delete_shop_payments";b:1;s:28:"delete_private_shop_payments";b:1;s:30:"delete_published_shop_payments";b:1;s:27:"delete_others_shop_payments";b:1;s:26:"edit_private_shop_payments";b:1;s:28:"edit_published_shop_payments";b:1;s:25:"manage_shop_payment_terms";b:1;s:23:"edit_shop_payment_terms";b:1;s:25:"delete_shop_payment_terms";b:1;s:25:"assign_shop_payment_terms";b:1;s:18:"edit_shop_discount";b:1;s:18:"read_shop_discount";b:1;s:20:"delete_shop_discount";b:1;s:19:"edit_shop_discounts";b:1;s:26:"edit_others_shop_discounts";b:1;s:22:"publish_shop_discounts";b:1;s:27:"read_private_shop_discounts";b:1;s:21:"delete_shop_discounts";b:1;s:29:"delete_private_shop_discounts";b:1;s:31:"delete_published_shop_discounts";b:1;s:28:"delete_others_shop_discounts";b:1;s:27:"edit_private_shop_discounts";b:1;s:29:"edit_published_shop_discounts";b:1;s:26:"manage_shop_discount_terms";b:1;s:24:"edit_shop_discount_terms";b:1;s:26:"delete_shop_discount_terms";b:1;s:26:"assign_shop_discount_terms";b:1;}}s:15:"shop_accountant";a:2:{s:4:"name";s:15:"Shop Accountant";s:12:"capabilities";a:8:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"delete_posts";b:0;s:13:"edit_products";b:1;s:21:"read_private_products";b:1;s:17:"view_shop_reports";b:1;s:19:"export_shop_reports";b:1;s:18:"edit_shop_payments";b:1;}}s:11:"shop_worker";a:2:{s:4:"name";s:11:"Shop Worker";s:12:"capabilities";a:55:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"upload_files";b:1;s:12:"delete_posts";b:0;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:17:"edit_shop_payment";b:1;s:17:"read_shop_payment";b:1;s:19:"delete_shop_payment";b:1;s:18:"edit_shop_payments";b:1;s:25:"edit_others_shop_payments";b:1;s:21:"publish_shop_payments";b:1;s:26:"read_private_shop_payments";b:1;s:20:"delete_shop_payments";b:1;s:28:"delete_private_shop_payments";b:1;s:30:"delete_published_shop_payments";b:1;s:27:"delete_others_shop_payments";b:1;s:26:"edit_private_shop_payments";b:1;s:28:"edit_published_shop_payments";b:1;s:25:"manage_shop_payment_terms";b:1;s:23:"edit_shop_payment_terms";b:1;s:25:"delete_shop_payment_terms";b:1;s:25:"assign_shop_payment_terms";b:1;s:18:"edit_shop_discount";b:1;s:18:"read_shop_discount";b:1;s:20:"delete_shop_discount";b:1;s:19:"edit_shop_discounts";b:1;s:26:"edit_others_shop_discounts";b:1;s:22:"publish_shop_discounts";b:1;s:27:"read_private_shop_discounts";b:1;s:21:"delete_shop_discounts";b:1;s:29:"delete_private_shop_discounts";b:1;s:31:"delete_published_shop_discounts";b:1;s:28:"delete_others_shop_discounts";b:1;s:27:"edit_private_shop_discounts";b:1;s:29:"edit_published_shop_discounts";b:1;s:26:"manage_shop_discount_terms";b:1;s:24:"edit_shop_discount_terms";b:1;s:26:"delete_shop_discount_terms";b:1;s:26:"assign_shop_discount_terms";b:1;}}s:11:"shop_vendor";a:2:{s:4:"name";s:11:"Shop Vendor";s:12:"capabilities";a:11:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"upload_files";b:1;s:12:"delete_posts";b:0;s:12:"edit_product";b:1;s:13:"edit_products";b:1;s:14:"delete_product";b:1;s:15:"delete_products";b:1;s:16:"publish_products";b:1;s:23:"edit_published_products";b:1;s:20:"assign_product_terms";b:1;}}s:20:"campaign_contributor";a:2:{s:4:"name";s:20:"Campaign Contributor";s:12:"capabilities";a:18:{s:4:"read";b:1;s:12:"upload_files";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:10:"edit_posts";b:1;s:13:"publish_posts";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"edit_published_posts";b:1;s:7:"level_1";b:1;s:16:"submit_campaigns";b:1;s:12:"edit_product";b:1;s:13:"edit_products";b:1;s:14:"delete_product";b:1;s:15:"delete_products";b:1;s:16:"publish_products";b:1;s:23:"edit_published_products";b:1;s:20:"assign_product_terms";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"sidebar-footer";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'cron', 'a:8:{i:1388513440;a:1:{s:34:"atcf_check_for_completed_campaigns";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1388519400;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1388530800;a:1:{s:19:"hmbkp_schedule_hook";a:2:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1388533518;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1388533525;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1388534833;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1388542255;a:2:{s:14:"edd_daily_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:29:"wp_session_garbage_collection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, '_transient_random_seed', '7a5d7ae4fa32b414539cfb739ed2aa6c', 'yes') ; 
INSERT INTO `wp_options` VALUES (104, 'auth_key', '9S:BswpGBBIqA%(e( abhy4.Ln2)/XK4o@VT`SPa=CWceRO!vU/fDil#58,uL^(g', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'auth_salt', 'pbZ!H-55*x%`y30A)Ww=q1WjbEFECMw$Rd@TBmHR0WtNq.p`_X@Oj&Zafynx$u7Z', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'logged_in_key', ' %rUz>Gk~1+IdqQV%F*]okZJ{-:X7)XbnOqMq|$>^(tt&*rF%f^*Km:;P.>]v1)Q', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'logged_in_salt', '^_&.}p?3zV/Ao> a7ZF87d3brq9ILNm^WI]fFKoqxr>IPrn!To&<7Z5$AB#hkwj[', 'yes') ; 
INSERT INTO `wp_options` VALUES (110, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1388512684;s:7:"checked";a:1:{s:5:"Roots";s:5:"6.5.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (111, 'nonce_key', '=X45&zTR9zGoLP#fS.?dLf6oia{{%/Z=R|;}&x?q26WC`+6/P}X6%#SF!#GJ?sq2', 'yes') ; 
INSERT INTO `wp_options` VALUES (112, 'nonce_salt', 'D)wDLNlp{tP6T.WDb&cZr>%(^zOlP5c10@.Q8~]s^7  A[c*eP-p22]Xsg<# ts2', 'yes') ; 
INSERT INTO `wp_options` VALUES (115, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:27:"http://localhost/wordpress1";s:4:"link";s:103:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://localhost/wordpress1/";s:3:"url";s:136:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://localhost/wordpress1/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (139, '_transient_timeout_plugin_slugs', '1388599295', 'no') ; 
INSERT INTO `wp_options` VALUES (140, '_transient_plugin_slugs', 'a:5:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:23:"revslider/revslider.php";i:3;s:41:"search-and-replace/search-and-replace.php";i:4;s:31:"wp-google-maps/wpGoogleMaps.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (152, 'current_theme', 'Roots', 'yes') ; 
INSERT INTO `wp_options` VALUES (153, 'theme_mods_Roots', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:18:"primary_navigation";i:2;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (154, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (161, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:1:{i:0;i:2;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (165, 'theme_mods_twentythirteen', 'a:2:{s:18:"nav_menu_locations";a:1:{s:7:"primary";i:2;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1381026047;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (168, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (173, 'theme_mods_wpbootstrap', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1379562538;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (182, 'theme_mods_eddiemachado-bones-405349e', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1379638248;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:8:"sidebar1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (311, 'ftp_credentials', 'a:3:{s:8:"hostname";s:7:"NewSite";s:8:"username";s:5:"admin";s:15:"connection_type";s:3:"ftp";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (332, 'theme_mods_upBootstrap3WP-master', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1380859566;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (341, 'pfund_options', 'a:27:{s:18:"allow_registration";b:1;s:13:"campaign_slug";s:4:"give";s:10:"cause_slug";s:6:"causes";s:15:"currency_symbol";s:1:"$";s:11:"date_format";s:5:"m/d/y";s:14:"login_required";b:1;s:9:"mailchimp";b:0;s:7:"use_ssl";b:0;s:23:"authorize_net_test_mode";b:0;s:11:"submit_role";a:5:{i:0;s:13:"administrator";i:1;s:6:"editor";i:2;s:6:"author";i:3;s:11:"contributor";i:4;s:10:"subscriber";}s:6:"fields";a:6:{s:10:"camp-title";a:6:{s:5:"label";s:5:"Title";s:4:"desc";s:26:"The title of your campaign";s:4:"type";s:10:"camp_title";s:4:"data";s:0:"";s:8:"required";s:4:"true";s:9:"sortorder";i:0;}s:13:"camp-location";a:6:{s:5:"label";s:3:"URL";s:4:"desc";s:25:"The URL for your campaign";s:4:"type";s:13:"camp_location";s:4:"data";s:0:"";s:8:"required";s:4:"true";s:9:"sortorder";i:1;}s:8:"end-date";a:5:{s:5:"label";s:8:"End Date";s:4:"desc";s:27:"The date your campaign ends";s:4:"type";s:8:"end_date";s:4:"data";s:0:"";s:9:"sortorder";i:2;}s:9:"gift-goal";a:6:{s:5:"label";s:4:"Goal";s:4:"desc";s:28:"The amount you hope to raise";s:4:"type";s:9:"user_goal";s:4:"data";s:0:"";s:8:"required";s:4:"true";s:9:"sortorder";i:3;}s:10:"gift-tally";a:6:{s:5:"label";s:12:"Total Raised";s:4:"desc";s:24:"Total donations received";s:4:"type";s:10:"gift_tally";s:4:"data";s:0:"";s:8:"required";s:4:"true";s:9:"sortorder";i:4;}s:11:"giver-tally";a:6:{s:5:"label";s:11:"Giver Tally";s:4:"desc";s:45:"The number of unique givers for the campaign.";s:4:"type";s:11:"giver_tally";s:4:"data";s:0:"";s:8:"required";s:4:"true";s:9:"sortorder";i:5;}}s:10:"cause_root";i:33;s:13:"campaign_root";i:34;s:14:"paypal_sandbox";b:1;s:16:"campaign_listing";b:1;s:13:"cause_listing";b:1;s:17:"paypal_donate_btn";s:420:"<form action="" method="post"><input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!" onclick="alert(\'This is a test button.  Please view the readme to setup your PayPal donate button.\');return false;"><img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1"></form>";s:7:"version";s:7:"0.7.9.1";s:17:"approval_required";b:0;s:16:"paypal_pdt_token";s:0:"";s:26:"authorize_net_api_login_id";s:0:"";s:29:"authorize_net_transaction_key";s:0:"";s:26:"authorize_net_product_name";s:0:"";s:10:"mc_api_key";s:0:"";s:19:"mc_email_publish_id";s:0:"";s:18:"mc_email_donate_id";s:0:"";s:16:"mc_email_goal_id";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (352, 'atcf_installed', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (366, 'edd_settings', 'a:22:{s:13:"purchase_page";s:2:"47";s:12:"success_page";s:2:"49";s:12:"failure_page";s:2:"51";s:8:"gateways";a:1:{s:6:"paypal";s:1:"1";}s:15:"default_gateway";s:6:"paypal";s:14:"accepted_cards";a:5:{s:10:"mastercard";s:10:"Mastercard";s:4:"visa";s:4:"Visa";s:15:"americanexpress";s:16:"American Express";s:8:"discover";s:8:"Discover";s:6:"paypal";s:6:"PayPal";}s:12:"paypal_email";s:0:"";s:17:"paypal_page_style";s:0:"";s:11:"submit_page";s:2:"55";s:8:"currency";s:3:"USD";s:17:"currency_position";s:6:"before";s:19:"thousands_separator";s:1:",";s:17:"decimal_separator";s:1:".";s:24:"atcf_campaign_length_min";s:2:"14";s:24:"atcf_campaign_length_max";s:2:"42";s:12:"profile_page";s:2:"70";s:10:"login_page";s:2:"70";s:13:"register_page";s:2:"70";s:27:"atcf_settings_custom_pledge";s:1:"1";s:19:"atcf_campaign_types";a:1:{s:8:"donation";s:77:"Donation — <small>Funds will be collected automatically as pledged.</small>";}s:8:"faq_page";s:1:"0";s:19:"submit_success_page";s:1:"0";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (368, 'edd_version', '1.8', 'yes') ; 
INSERT INTO `wp_options` VALUES (375, '_transient_edd_cache_excluded_uris', 'a:4:{i:0;s:4:"p=47";i:1;s:4:"p=49";i:2;s:9:"/checkout";i:3;s:22:"/purchase-confirmation";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (421, 'download_category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (424, 'roots_theme_activation_options', 'a:5:{s:17:"create_front_page";b:0;s:26:"change_permalink_structure";b:0;s:21:"change_uploads_folder";b:0;s:23:"create_navigation_menus";b:0;s:31:"add_pages_to_primary_navigation";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (618, 'freeworldcontinenthtml5map_map_data', '{
    "st1": {
   	 	"id": 1,
		"name": "NORTH AMERICA",
		"shortname": "",
		"link": "",
		"comment": "",
		"image": ""
	},
    "st2": {
    	"id": 2,
		"name": "CENTRAL AMERICA",
		"shortname": "",
		"link": "",
		"comment": "",
		"image": ""
	},
    "st3": {
		"id": 3,
		"name": "SOUTH AMERICA",
		"shortname": "",
		"link": "",
		"comment": "",
		"image": ""
	},
    "st4":{
    	"id": 4,
		"name": "AFRICA",
		"shortname": "",
		"link": "",
		"comment": "",
		"image": ""
	},
    "st5":{
    	"id": 5,
		"name": "EUROPE",
		"shortname": "",
		"link": "",
		"comment": "",
		"image": ""
	},
    "st6":{
    	"id": 6,
		"name": "ASIA",
		"shortname": "",
		"link": "",
		"comment": "",
		"image": ""
	},
    "st7":{
    	"id": 7,
		"name": "OCEANIA",
		"shortname": "",
		"link": "",
		"comment": "",
		"image": ""
	}
}', 'yes') ; 
INSERT INTO `wp_options` VALUES (619, 'freeworldcontinenthtml5map_nameColor', '#000000', 'yes') ; 
INSERT INTO `wp_options` VALUES (620, 'freeworldcontinenthtml5map_nameFontSize', '12px', 'yes') ; 
INSERT INTO `wp_options` VALUES (621, 'freeworldcontinenthtml5map_state_info_1', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (622, 'freeworldcontinenthtml5map_state_info_2', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (623, 'freeworldcontinenthtml5map_state_info_3', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (624, 'freeworldcontinenthtml5map_state_info_4', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (625, 'freeworldcontinenthtml5map_state_info_5', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (626, 'freeworldcontinenthtml5map_state_info_6', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (627, 'freeworldcontinenthtml5map_state_info_7', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (852, '_wp_session_expires_e68aed75dac375cf2a1da81a1a72bd95', '1382731468', 'yes') ; 
INSERT INTO `wp_options` VALUES (950, 'wpcf7', 'a:1:{s:7:"version";s:3:"3.6";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (957, 'wp_smtp_options', 'a:9:{s:4:"from";s:22:"michael.wiss@gmail.com";s:8:"fromname";s:7:"Michael";s:4:"host";s:14:"smtp.gmail.com";s:10:"smtpsecure";s:3:"tls";s:4:"port";s:3:"567";s:8:"smtpauth";s:3:"yes";s:8:"username";s:22:"michael.wiss@gmail.com";s:8:"password";s:9:"knish1972";s:10:"deactivate";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (959, 'fs_contact_global', 'a:11:{s:12:"fscf_version";s:6:"4.0.16";s:7:"donated";s:5:"false";s:18:"vcita_auto_install";s:5:"false";s:13:"vcita_dismiss";s:5:"false";s:17:"vcita_initialized";s:5:"false";s:22:"vcita_show_disable_msg";s:5:"false";s:10:"vcita_site";s:13:"www.vcita.com";s:19:"enable_php_sessions";s:5:"false";s:19:"num_standard_fields";s:1:"4";s:12:"max_form_num";s:1:"2";s:9:"form_list";a:2:{i:1;s:8:"New Form";i:2;s:6:"Form 2";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (960, 'fs_contact_form1', 'a:165:{s:9:"form_name";s:8:"New Form";s:7:"welcome";s:41:"<p>Comments or questions are welcome.</p>";s:15:"after_form_note";s:0:"";s:8:"email_to";s:32:"Webmaster,michael.wiss@gmail.com";s:17:"php_mailer_enable";s:9:"wordpress";s:10:"email_from";s:0:"";s:19:"email_from_enforced";s:5:"false";s:14:"email_reply_to";s:0:"";s:9:"email_bcc";s:0:"";s:13:"email_subject";s:21:"Michael Wiss Contact:";s:18:"email_subject_list";s:0:"";s:11:"name_format";s:4:"name";s:21:"preserve_space_enable";s:5:"false";s:12:"double_email";s:5:"false";s:16:"name_case_enable";s:5:"false";s:18:"sender_info_enable";s:4:"true";s:14:"domain_protect";s:4:"true";s:20:"domain_protect_names";s:0:"";s:13:"anchor_enable";s:4:"true";s:15:"email_check_dns";s:5:"false";s:10:"email_html";s:5:"false";s:18:"email_inline_label";s:5:"false";s:16:"email_hide_empty";s:5:"false";s:17:"print_form_enable";s:5:"false";s:22:"email_keep_attachments";s:5:"false";s:15:"akismet_disable";s:5:"false";s:19:"akismet_send_anyway";s:4:"true";s:14:"captcha_enable";s:4:"true";s:13:"captcha_small";s:5:"false";s:12:"captcha_perm";s:5:"false";s:18:"captcha_perm_level";s:4:"read";s:15:"honeypot_enable";s:5:"false";s:15:"redirect_enable";s:4:"true";s:16:"redirect_seconds";i:3;s:12:"redirect_url";s:27:"http://localhost/wordpress1";s:14:"redirect_query";s:5:"false";s:15:"redirect_ignore";s:0:"";s:15:"redirect_rename";s:0:"";s:12:"redirect_add";s:0:"";s:18:"redirect_email_off";s:5:"false";s:11:"silent_send";s:3:"off";s:10:"silent_url";s:0:"";s:13:"silent_ignore";s:0:"";s:13:"silent_rename";s:0:"";s:10:"silent_add";s:0:"";s:16:"silent_email_off";s:5:"false";s:13:"export_ignore";s:0:"";s:13:"export_rename";s:0:"";s:10:"export_add";s:0:"";s:16:"export_email_off";s:5:"false";s:11:"date_format";s:10:"mm/dd/yyyy";s:13:"cal_start_day";s:1:"0";s:11:"time_format";s:2:"12";s:12:"attach_types";s:33:"doc,docx,pdf,txt,gif,jpg,jpeg,png";s:11:"attach_size";s:3:"1mb";s:19:"textarea_html_allow";s:5:"false";s:17:"enable_areyousure";s:5:"false";s:19:"auto_respond_enable";s:5:"false";s:17:"auto_respond_html";s:5:"false";s:22:"auto_respond_from_name";s:12:"Michael Wiss";s:23:"auto_respond_from_email";s:22:"michael.wiss@gmail.com";s:21:"auto_respond_reply_to";s:22:"michael.wiss@gmail.com";s:20:"auto_respond_subject";s:0:"";s:20:"auto_respond_message";s:0:"";s:26:"req_field_indicator_enable";s:4:"true";s:22:"req_field_label_enable";s:4:"true";s:19:"req_field_indicator";s:1:"*";s:13:"border_enable";s:5:"false";s:14:"external_style";s:5:"false";s:13:"aria_required";s:5:"false";s:16:"auto_fill_enable";s:4:"true";s:15:"form_attributes";s:0:"";s:17:"submit_attributes";s:0:"";s:12:"title_border";s:12:"Contact Form";s:10:"title_dept";s:0:"";s:12:"title_select";s:0:"";s:10:"title_name";s:0:"";s:11:"title_fname";s:0:"";s:11:"title_mname";s:0:"";s:12:"title_miname";s:0:"";s:11:"title_lname";s:0:"";s:11:"title_email";s:0:"";s:12:"title_email2";s:0:"";s:10:"title_subj";s:0:"";s:10:"title_mess";s:0:"";s:10:"title_capt";s:0:"";s:12:"title_submit";s:0:"";s:11:"title_reset";s:0:"";s:16:"title_areyousure";s:0:"";s:17:"text_message_sent";s:0:"";s:17:"text_print_button";s:0:"";s:16:"tooltip_required";s:0:"";s:15:"tooltip_captcha";s:0:"";s:15:"tooltip_refresh";s:0:"";s:17:"tooltip_filetypes";s:0:"";s:16:"tooltip_filesize";s:0:"";s:12:"enable_reset";s:5:"false";s:18:"enable_credit_link";s:5:"false";s:20:"error_contact_select";s:0:"";s:10:"error_name";s:0:"";s:11:"error_email";s:0:"";s:17:"error_email_check";s:0:"";s:12:"error_email2";s:0:"";s:9:"error_url";s:0:"";s:10:"error_date";s:0:"";s:10:"error_time";s:0:"";s:12:"error_maxlen";s:0:"";s:11:"error_field";s:0:"";s:13:"error_subject";s:0:"";s:12:"error_select";s:0:"";s:11:"error_input";s:0:"";s:19:"error_captcha_blank";s:0:"";s:19:"error_captcha_wrong";s:0:"";s:13:"error_correct";s:0:"";s:13:"error_spambot";s:0:"";s:6:"fields";a:4:{i:0;a:20:{s:8:"standard";s:1:"1";s:7:"options";s:0:"";s:7:"default";s:0:"";s:6:"inline";s:5:"false";s:3:"req";s:4:"true";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";s:5:"label";s:5:"Name:";s:4:"slug";s:9:"full_name";s:4:"type";s:4:"text";s:7:"max_len";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";}i:1;a:20:{s:8:"standard";s:1:"2";s:7:"options";s:0:"";s:7:"default";s:0:"";s:6:"inline";s:5:"false";s:3:"req";s:4:"true";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";s:5:"label";s:6:"Email:";s:4:"slug";s:5:"email";s:4:"type";s:4:"text";s:7:"max_len";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";}i:2;a:20:{s:8:"standard";s:1:"3";s:7:"options";s:0:"";s:7:"default";s:0:"";s:6:"inline";s:5:"false";s:3:"req";s:4:"true";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";s:5:"label";s:8:"Subject:";s:4:"slug";s:7:"subject";s:4:"type";s:4:"text";s:7:"max_len";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";}i:3;a:20:{s:8:"standard";s:1:"4";s:7:"options";s:0:"";s:7:"default";s:0:"";s:6:"inline";s:5:"false";s:3:"req";s:4:"true";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";s:5:"label";s:8:"Message:";s:4:"slug";s:7:"message";s:4:"type";s:8:"textarea";s:7:"max_len";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";}}s:23:"vcita_scheduling_button";s:5:"false";s:29:"vcita_scheduling_button_label";s:23:"Schedule an Appointment";s:14:"vcita_approved";s:5:"false";s:9:"vcita_uid";s:0:"";s:11:"vcita_email";s:0:"";s:15:"vcita_email_new";s:22:"michael.wiss@gmail.com";s:19:"vcita_confirm_token";s:0:"";s:20:"vcita_confirm_tokens";s:0:"";s:17:"vcita_initialized";s:5:"false";s:10:"vcita_link";s:5:"false";s:16:"vcita_first_name";s:0:"";s:15:"vcita_last_name";s:0:"";s:26:"vcita_scheduling_link_text";s:68:"Click above to schedule an appointment using vCita Online Scheduling";s:10:"form_style";s:27:"width:99%; max-width:555px;";s:14:"left_box_style";s:39:"float:left; width:55%; max-width:270px;";s:15:"right_box_style";s:24:"float:left; width:235px;";s:11:"clear_style";s:11:"clear:both;";s:16:"field_left_style";s:70:"clear:left; float:left; width:99%; max-width:550px; margin-right:10px;";s:21:"field_prefollow_style";s:70:"clear:left; float:left; width:99%; max-width:250px; margin-right:10px;";s:18:"field_follow_style";s:58:"float:left; padding-left:10px; width:99%; max-width:250px;";s:11:"title_style";s:33:"text-align:left; padding-top:5px;";s:15:"field_div_style";s:16:"text-align:left;";s:20:"captcha_div_style_sm";s:42:"width:175px; height:50px; padding-top:2px;";s:19:"captcha_div_style_m";s:42:"width:250px; height:65px; padding-top:2px;";s:19:"captcha_image_style";s:72:"border-style:none; margin:0; padding:0px; padding-right:5px; float:left;";s:26:"captcha_reload_image_style";s:64:"border-style:none; margin:0; padding:0px; vertical-align:bottom;";s:16:"submit_div_style";s:46:"text-align:left; clear:both; padding-top:15px;";s:12:"border_style";s:65:"border:1px solid black; width:99%; max-width:550px; padding:10px;";s:14:"required_style";s:16:"text-align:left;";s:19:"required_text_style";s:16:"text-align:left;";s:10:"hint_style";s:38:"font-size:x-small; font-weight:normal;";s:11:"error_style";s:27:"text-align:left; color:red;";s:14:"redirect_style";s:16:"text-align:left;";s:14:"fieldset_style";s:65:"border:1px solid black; width:97%; max-width:500px; padding:10px;";s:11:"label_style";s:16:"text-align:left;";s:18:"option_label_style";s:15:"display:inline;";s:11:"field_style";s:54:"text-align:left; margin:0; width:99%; max-width:250px;";s:19:"captcha_input_style";s:38:"text-align:left; margin:0; width:50px;";s:14:"textarea_style";s:68:"text-align:left; margin:0; width:99%; max-width:250px; height:120px;";s:12:"select_style";s:16:"text-align:left;";s:14:"checkbox_style";s:11:"width:13px;";s:11:"radio_style";s:11:"width:13px;";s:17:"placeholder_style";s:27:"opacity:0.6; color:#333333;";s:12:"button_style";s:25:"cursor:pointer; margin:0;";s:11:"reset_style";s:25:"cursor:pointer; margin:0;";s:18:"vcita_button_style";s:156:"text-decoration:none; display:block; text-align:center; background:linear-gradient(to bottom, #ed6a31 0%, #e55627 100%); color:#fff !important; padding:8px;";s:22:"vcita_div_button_style";s:63:"border-left:1px dashed #ccc; margin-top:25px; padding:8px 20px;";s:16:"powered_by_style";s:74:"font-size:x-small; font-weight:normal; padding-top:5px; text-align:center;";s:19:"ex_fields_after_msg";s:5:"false";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (976, 'cntctfrm_options', 'a:53:{s:19:"cntctfrm_user_email";s:5:"admin";s:21:"cntctfrm_custom_email";s:22:"michael.wiss@gmail.com";s:21:"cntctfrm_select_email";s:6:"custom";s:19:"cntctfrm_from_email";s:4:"user";s:26:"cntctfrm_custom_from_email";s:0:"";s:26:"cntctfrm_additions_options";s:1:"1";s:19:"cntctfrm_attachment";i:0;s:32:"cntctfrm_attachment_explanations";i:0;s:18:"cntctfrm_send_copy";i:0;s:19:"cntctfrm_from_field";s:12:"Michael Wiss";s:26:"cntctfrm_select_from_field";s:6:"custom";s:28:"cntctfrm_display_phone_field";i:0;s:30:"cntctfrm_display_address_field";i:0;s:28:"cntctfrm_required_name_field";i:1;s:31:"cntctfrm_required_address_field";i:0;s:29:"cntctfrm_required_email_field";i:1;s:29:"cntctfrm_required_phone_field";i:0;s:31:"cntctfrm_required_subject_field";i:1;s:31:"cntctfrm_required_message_field";i:1;s:24:"cntctfrm_required_symbol";i:1;s:25:"cntctfrm_display_add_info";i:1;s:26:"cntctfrm_display_sent_from";i:1;s:26:"cntctfrm_display_date_time";i:1;s:20:"cntctfrm_mail_method";s:7:"wp-mail";s:28:"cntctfrm_display_coming_from";i:1;s:27:"cntctfrm_display_user_agent";i:1;s:17:"cntctfrm_language";a:0:{}s:21:"cntctfrm_change_label";i:0;s:19:"cntctfrm_name_label";a:1:{s:2:"en";s:5:"Name:";}s:22:"cntctfrm_address_label";a:1:{s:2:"en";s:8:"Address:";}s:20:"cntctfrm_email_label";a:1:{s:2:"en";s:14:"Email Address:";}s:20:"cntctfrm_phone_label";a:1:{s:2:"en";s:13:"Phone number:";}s:22:"cntctfrm_subject_label";a:1:{s:2:"en";s:8:"Subject:";}s:22:"cntctfrm_message_label";a:1:{s:2:"en";s:8:"Message:";}s:25:"cntctfrm_attachment_label";a:1:{s:2:"en";s:11:"Attachment:";}s:24:"cntctfrm_send_copy_label";a:1:{s:2:"en";s:14:"Send me a copy";}s:21:"cntctfrm_submit_label";a:1:{s:2:"en";s:6:"Submit";}s:19:"cntctfrm_name_error";a:1:{s:2:"en";s:22:"Your name is required.";}s:22:"cntctfrm_address_error";a:1:{s:2:"en";s:20:"Address is required.";}s:20:"cntctfrm_email_error";a:1:{s:2:"en";s:34:"A valid email address is required.";}s:20:"cntctfrm_phone_error";a:1:{s:2:"en";s:25:"Phone number is required.";}s:22:"cntctfrm_subject_error";a:1:{s:2:"en";s:20:"Subject is required.";}s:22:"cntctfrm_message_error";a:1:{s:2:"en";s:25:"Message text is required.";}s:25:"cntctfrm_attachment_error";a:1:{s:2:"en";s:25:"File format is not valid.";}s:32:"cntctfrm_attachment_upload_error";a:1:{s:2:"en";s:18:"File upload error.";}s:30:"cntctfrm_attachment_move_error";a:1:{s:2:"en";s:31:"The file could not be uploaded.";}s:30:"cntctfrm_attachment_size_error";a:1:{s:2:"en";s:23:"This file is too large.";}s:22:"cntctfrm_captcha_error";a:1:{s:2:"en";s:28:"Please fill out the CAPTCHA.";}s:19:"cntctfrm_form_error";a:1:{s:2:"en";s:44:"Please make corrections below and try again.";}s:26:"cntctfrm_action_after_send";s:1:"1";s:19:"cntctfrm_thank_text";a:1:{s:2:"en";s:28:"Thank you for contacting us.";}s:21:"cntctfrm_redirect_url";s:0:"";s:29:"cntctfrm_delete_attached_file";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (979, 'customContactFormsAdminOptions', 'a:34:{s:16:"show_widget_home";i:1;s:17:"show_widget_pages";i:1;s:19:"show_widget_singles";i:1;s:22:"show_widget_categories";i:1;s:20:"show_widget_archives";i:1;s:16:"default_to_email";s:22:"michael.wiss@gmail.com";s:18:"default_from_email";s:22:"michael.wiss@gmail.com";s:17:"default_from_name";s:20:"Custom Contact Forms";s:20:"default_form_subject";s:37:"Someone Filled Out Your Contact Form!";s:21:"remember_field_values";i:0;s:22:"enable_widget_tooltips";i:1;s:13:"mail_function";s:7:"default";s:26:"form_success_message_title";s:26:"Successful Form Submission";s:20:"form_success_message";s:69:"Thank you for filling out our web form. We will get back to you ASAP.";s:13:"enable_jquery";i:1;s:9:"code_type";s:5:"XHTML";s:20:"show_install_popover";i:0;s:22:"email_form_submissions";i:1;s:23:"enable_dashboard_widget";i:1;s:10:"admin_ajax";i:1;s:9:"smtp_host";s:0:"";s:15:"smtp_encryption";s:4:"none";s:19:"smtp_authentication";i:0;s:13:"smtp_username";s:0:"";s:13:"smtp_password";s:0:"";s:9:"smtp_port";s:0:"";s:25:"default_form_error_header";s:36:"You filled out the form incorrectly.";s:28:"default_form_bad_permissions";s:56:"You don\'t have the proper permissions to view this form.";s:26:"enable_form_access_manager";i:0;s:16:"dashboard_access";i:2;s:24:"form_page_inclusion_only";i:0;s:20:"max_file_upload_size";i:10;s:20:"recaptcha_public_key";s:0:"";s:21:"recaptcha_private_key";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (984, 'ai_email_address_setting', 'michael.wiss@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (985, 'ai_subject_text', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (986, 'ai_reply_user_message', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (987, 'ai_enable_captcha', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (988, 'ai_error_setting', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (989, 'ai_visible_name', 'on', 'yes') ; 
INSERT INTO `wp_options` VALUES (990, 'ai_enable_require_name', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (991, 'ai_visible_phone', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (992, 'ai_enable_require_phone', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (993, 'ai_visible_email', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (994, 'ai_visible_subject', 'on', 'yes') ; 
INSERT INTO `wp_options` VALUES (995, 'ai_enable_require_subject', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (996, 'ai_visible_website', 'on', 'yes') ; 
INSERT INTO `wp_options` VALUES (997, 'ai_enable_require_website', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (998, 'ai_visible_comment', 'on', 'yes') ; 
INSERT INTO `wp_options` VALUES (999, 'ai_enable_require_comment', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1000, 'ai_visible_sendcopy', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1095, 'cgmp_settings_should_base_object_render', 'false', 'yes') ; 
INSERT INTO `wp_options` VALUES (1096, 'cgmp_settings_was_base_object_rendered', 'false', 'yes') ; 
INSERT INTO `wp_options` VALUES (1097, 'cgmp_published_post_markers', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1098, 'cgmp_total_published_posts', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1099, 'cgmp_published_post_ids', 'YTowOnt9', 'yes') ; 
INSERT INTO `wp_options` VALUES (1100, 'cgmp_published_page_ids', 'YTowOnt9', 'yes') ; 
INSERT INTO `wp_options` VALUES (1101, 'cgmp_purge_geomashup_cache', 'true', 'yes') ; 
INSERT INTO `wp_options` VALUES (1102, 'cgmp_geomashup_content', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1103, 'wpgmza_db_version', '5.22', 'yes') ; 
INSERT INTO `wp_options` VALUES (1104, 'wpgmza_permission', 'n', 'yes') ; 
INSERT INTO `wp_options` VALUES (1105, 'WPGMZA_SETTINGS', 'a:21:{s:24:"map_default_starting_lat";s:18:"40.643559981257546";s:24:"map_default_starting_lng";s:17:"-74.0093450268555";s:18:"map_default_height";s:3:"500";s:17:"map_default_width";s:3:"100";s:16:"map_default_zoom";i:13;s:16:"map_default_type";i:1;s:21:"map_default_alignment";i:2;s:28:"map_default_order_markers_by";i:0;s:32:"map_default_order_markers_choice";i:0;s:30:"map_default_show_user_location";i:0;s:22:"map_default_directions";i:0;s:19:"map_default_bicycle";i:0;s:19:"map_default_traffic";i:0;s:16:"map_default_dbox";i:0;s:22:"map_default_dbox_width";s:0:"";s:23:"map_default_listmarkers";i:0;s:32:"map_default_listmarkers_advanced";i:0;s:23:"map_default_filterbycat";i:0;s:18:"map_default_marker";N;s:22:"map_default_width_type";s:2:"\\%";s:23:"map_default_height_type";s:2:"px";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1310, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (1312, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:39:"https://wordpress.org/wordpress-3.8.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:39:"https://wordpress.org/wordpress-3.8.zip";s:10:"no_content";s:50:"https://wordpress.org/wordpress-3.8-no-content.zip";s:11:"new_bundled";s:51:"https://wordpress.org/wordpress-3.8-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"3.8";s:7:"version";s:3:"3.8";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1388508978;s:15:"version_checked";s:3:"3.8";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1313, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (1319, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1388512843;s:7:"checked";a:5:{s:35:"backupwordpress/backupwordpress.php";s:5:"2.3.3";s:36:"contact-form-7/wp-contact-form-7.php";s:3:"3.6";s:23:"revslider/revslider.php";s:5:"4.1.3";s:41:"search-and-replace/search-and-replace.php";s:5:"2.6.5";s:31:"wp-google-maps/wpGoogleMaps.php";s:4:"5.22";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1355, 'w3tc_request_data', '', 'no') ; 
INSERT INTO `wp_options` VALUES (1356, '_transient_timeout_w3tc.verify_plugins', '1387765020', 'no') ; 
INSERT INTO `wp_options` VALUES (1357, '_transient_w3tc.verify_plugins', '1', 'no') ; 
INSERT INTO `wp_options` VALUES (1358, '_transient_timeout_w3tc_license_status', '1387592224', 'no') ; 
INSERT INTO `wp_options` VALUES (1359, '_transient_w3tc_license_status', 'no_key', 'no') ; 
INSERT INTO `wp_options` VALUES (1360, '_transient_timeout_feed_6c78d00722dae650afc8789333d5c38e', '1387203427', 'no') ; 
INSERT INTO `wp_options` VALUES (1361, '_transient_feed_6c78d00722dae650afc8789333d5c38e', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://pipes.yahoo.com/pipes/pipe.info?_id=02f556aa2f503be89aa9d89723644f40";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:59:"The fastest and most complete WordPress performance plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://pipes.yahoo.com/pipes/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:5:{i:0;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"tombyrnes on &quot;Call to a member function using_permalinks() on a non-object&quot;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:117:"http://feedproxy.google.com/~r/W3TOTALCACHE/~3/bML-86gB1wE/call-to-a-member-function-using_permalinks-on-a-non-object";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 15 Dec 2013 17:54:23 PST";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"5001710@http://wordpress.org/support/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:774:"<p>I am consistently getting this error when my plugin code executes a section to update the post_title of a few posts/pages. If I deactivate W3 Total Cache, the error disappears. The error is triggered by a call to wp_update_posts with just the post_ID and (new) post_title as arguments.</p>
<p>In production, this code is only triggered once per month (i.e. on a change of "current" month/year). It seems a shame to have to deactivate W3TC altogether, for this occasional event. Any suggestions for a workaround would be appreciated.</p>
<p><a rel="nofollow" target="_blank" href="http://wordpress.org/plugins/w3-total-cache/">http://wordpress.org/plugins/w3-total-cache/</a>
</p><img src="http://feeds.feedburner.com/~r/W3TOTALCACHE/~4/bML-86gB1wE" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:106:"http://wordpress.org/support/topic/call-to-a-member-function-using_permalinks-on-a-non-object#post-5001710";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"roosterling on &quot;Page cache not working properly&quot;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://feedproxy.google.com/~r/W3TOTALCACHE/~3/JBQxAmXJ7vE/page-cache-not-working-properly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 15 Dec 2013 11:45:45 PST";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"5000731@http://wordpress.org/support/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:442:"<p>Hello,</p>
<p>Since the migration to another server my page cache isn\'t working correct. Every fist hit results in a blank page. Once the cache is warmed everything is fine. </p>
<p>How to solve this?</p>
<p><a rel="nofollow" target="_blank" href="http://wordpress.org/plugins/w3-total-cache/">http://wordpress.org/plugins/w3-total-cache/</a>
</p><img src="http://feeds.feedburner.com/~r/W3TOTALCACHE/~4/JBQxAmXJ7vE" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wordpress.org/support/topic/page-cache-not-working-properly#post-5000731";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"binaryestate on &quot;Woocommerce https: pages not loading properly&quot;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:103:"http://feedproxy.google.com/~r/W3TOTALCACHE/~3/wH4gvF-Omyo/woocommerce-https-pages-not-loading-properly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 15 Dec 2013 11:43:57 PST";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"5000719@http://wordpress.org/support/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:143:"<p>That\'s great to hear, you are most welcome!
</p><img src="http://feeds.feedburner.com/~r/W3TOTALCACHE/~4/wH4gvF-Omyo" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wordpress.org/support/topic/woocommerce-https-pages-not-loading-properly#post-5000719";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"optimus203 on &quot;Duplicate meta descriptions and meta titles for certain pages&quot;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://feedproxy.google.com/~r/W3TOTALCACHE/~3/XVepXH0t39Q/duplicate-meta-descriptions-and-meta-titles-for-certain-pages";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 15 Dec 2013 11:39:25 PST";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"5000709@http://wordpress.org/support/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:815:"<p>My Webmaster tools is showing that I have duplicate meta descriptions and meta titles for certain pages on my site. For example:</p>
<p>/contact/<br />
/contact</p>
<p>/fonts/vega/<br />
/fonts/vega</p>
<p>My permalinks is set to post name: <a rel="nofollow" target="_blank" href="http://www.website.com/sample-post/">http://www.website.com/sample-post/</a></p>
<p>It doesn\'t matter if I have the trailing / or not, I just want to remove this duplicate meta Title and meta Description warning that I\'m seeing in Google Webmaster Tools. Any idea why this might be occurring?</p>
<p><a rel="nofollow" target="_blank" href="http://wordpress.org/plugins/w3-total-cache/">http://wordpress.org/plugins/w3-total-cache/</a>
</p><img src="http://feeds.feedburner.com/~r/W3TOTALCACHE/~4/XVepXH0t39Q" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:109:"http://wordpress.org/support/topic/duplicate-meta-descriptions-and-meta-titles-for-certain-pages#post-5000709";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"underwearnation on &quot;Woocommerce https: pages not loading properly&quot;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:103:"http://feedproxy.google.com/~r/W3TOTALCACHE/~3/DE3_zi7qLxQ/woocommerce-https-pages-not-loading-properly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 15 Dec 2013 11:17:23 PST";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"5000643@http://wordpress.org/support/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:321:"<p>Yes, I used the MaxCDN live chat and was able to resolve the issue. One of the SSL settings was incorrect on my account at MaxCDN and now everything is working properly! Thanks for all your help on this. Much appreciated.
</p><img src="http://feeds.feedburner.com/~r/W3TOTALCACHE/~4/DE3_zi7qLxQ" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wordpress.org/support/topic/woocommerce-https-pages-not-loading-properly#post-5000643";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:4:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:40:"http://feeds.feedburner.com/W3TOTALCACHE";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:4:"next";s:4:"href";s:93:"http://pipes.yahoo.com/pipes/pipe.run?_id=02f556aa2f503be89aa9d89723644f40&_render=rss&page=2";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:40:"http://feeds.feedburner.com/W3TOTALCACHE";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:12:"w3totalcache";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:28:"http://www.w3.org/1999/xhtml";a:1:{s:4:"meta";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"name";s:6:"robots";s:7:"content";s:7:"noindex";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:22:"http://pipes.yahoo.com";a:1:{s:4:"meta";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"name";s:5:"pipes";s:7:"content";s:9:"noprocess";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"OorZ/MMmIjX+ehpBzwLN3cOK5U8";s:13:"last-modified";s:29:"Mon, 16 Dec 2013 02:09:08 GMT";s:4:"date";s:29:"Mon, 16 Dec 2013 02:17:07 GMT";s:7:"expires";s:29:"Mon, 16 Dec 2013 02:17:07 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1362, '_transient_timeout_feed_mod_6c78d00722dae650afc8789333d5c38e', '1387203427', 'no') ; 
INSERT INTO `wp_options` VALUES (1363, '_transient_feed_mod_6c78d00722dae650afc8789333d5c38e', '1387160227', 'no') ; 
INSERT INTO `wp_options` VALUES (1364, '_transient_timeout_dash_91cf481bdcff97d36bc4763744848eba', '1387203427', 'no') ; 
INSERT INTO `wp_options` VALUES (1365, '_transient_dash_91cf481bdcff97d36bc4763744848eba', '<h4>
	<a href="http://feedproxy.google.com/~r/W3TOTALCACHE/~3/bML-86gB1wE/call-to-a-member-function-using_permalinks-on-a-non-object">tombyrnes on &quot;Call to a member function using_permalinks() on a non-object&quot;</a>
</h4>
<h4>
	<a href="http://feedproxy.google.com/~r/W3TOTALCACHE/~3/JBQxAmXJ7vE/page-cache-not-working-properly">roosterling on &quot;Page cache not working properly&quot;</a>
</h4>
<h4>
	<a href="http://feedproxy.google.com/~r/W3TOTALCACHE/~3/wH4gvF-Omyo/woocommerce-https-pages-not-loading-properly">binaryestate on &quot;Woocommerce https: pages not loading properly&quot;</a>
</h4>

<p style="text-align: center;">
	<a href="http://feeds.feedburner.com/W3TOTALCACHE" target="_blank">View Feed</a>
</p>
', 'no') ; 
INSERT INTO `wp_options` VALUES (1366, '_transient_timeout_feed_4fee809661d1b035d98b93142a587416', '1387203428', 'no') ; 
INSERT INTO `wp_options` VALUES (1367, '_transient_feed_4fee809661d1b035d98b93142a587416', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
	
	
	

		
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"W3 EDGE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:22:"http://www.w3-edge.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:20:"Innovation Redefined";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Dec 2013 14:54:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.6.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Announcing W3 Total Cache Pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/dcqMeozVVyU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:66:"http://www.w3-edge.com/weblog/2013/09/w3-total-cache-pro/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 13 Sep 2013 02:01:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"w3 total cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.w3-edge.com/?p=2292";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:354:"Several weeks ago we silently launched version 0.9.3, a very exciting release for us. As we get closer to a final release of the popular web performance optimization (WPO) framework, we’re finally able start employing the best practices our colleagues like Joost de Valk and Pippin Williamson (among others) have championed for some time. But [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4780:"<p>Several weeks ago we silently launched version 0.9.3, a very exciting release for us. As we get closer to a final release of the popular web performance optimization (WPO) framework, we’re finally able start employing the best practices our colleagues like <a href="http://yoast.com/" target="_blank">Joost de Valk</a> and <a href="http://pippinsplugins.com/why-extensions/" target="_blank">Pippin Williamson</a> (among others) have championed for some time.</p>
<p>But before we get into that, let’s take a look at the highlights:</p>
<ul>
<li><strong>Fragment Caching</strong><br />
Social layer, personalization and e-commerce etc are common elements of highly dynamic web sites. That means that caching entire pages to improve user experience and performance is not a solution. Fragment Caching bridges the gap between no caching at all and the “ideal,” full page caching. By extending the WordPress <a href="http://codex.wordpress.org/Transients_API" target="_blank">Transient API</a>, W3TC allows developers to bring both horizontal and vertical scale to bear without doing anything differently.</li>
<li><strong>Extension Framework</strong><br />
As mentioned above, extensions / add-ons represent a great opportunity to both de-bloat projects that solve many problems or address many use cases. It also allows for innovation as 3<sup>rd</sup> parties can make contributions without having to be a core project developer to contribute or solve their problems while maintaining the control they need. We’re excited for you to try this first iteration of our extension framework, and documentation can be found (for now) inside the plugin’s FAQ.</li>
<li><strong>Genesis Framework Extension</strong><br />
Among the most popular theme clubs in the market and part of a highly valuable suite of publishing solutions is the Genesis Framework. Our work in the website optimization industry for the past 11+ years allows us to know great products and communities when we see them, and that is why we chose to work with <a href="http://www.studiopress.com/news/genesis-and-w3tc-pro.htm" target="_blank">CopyBlogger Media</a> to enhance the performance of the framework.The extension is included in the W3TC default distribution and requires an active Genesis theme as well as W3TC Pro. The extension leverages the fragment cache in order to do its magic, a solid example of the power of the new extension framework. Once enabled, a given page request will be served 30-60% faster (and will be even faster as we move forward).</p>
<p>Working with the Genesis team to get this extension into play has been fun, but we do expect to find some bugs along the way. Please let us know what you find so that we can promptly address. Meanwhile, we hope the value we’re offering helps you create engaging experiences for your readers / users. For Synthesis hosting customers, the upgrade is free and already running on your site(s).</li>
</ul>
<p>For those interested in upgrading to the Pro version, simply use the upgrade button to obtain a license key valid for a single WordPress installation. To have a professional from the team tune your site for performance, simply make a purchase from the support tab of the plugin itself.</p>
<p>To learn more about how fragment caching helps “origin optimization” (optimizing your site for the cache miss and other use cases), check out the <a href="http://websynthesis.com/wsa/wp-content/uploads/2013/09/The-Truth-About-WordPress-Performance.pdf" target="_blank">white paper</a> we co-authored with our friends at CopyBlogger Media!</p>
<p>We have a lot more planned for the Pro version of W3TC, so please stay tuned or share your ideas with us as we move forward.</p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=dcqMeozVVyU:qfvjWITD2dI:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=dcqMeozVVyU:qfvjWITD2dI:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=dcqMeozVVyU:qfvjWITD2dI:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=dcqMeozVVyU:qfvjWITD2dI:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=dcqMeozVVyU:qfvjWITD2dI:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=dcqMeozVVyU:qfvjWITD2dI:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=dcqMeozVVyU:qfvjWITD2dI:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=dcqMeozVVyU:qfvjWITD2dI:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/dcqMeozVVyU" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.w3-edge.com/weblog/2013/09/w3-total-cache-pro/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:57:"http://www.w3-edge.com/weblog/2013/09/w3-total-cache-pro/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"Security &amp; W3 Total Cache 0.9.2.4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/D6uNPwMc3MU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:79:"http://www.w3-edge.com/weblog/2013/01/security-w3-total-cache-0-9-2-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 28 Jan 2013 13:26:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"w3 total cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.w3-edge.com/?p=1730";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:334:"We take security quite seriously even though our focus is on making it trivial to allow any publisher to maximize the performance they can extract from their hosting environment and WordPress itself.  Most recently we took a look at the steps that GoDaddy was taking in the shared hosting segment of the market. In versions [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3436:"<p>We take security quite seriously even though our focus is on making it trivial to allow any publisher to maximize the performance they can extract from their hosting environment and WordPress itself.  Most recently we took a look at the steps that GoDaddy was taking in the <a href="http://www.w3-edge.com/weblog/2013/01/wpo-godaddy-how-to-configure-w3-total-cache/">shared hosting</a> segment of the market.</p>
<p>In versions of W3 Total Cache prior to 0.9.2.5 vulnerability exists (CVE-2012-6077, CVE-2012-6078, CVE-2012-6079) if the following two cases are true:</p>
<ol>
<li>Directory listing and download of w3tc/dbcache/ directories is possible</li>
<li>W3 Total Cache has database caching enabled and is set to use disk</li>
</ol>
<p>This issue was resolved, irrespective of whether or not #1 was true in release <a href="http://downloads.wordpress.org/plugin/w3-total-cache.0.9.2.5.zip">0.9.2.5</a> which offset the next release than some of you may have been testing to 0.9.2.6.</p>
<p>For those of you who feel they were affected, here are some remediation steps:</p>
<ul>
<li>Empty and disable database caching until you upgrade W3TC</li>
<li>Audit your administrator accounts and change their passwords, potentially add HTTP Basic Authentication to /wp-login.php and /wp-admin/ if possible</li>
<li>Update your database credentials, name (and table name offset if possible)</li>
<li>Ensure that you have nightly backups of your site, if you’re not sure contact your web host</li>
</ul>
<p>The 0.9.2.6 release expected within less than a week further expands on the initial approach to securing caching files to disk while using database caching and ameliorates issues caused with the previous patch.</p>
<p>One might ask, why not completely remove disk caching for the database from the W3TC framework? The problem is that our goal is to make it possible for users to take control of their performance needs, that means that if they have an environment where they’ve tested to find that reading cache files from disk provided lower execution times than not caching at all, that option should be available.</p>
<p>After years of scaling web sites, one thing we know for sure is that as your site grows, the techniques you use to scale it change. W3TC is ready to grow with you. With more than 140 features and fixes in the next release, the future is bright.</p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D6uNPwMc3MU:aBacnn1AIcs:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D6uNPwMc3MU:aBacnn1AIcs:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=D6uNPwMc3MU:aBacnn1AIcs:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D6uNPwMc3MU:aBacnn1AIcs:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=D6uNPwMc3MU:aBacnn1AIcs:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D6uNPwMc3MU:aBacnn1AIcs:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D6uNPwMc3MU:aBacnn1AIcs:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=D6uNPwMc3MU:aBacnn1AIcs:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/D6uNPwMc3MU" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:75:"http://www.w3-edge.com/weblog/2013/01/security-w3-total-cache-0-9-2-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:70:"http://www.w3-edge.com/weblog/2013/01/security-w3-total-cache-0-9-2-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPO &amp; GoDaddy: How to configure W3 Total Cache and APC";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/uPZ-1anZcvs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:91:"http://www.w3-edge.com/weblog/2013/01/wpo-godaddy-how-to-configure-w3-total-cache/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jan 2013 04:41:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"Web Hosting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.w3-edge.com/?p=1668";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:341:"APC is an opcode cache used by many sites to improve application performance. PHP is an interpreted language, and the scripts (such as the ones that comprise your WordPress site) are loaded, parsed, compiled into an opcode, and executed when called. This process can use an inordinate amount of resources on a busy site, especially [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Willie Jackson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3647:"<p><abbr title="Alternative PHP Cache">APC</abbr> is an opcode cache used by many sites to improve application performance. <abbr title="PHP: Hypertext Preprocessor">PHP</abbr> is an interpreted language, and the scripts (such as the ones that comprise your WordPress site) are loaded, parsed, compiled into an opcode, and executed when called. This process can use an inordinate amount of resources on a busy site, especially one without caching, so we need to do what we can to optimize this process.</p>
<p>While installing <abbr title="Alternative PHP Cache">APC</abbr> on a dedicated server or <abbr title="Virtual Private Server">VPS</abbr> is a straightforward process, this post (the first in a series of Web Performance Optimization (WPO) posts for GoDaddy) outlines how to enable it on your GoDaddy shared web hosting account:</p>
<ol>
<li>Log into your GoDaddy account and navigate to your hosting dashboard</li>
<li>Go to Tools > <abbr title="File Transfer Protocol">FTP</abbr> File Manager</li>
<li>Locate the <code>php5.ini</code> file and make a copy by clicking the checkbox, clicking on the &#8220;html&#8221; directory on the left, and entering <code>php5.ini.backup.txt</code> as the file name</li>
<li>Look for a line mentioning apc.shm_size and if one doesn&#8217;t exist, add this: <code>apc.shm_size = 64M</code></li>
<li>Make sure lines beginning with <code>zend_optimizer</code> and <code>zend_extension</code> are preceded by a semicolon</li>
<li>Save the file and then click the X in the top-right corner</li>
</ol>
<p>And now we need to restart <abbr title="PHP: Hypertext Preprocessor">PHP</abbr>:</p>
<ol>
<li>Navigate to your hosting dashboard again</li>
<li>Click the &#8220;Launch&#8221; button that corresponds with the hosting account in question</li>
<li>Under &#8220;Stats &#038; Monitors&#8221; click &#8220;System Processes&#8221;</li>
<li>Click &#8220;End Web&#8221; in the top</li>
<li>This will restart the PHP process on your account and you should now be able to cache against <abbr title="Alternative PHP Cache">APC</abbr> in W3 Total Cache</li>
</ol>
<p>Note that the optimal configuration depends on available memory, your theme, active plugins, and other factors. If you&#8217;d like help unlocking your site&#8217;s performance potential, <a href="http://www.w3-edge.com/wordpress-plugins/w3-total-cache/#form">place your order here</a> and we&#8217;ll implement these best practices for you.</p>
<p>And if you&#8217;d like to be updated when products are updated or announced, be sure to <a href="http://eepurl.com/n9mjH">sign up here</a>.</p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=uPZ-1anZcvs:mYEvGzWsfE0:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=uPZ-1anZcvs:mYEvGzWsfE0:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=uPZ-1anZcvs:mYEvGzWsfE0:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=uPZ-1anZcvs:mYEvGzWsfE0:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=uPZ-1anZcvs:mYEvGzWsfE0:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=uPZ-1anZcvs:mYEvGzWsfE0:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=uPZ-1anZcvs:mYEvGzWsfE0:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=uPZ-1anZcvs:mYEvGzWsfE0:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/uPZ-1anZcvs" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.w3-edge.com/weblog/2013/01/wpo-godaddy-how-to-configure-w3-total-cache/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:82:"http://www.w3-edge.com/weblog/2013/01/wpo-godaddy-how-to-configure-w3-total-cache/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"W3 Total Cache Version 0.9.2.5";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/roTCgklYEgQ/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.w3-edge.com/weblog/2013/01/w3-total-cache-version-0-9-2-5/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 09 Jan 2013 21:46:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.w3-edge.com/?p=1681";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:389:"We recently released a security update to W3 Total Cache that addresses a vulnerability that can be exploited on misconfigured servers when database caching to disk is enabled. All users are encouraged to update. If you see the following error following the upgrade: Fatal error: Call to undefined function w3_is_dbcluster() in /path/to/wp-content/some-file.php This likely means [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Willie Jackson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1770:"<p>We recently released a security update to W3 Total Cache that addresses a vulnerability that can be exploited on misconfigured servers when database caching to disk is enabled. All users are encouraged to update.</p>
<p>If you see the following error following the upgrade:<br />
<code>Fatal error: Call to undefined function w3_is_dbcluster() in /path/to/wp-content/some-file.php</code></p>
<p>This likely means that you&#8217;ve had us configure W3 Total Cache on your site already, and you were running a newer version of the plugin already. </p>
<p>You&#8217;ll need to manually disable W3 Total Cache to restore access and <a href="http://www.w3-edge.com/contact/">reach out</a> so we can get you sorted.</p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=roTCgklYEgQ:qMSvSpoLW84:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=roTCgklYEgQ:qMSvSpoLW84:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=roTCgklYEgQ:qMSvSpoLW84:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=roTCgklYEgQ:qMSvSpoLW84:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=roTCgklYEgQ:qMSvSpoLW84:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=roTCgklYEgQ:qMSvSpoLW84:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=roTCgklYEgQ:qMSvSpoLW84:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=roTCgklYEgQ:qMSvSpoLW84:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/roTCgklYEgQ" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"http://www.w3-edge.com/weblog/2013/01/w3-total-cache-version-0-9-2-5/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:69:"http://www.w3-edge.com/weblog/2013/01/w3-total-cache-version-0-9-2-5/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"The Magic of Brand Building: Cultivating 3rd Party Credibility";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/2fKM3LtVHUk/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:66:"http://www.w3-edge.com/weblog/2012/04/driving-brand-lift/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Apr 2012 16:33:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:31:"Business Development / Strategy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:10:"brand lift";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:18:"internet marketing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:18:"product market fit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.w3-edge.com/?p=1577";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:169:"Lots of the activities we often do as marketers when applied correctly can pay dividends in the future if we properly work towards building credibility around our brand.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6292:"<p>We take a holistic approach to internet marketing and while the recipes may change a bit year-to-year, the ingredients largely remain unchanged. It&#8217;s for that reason that I wanted to take look at some common tactics for driving traffic and converting it by creating brand trust / confidence. That is, common activities that marketers take when creating successful sites that drive traffic also work well in creating a memorable brand in the marketplace.</p>
<p>Growing a business is a balancing act of striking a balance between market relevance, market opportunity and market fit. Once you&#8217;ve reached that balance one of the key objectives is to have prospective customers associate your brand with the solution to their needs.</p>
<p align="center"><a href="http://www.w3-edge.com/?attachment_id=1576" rel="attachment wp-att-1576"><img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/04/product-market-fit.png" alt="" title="Market Relevance, Market Opportunity, Market Fit" width="500" height="455" class="aligncenter size-full wp-image-1576" /></a></p>
<p>In terms of 3<sup>rd</sup> party credibility, I&#8217;m talking about all the various ways we as marketers can cultivate word of mouth, which is the single most effective way to develop customers and communities.</p>
<p align="center"><a href="http://www.w3-edge.com/?attachment_id=1575" rel="attachment wp-att-1575"><img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/04/creating-trust.png" alt="" title="Creating Trust &amp; Credibility" width="500" height="496" class="aligncenter size-full wp-image-1575" /></a></p>
<p>Everyone is familiar with countless examples of 3rd party credibility at work directly or indirectly, let&#8217;s take a look at some:</p>
<p><strong>Link Building</strong><br />
Search Engines provide millions of recommendations every day, all of these referrals are hinged on the link juice that flows from one credible site to another online (otherwise known as Page Rank). Of the more than 200 ranking factors that Google uses and the countless filters that search engines apply in an effort to fight spam, back links remain one of the most significant signals that a site is worthy of appearing in search engine result pages (SERPs).</p>
<p><strong>Content Marketing Strategy</strong><br />
Every successful site today needs to have a healthy content strategy, among the numerous techniques to create engaging content whether evergreen (timelessly relevant) or seasonal etc, one of the most common ways to create or drive brand credibility is by having your company&#8217;s experts contribute to content other authoritative sites in your niche.</p>
<p><strong>Testimonials / Client List</strong><br />
Today&#8217;s testimonials may take shape in a number of ways, not the least of which is badges clients can sport on their sites indicating their support of your brand. Customers may also pen a short inspirational sentence or two talking about their experience with your brand and the value your product(s) or service(s) created for them.</p>
<p><strong>Reviews / Case Studies</strong><br />
When publications that your customers trust choose to provide an in depth review of your company and it&#8217;s offerings, you&#8217;re definitely on your way to creating a strong brand. By the same token, case studies are an opportunity share an in depth look at the “before and after” results clients realized in working with you. Since case studies normally require a blessing from the client, this approach is helpful for prospective customers who may relate to the story or otherwise discover more about how your product(s) or service(s) can be used.</p>
<p><strong>Brand Associations / Partnerships</strong><br />
Offline or on, creating close proximity of your brand with others your target market trusts is often a very good thing. In cases where you can create an offer by working together with a brand that compliments yours, not only does this save time and hopefully money for your customers, but it also creates an even more profound brand experience. Associations and partnerships can take numerous forms, however the primary goal here is to generate brand lift – awareness about your brand and your value proposition in the marketplace.</p>
<p>So what are the keys to growing brand recognition, trust and creating brand lift? Well it depends on your business a bit, but in essence we need to think through a strategy to apply the principles above in an engaging way without sacrificing any opportunity to create value while differentiating your business from the competition. The following matrix provides a good framework to think about how to create the credibility that grows brand equity:</p>
<p align="center"><a href="http://www.w3-edge.com/?attachment_id=1574" rel="attachment wp-att-1574"><img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/04/creating-credibility.png" alt="" title="Creating Credibility" width="500" height="405" class="aligncenter size-full wp-image-1574" /></a></p>
<p>Have any great examples of companies that are doing a great job of creating brand equity online today via their efforts? Share by leaving a comment.</p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=2fKM3LtVHUk:gJ4YB8btkIo:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=2fKM3LtVHUk:gJ4YB8btkIo:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=2fKM3LtVHUk:gJ4YB8btkIo:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=2fKM3LtVHUk:gJ4YB8btkIo:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=2fKM3LtVHUk:gJ4YB8btkIo:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=2fKM3LtVHUk:gJ4YB8btkIo:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=2fKM3LtVHUk:gJ4YB8btkIo:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=2fKM3LtVHUk:gJ4YB8btkIo:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/2fKM3LtVHUk" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.w3-edge.com/weblog/2012/04/driving-brand-lift/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:57:"http://www.w3-edge.com/weblog/2012/04/driving-brand-lift/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"How to integrate a CDN with W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/aAvdFAPCTIg/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.w3-edge.com/weblog/2012/03/how-to-integrate-a-cdn-with-w3-total-cache/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 13 Mar 2012 13:00:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.w3-edge.com/?p=1369";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:371:"The integration of a Content Delivery Network (CDN) into your website remains one of the easiest and most cost-effective ways to improve web performance. W3 Total Cache supports several CDN types (self-hosted, origin pull, and origin push) and makes the integration into WordPress simple. In this post, I&#8217;ll show you how to integrate MaxCDN&#8217;s origin [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Willie Jackson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:8934:"<p>The integration of a Content Delivery Network (CDN) into your website remains one of the easiest and most cost-effective ways to improve web performance. W3 Total Cache supports several CDN types (self-hosted, origin pull, and origin push) and makes the integration into WordPress simple.</p>
<p>In this post, I&#8217;ll show you how to integrate MaxCDN&#8217;s origin pull CDN product into W3TC. <a href="http://bit.ly/pXZ4t1">MaxCDN&#8217;s product</a> remains one of the most commonly used CDNs in W3TC because it&#8217;s both affordable, simple to set up, and requires virtually no maintenance once integrated.</p>
<h2><strong>MaxCDN configuration steps</strong></h2>
<p>First, <a href="http://bit.ly/pXZ4t1">create MaxCDN account</a> if you haven&#8217;t already. When you log in, click &#8220;Manage Zones&#8221;<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/click-manage-zones1.png" alt="" title="click-manage-zones" width="710" height="566" class="aligncenter size-full wp-image-1541" /><br />
Then click &#8220;Create Pull Zone&#8221;<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/create-pull-zone1-710x459.png" alt="" title="create-pull-zone" width="710" height="459" class="aligncenter size-large wp-image-1527" /><br />
Configure your new Pull Zone and then click &#8220;Create&#8221;<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/click-create.png" alt="" title="click-create" width="710" height="329" class="aligncenter size-full wp-image-1543" /><br />
Make a note of your CDN URL, which we&#8217;ll use in a moment<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/pull-zone-created1.png" alt="" title="pull-zone-created" width="710" height="378" class="aligncenter size-full wp-image-1545" /></p>
<p>We could technically integrate our CDN now, but W3TC can communicate with the MaxCDN (allowing purge requests to be sent directly from WordPress) if we set up the API connection.</p>
<p>Click &#8220;my settings&#8221; in the top-right corner<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/click-settings.png.png" alt="" title="click-settings" width="390" height="38" class="aligncenter size-full wp-image-1529" /><br />
Click &#8220;API&#8221; in the sub-menu that appears<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/click-api1-710x26.png" alt="" title="click-api" width="710" height="26" class="aligncenter size-large wp-image-1530" /><br />
You&#8217;ll notice that we don&#8217;t have any API Keys configured. Click &#8220;Add Key&#8221;<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/click-add-key1-710x214.png" alt="" title="click-add-key" width="710" height="214" class="aligncenter size-large wp-image-1532" /><br />
Add a description if you&#8217;d like and then click &#8220;Save&#8221;<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/add-api-key-710x211.png" alt="" title="add-api-key" width="710" height="211" class="aligncenter size-large wp-image-1473" /><br />
Your API ID and Key will appear here, I&#8217;ve removed my Key from the screenshot<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/key-and-id-710x84.png" alt="" title="key-and-id" width="710" height="84" class="aligncenter size-large wp-image-1474" /></p>
<p>That&#8217;s all we need to do in MaxCDN right now. In the next section, we&#8217;ll configure W3 Total Cache using the pull zone we just created.</p>
<p><strong><br />
<h2>W3 Total Cache configuration steps:</h2>
<p></strong><br />
Once logged into WordPress, navigate to the W3 Total Cache by clicking on the &#8220;Performance&#8221; tab towards the bottom of your Dashboard sidebar. From the General Setting page, ensure that CDN is <strong>disabled</strong> and select &#8220;NetDNA / MaxCDN&#8221; from dropdown menu<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/w3tc-select-maxcdn3-710x210.png" alt="" title="w3tc-select-maxcdn" width="710" height="210" class="aligncenter size-large wp-image-1486" /><br />
Navigate to the CDN Settings. Enter your API ID and Key, your CDN URL, and click &#8220;Test NetDNA&#8221;<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/test-passed-710x345.png" alt="" title="test-passed" width="710" height="345" class="aligncenter size-large wp-image-1487" /></p>
<p>You should see &#8220;Test passed&#8221; in green if you&#8217;ve done everything correctly. Save your settings and then navigate back to the General Settings page. Enable the CDN by clicking the check box and saving your settings. </p>
<p><strong>Power user tip #1:</strong> Configure a subdomain like <code>cdn.yourdomain.com</code> so we can get rid of long MaxCDN URL. W3 Total Cache lets you configure multiple CDN subdomains, so we&#8217;ll go ahead and configure a few.</p>
<p>Log back into MaxCDN and from the dashboard, click &#8220;Manage&#8221; next to the Pull Zone you created:<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/click-manage-710x119.png" alt="" title="click-manage" width="710" height="119" class="aligncenter size-large wp-image-1515" /><br />
Then click &#8220;Settings&#8221; right above the Zone Configuration<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/cdn-settings1.png" alt="" title="cdn-settings" width="393" height="52" class="aligncenter size-full wp-image-1533" /><br />
You&#8217;re presented with an overview of your Pull Zone settings<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/cdn-settings.png" alt="" title="cdn-settings" width="480" height="595" class="aligncenter size-full wp-image-1517" /><br />
The section we want is labeled Custom Domains. Click &#8220;Edit&#8221; and enter your desired subdomains<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/custom-subdomains.png" alt="" title="custom-subdomains" width="477" height="333" class="aligncenter size-full wp-image-1519" /><br />
Click &#8220;Update&#8221; and then navigate to your DNS control panel. Create a CNAME entry for every subdomain that you entered in MaxCDN, and alias them to your MaxCDN URL<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/cname-aliases-710x125.png" alt="" title="cname-aliases" width="710" height="125" class="aligncenter size-large wp-image-1520" /><br />
Once <a target="_blank" href="http://hosting.intermedia.net/support/kb/?id=797">DNS propagates</a>, you can update W3TC with the subdomains and replace the long CDN URL with the new, custom ones<br />
<img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2012/01/subdomains-integrated-710x368.png" alt="" title="subdomains-integrated" width="710" height="368" class="aligncenter size-large wp-image-1521" /></p>
<p><strong>Power user tip #2:</strong> We can further improve page loads speeds by using a completely different domain for the CDN, ensuring that the domain is <a target="_blank" href="http://developer.yahoo.com/performance/rules.html#cookie_free">cookie-free</a>. So if your site is <code>www.domain.com</code>, you could set <code>domain.<strong>net</strong></code> as the domain to use with your CDN. <em>Note: this assumes that you own <code>domain.net</code> and have access to its DNS control panel.</em><br />
That&#8217;s it! If you have any issues getting it working, <a href="http://www.w3-edge.com/contact/">drop us a line</a>. If you&#8217;d like us to set this up for you, we&#8217;re <a href="http://www.w3-edge.com/wordpress-plugins/w3-total-cache/#form">happy to help</a>. </p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=aAvdFAPCTIg:DffZEdDbGOQ:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=aAvdFAPCTIg:DffZEdDbGOQ:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=aAvdFAPCTIg:DffZEdDbGOQ:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=aAvdFAPCTIg:DffZEdDbGOQ:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=aAvdFAPCTIg:DffZEdDbGOQ:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=aAvdFAPCTIg:DffZEdDbGOQ:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=aAvdFAPCTIg:DffZEdDbGOQ:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=aAvdFAPCTIg:DffZEdDbGOQ:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/aAvdFAPCTIg" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:86:"http://www.w3-edge.com/weblog/2012/03/how-to-integrate-a-cdn-with-w3-total-cache/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"12";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.w3-edge.com/weblog/2012/03/how-to-integrate-a-cdn-with-w3-total-cache/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:60:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"How to configure W3 Total Cache to work with HTTPS and SSL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/amgAo0bE390/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:69:"http://www.w3-edge.com/weblog/2011/11/how-to-w3tc-https-ssl/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 11 Nov 2011 21:42:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:19:"CSS / Markup / Code";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"caching";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:17:"http transactions";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:10:"production";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:14:"w3 total cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:9:"wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.w3-edge.com/?p=1321";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:337:"We&#8217;ve worked with a few sites recently that use HTTPS to secure certain parts of there site. Some of the pages are SSL protected due to the data captured (pages processing registration or financial information, for example). When using a CDN in conjunction with HTTPS / SSL, customers often find that the CDN product they [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Anthony Somerset";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4407:"<p>We&#8217;ve worked with a few sites recently that use <abbr title="Hypertext Transfer Protocol Secure">HTTPS</abbr> to secure  certain parts of there site. Some of the pages are <abbr title="Secure Sockets Layer">SSL</abbr> protected due to the data captured (pages processing registration or financial information, for example).</p>
<p>When using a <abbr title="Content Delivery Network">CDN</abbr> in conjunction with <abbr title="Hypertext Transfer Protocol Secure">HTTPS</abbr> / <abbr title="Secure Sockets Layer">SSL</abbr>, customers often find that the <abbr title="Content Delivery Network">CDN</abbr> product they use  lacks an <abbr title="Hypertext Transfer Protocol Secure">HTTPS</abbr> endpoint, or the one provided is different from the standard, non-<abbr title="Hypertext Transfer Protocol Secure">HTTPS</abbr> one.</p>
<p>One simple solution to this would be to force the loading of your <abbr title="Content Delivery Network">CDN</abbr> assets via <abbr title="Hypertext Transfer Protocol">HTTP</abbr> like so:</p>
<p><img class="alignnone size-full wp-image-1322" src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2011/11/Screen-Shot-2011-11-11-at-19.50.27.jpg" alt="" width="649" height="198" /></p>
<p>This leads to one other issue, however&#8230;</p>
<h2>Why dont I see the Blue/Green Bar?</h2>
<p><img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2011/11/https.jpg" alt="" title="https" width="310" height="35" class="alignnone size-full wp-image-1340" /><br />
When a page and all of its assets are served over HTTPS, modern web browsers provide a visual indicator—usually in green or blue. This is designed to provide visitors with the confidence to shop or register on your site.</p>
<p>When your HTTPS pages are served with &#8220;mixed content&#8221; (as it sounds, this is a situation in which HTTPS and HTTP assets are both being loaded on a single page, this indicator does not appear. This could happen for any number of reasons — all beyond the scope of this article — but there&#8217;s a simple solution for addressing this with only a few short lines of code.</p>
<h2>Disabling CDN on HTTPS pages only</h2>
<p>W3 Total Cache ships with documentation (Performance > FAQ) that provides instructions on disabling each of the caching types. Combined with a simple PHP function and WordPress hook, we&#8217;re able to conditionally disable the CDN for pages that utilize HTTPS.</p>
<p>Add the following code snippet to your theme&#8217;s functions.php file:</p>
<pre class="brush: plain; title: ; notranslate">add_action(\'wp_head\',\'nocdn_on_ssl_page\');
function nocdn_on_ssl_page() {
if ($_SERVER[\'HTTPS\'] == &quot;on&quot;) {
define(\'DONOTCDN\', true);
}
}</pre>
<p>This of course assumes that you have W3 Total Cache active and that the only assets being served over HTTP are originating from your CDN (otherwise, you might need something like <a href="http://wordpress.org/extend/plugins/wordpress-https/">this</a>). When you reload a page being served over HTTPS, you should notice that the familiar green / blue indicator appears in your address bar. </p>
<p><em>Note: we&#8217;ve found that <a href="http://tracking.maxcdn.com/c/15753/3982/378">MaxCDN</a>&#8216;s SSL support and easy integration with W3 Total Cache provides a solid solution for many customers.</em></p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=amgAo0bE390:JIz8qPvOWpY:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=amgAo0bE390:JIz8qPvOWpY:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=amgAo0bE390:JIz8qPvOWpY:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=amgAo0bE390:JIz8qPvOWpY:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=amgAo0bE390:JIz8qPvOWpY:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=amgAo0bE390:JIz8qPvOWpY:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=amgAo0bE390:JIz8qPvOWpY:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=amgAo0bE390:JIz8qPvOWpY:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/amgAo0bE390" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://www.w3-edge.com/weblog/2011/11/how-to-w3tc-https-ssl/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:60:"http://www.w3-edge.com/weblog/2011/11/how-to-w3tc-https-ssl/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Security Alert for W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/fW00ncmChiI/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://www.w3-edge.com/weblog/2011/06/security-alert-w3-total-cache/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 21 Jun 2011 22:56:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:14:"w3 total cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.w3-edge.com/?p=1284";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:313:"On the heels of a post by Matt Mullenweg, I thought it best to also make a post here to put any confusion that may ensue to rest: Suspicious activity in wordpress.org plugin was noticed and a few plugins were found to be compromised. Malicious code was added to these plugins creating backdoor access to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2792:"<p>On the heels of a post by <a href="http://wordpress.org/news/2011/06/passwords-reset/">Matt Mullenweg</a>, I  thought it best to also make a post here to put any confusion that may ensue to  rest:</p>
<p>Suspicious activity in wordpress.org plugin was noticed and  a <a href="http://www.addthis.com/blog/2011/06/21/security-alert-for-addthis-wordpress-plugin/">few</a> <a href="http://www.bravenewcode.com/2011/06/important-security-update-wptouch-1-9/">plugins</a> were found to be compromised. Malicious code was added to these plugins  creating backdoor access to the web server. You would only be affected if you  downloaded an update of the plugin today.</p>
<p>Once we were notified of the issue, we made sure that the  current stable release (0.9.2.2) was restored to normal in addition to  releasing the current development version as (0.9.2.3) allowing users to get an  upgrade notification in WordPress Admin.</p>
<p>Needless to say, if you haven’t already upgraded, we  encourage you to do so straight away via the WordPress Admin’s plugins page, it  just takes a minute. If you did not upgrade today, you site should be secure,  however we encourage you to update so that your site can take advantage of the  additional performance optimizations included with each release.</p>
<p>  As many of you have learned from working with us, W3TC seeks  to improve the search engine ranking, conversion rates and user experience of  web sites for free. We welcome you to submit a bug submission form from the  support tab of the plugin to help us identify issues in new features and old  features as the performance framework is used in more and more cases.</p>
<p>As always, thanks for your understanding and participation.</p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=fW00ncmChiI:kmeEO_e9wsQ:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=fW00ncmChiI:kmeEO_e9wsQ:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=fW00ncmChiI:kmeEO_e9wsQ:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=fW00ncmChiI:kmeEO_e9wsQ:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=fW00ncmChiI:kmeEO_e9wsQ:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=fW00ncmChiI:kmeEO_e9wsQ:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=fW00ncmChiI:kmeEO_e9wsQ:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=fW00ncmChiI:kmeEO_e9wsQ:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/fW00ncmChiI" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://www.w3-edge.com/weblog/2011/06/security-alert-w3-total-cache/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.w3-edge.com/weblog/2011/06/security-alert-w3-total-cache/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:63:"
		
		
		
		
		
				
		
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"Optimize the Performance of Widgets, Buttons &amp; More";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/D8S9gY2WmME/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:88:"http://www.w3-edge.com/weblog/2011/02/optimize-social-media-button-performance/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 07 Feb 2011 19:08:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:8:{i:0;a:5:{s:4:"data";s:9:"Usability";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:27:"User Interface / Experience";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:15:"Web Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:11:"performance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:7:"plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:12:"start render";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:7:"widgets";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.w3-edge.com/?p=1207";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:246:"Too much 3rd Party content can slow down the growth of your site, reduce engagement, conversions and more. Learn how you can still incorporate widgets, plugins etc and still have a site that does not force your visitors to leave and never return.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:25017:"<p>A <a href="http://www.stevesouders.com/blog/2010/09/30/render-first-js-second/">recent  post</a> by web site performance thought leader (and user experience expert as  a result) Steve Souders reminds me of a vital nuance that&#8217;s not even clearly  expressed in the popular Yahoo! <a href="http://developer.yahoo.com/performance/rules.html">performance rules</a>;  namely render the page first, THEN add JavaScript. One of the largest  challenges with this objective is addressing the performance of <a href="http://www.stevesouders.com/blog/2010/02/17/performance-of-3rd-party-content/">3rd  party resources</a>. With social media demanding more widgets, plugins, badges  and buttons etc available every day and a lack of awareness on the part of  developers about how to make sure that their buttons are as effective and  valuable as possible, sometimes performance concerns are overlooked.</p>
<p>Ask  yourself, what is the value of lost visitors due to a slow loading web site?  There are literally page views &#8220;locked&#8221; away in those slow loading pages of  your web site that can be &#8220;unlocked&#8221; with a few quick changes. Simply put, having  numerous 3rd party elements in your site can ultimately be its  downfall.</p>
<p>For  example, simply adding the <a href="http://developers.facebook.com/docs/plugins/">Facebook fan box</a> will dramatically  slow a page in many cases, slow down the browsers due to large memory usage and  usually lots of additional download time making the page &#8220;not ready&#8221; until  everything is downloaded. So if your goal is to optimize your site for social  media and make sure that your bounce rates are low, time on site is high, page  views per visit grows and Google has 1 less reason to rank your site poorly,  keep reading.</p>
<p>So,  let&#8217;s take a look at the implementations you need for your site that make sure  your visitors see your content before your widgets. From an idealistic point of  view the &#8220;start render time,&#8221; or when the browser actually starts to paint  the page, these tips will not bring this value as close to zero as I would  like, however they will definitely improve user experience. Keep in mind that  there are numerous other steps to be taken or possibilities, but we&#8217;re focusing  on reducing the negative impact of widgets characterized above. What follows is  HTML5 code for various cases:</p>
<p><strong><a href="http://about.digg.com/downloads/button/smart">Digg</a>:<br />
</strong>After working with Digg on some their latest  improvements, I&#8217;m happy to share an implementation that is much more  user-centric; if you have multiple buttons per page, this is especially  valuable:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;a class=&quot;DiggThisButton DiggThisButtonMedium&quot;
        href=&quot;http://digg.com/submit?url=http://domain.com/&amp;amp;title=Post%20Title&quot;
        rel=&quot;nofollow external&quot;&gt;&lt;img src=&quot;http://widgets.digg.com/img/button/diggThisMedium.png&quot;
        width=&quot;50&quot; height=&quot;61&quot; alt=&quot;&quot; /&gt;&lt;/a&gt;
</pre>
<p>Then, before &lt;/body&gt; embed the following only once and multiple buttons will  still work in a single page:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script src=&quot;http://widgets.digg.com/buttons.js&quot;&gt;&lt;/script&gt;
</pre>
<p>This  implementation allows the page to render and then draws the buttons later.</p>
<p><strong><a href="http://www.stumbleupon.com/badges/landing/">StumbleUpon</a>:<br />
</strong>SU, has recently updated their buttons, which is  good, but what follows is not truly asynchronous and definitely not as optimal  as the Digg button above because of the multiple JS embeddings per page, at  least this implementation won&#8217;t block the page render. First position the  button with a unique ID wherever you wish:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;div id=&quot;id&quot;&gt;&lt;/div&gt;
</pre>
<p>Then  for each button make sure that an embedding exists above &lt;/body&gt; so the  button will be rendered in the location:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script src=&quot;http://www.stumbleupon.com/hostedbadge.php?s=5&amp;r=http%3A%2F%2Fdomain.com%2F&amp;a=1&amp;d=id&quot;&gt;&lt;/script&gt;
</pre>
<p><strong><a href="http://www.linkedin.com/publishers">LinkedIn</a>:</strong><br />
The LinkedIn button implementation is also not perfect, but a carries a smaller  total payload than the StumbleUpon buttons when there are multiple buttons per  page:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script type=&quot;in/share&quot; data-counter=&quot;top&quot;&gt;&lt;/script&gt;
</pre>
<p>Then  at the bottom of the page a single JS embedding with power all of the buttons:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script src=&quot;http://platform.linkedin.com/in.js&quot;&gt;&lt;/script&gt;
&lt;/body&gt;
</pre>
<p><strong><a href="http://tweetmeme.com/about/retweet_button">Tweetmeme</a>:<br />
</strong>I still recommend this service because it also  generates a usable button for feeds you may syndicate, while the official  twitter button still does not. The best way to use this widget is via &lt;iframe&gt;  as iframes do not block the render of a page, too many though can still slow  down a page render or cause other anomalies in some browsers. Anyway, here&#8217;s what  that implementation looks like:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;iframe scrolling=&quot;no&quot; height=&quot;61&quot; width=&quot;50&quot; frameborder=&quot;0&quot;
        src=&quot;http://api.tweetmeme.com/widget.js?url=http://yoururl.com/&amp;amp;style=normal&amp;amp;source=yoururl&amp;amp;service=bit.ly&quot;&gt;&lt;/iframe&gt;
</pre>
<p><strong><a href="http://twitter.com/goodies/tweetbutton">Twitter</a>:<br />
</strong>The official twitter button works pretty well,  it doesn&#8217;t have retweet data for everything ever shared on your site as they  only started gathering that data when they launched the button (so use  tweetmeme for those older stories if you can), but it does have a reliable  sharing experience for users, just make sure that if you use the following  implementation:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;iframe class=&quot;twitter-share-button&quot; allowtransparency=&quot;true&quot; frameborder=&quot;0&quot; scrolling=&quot;no&quot;
        src=&quot;http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%domain.com%2F&amp;amp;via=twitterhandle&amp;amp;text=Post%20Title&amp;amp;count=vertical&quot;
        width=&quot;55&quot; height=&quot;63&quot;&gt;&lt;/iframe&gt;
</pre>
<p>You  can of course use a technique similar to LinkedIn or Digg, but the JS will  actually create an &lt;iframe&gt; anyway, so this approach is more performance  as it won&#8217;t block the page render and yields the same net result. For those  using <a href="http://dev.twitter.com/anywhere/begin">@anywhere</a> to add  hovercards and other twitter functionality to their sites, the technique that  apples for Diff of LinkedIn can be applied.</p>
<p><strong><a href="http://help.sharethis.com/">ShareThis</a>:</strong><br />
Among the most popular buttons available, their implementation has dramatically  improved as the total payload for JavaScript has been reduced, although the  script loads synchronously still unfortunately. On the positive side, the  buttons are decoupled from the scripts that embed them. The instructions  recommend adding the scripts to the &lt;head&gt;, but I recommend adding them  before &lt;/body&gt; or after &lt;body&gt; if you&#8217;re having any problems.</p>
<pre class="brush: xml; title: ; notranslate">
&lt;span class=&quot;st_sharethis&quot;&gt;&lt;/span&gt;
&lt;script&gt;
        var __st_loadLate=true; // if __st_loadLate is defined then the widget will not load on domcontent ready
        stLight.options({
                publisher:\'12345\',
                tracking:\'google\',
                embeds:\'true\'
        });
&lt;/script&gt;
</pre>
<p>And  of course, activate the button after the content is displayed by placing the  script that powers the widgets on the page as shown:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script src=&quot;http://w.sharethis.com/button/buttons.js&quot;&gt;&lt;/script&gt;
&lt;/body&gt;
</pre>
<p><strong><a href="http://www.google.com/buzz/api/admin/configPostWidget">Google Buzz</a>:</strong><br />
Implementing the Buzz button like many others that are reasonably well done  allow for a single JS embed to support multiple button instances in a single  page:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;a href=&quot;http://www.google.com/buzz/post&quot; class=&quot;google-buzz-button&quot; title=&quot;Google Buzz&quot;
        data-message=&quot;Here\'s Buzz!&quot; data-url=&quot;http://www.google.com/buzz&quot; data-locale=&quot;en&quot;
        data-button-style=&quot;normal-count&quot;&gt;&lt;/a&gt;
</pre>
<p>Although  not asynchronous the JS embed can still be placed above the &lt;/body&gt; tag  as shown:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script src=&quot;http://www.google.com/buzz/api/button.js&quot;&gt;&lt;/script&gt;
</pre>
<p><strong><a href="http://www.google.com/friendconnect/">Google  Friend Connect</a> (AdSense &amp; Gadgets):</strong><br />
It&#8217;s critical to remember that you only need to embed the Friend Connect JS  library once per page. If you&#8217;re minifying the file be sure to make sure your  cache is frequently updated as the code is changed quite often and an old cache  may cause anomalies on your site. The reason why this tip is notable is that  this implementation supports AdSense as well as all of the other Gadgets with a  single embed, so if you have multiple AdSense placements in a page, this is the  way to go:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;body&gt;
&lt;script src=&quot;http://www.google.com/friendconnect/script/friendconnect.js&quot;&gt;&lt;/script&gt;
</pre>
<p>Specify where the placement will appear using a div with a unique ID:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;div id=&quot;id&quot;&gt;&lt;/div&gt;
&lt;script&gt;
google.friendconnect.container.setParentUrl(\'/\' /* location of rpc_relay.html and canvas.html */);
google.friendconnect.container.renderAdsGadget({
        id: \'id\',
        height: 90,
        site: \'XXXXXXXXXXXXXXX\',\'prefs\':{&quot;google_ad_client&quot;:&quot;ca-pub-XXXXXXXXXXXXXXX&quot;,
                &quot;google_ad_host&quot;:&quot;pub-XXXXXXXXXXXXXXX&quot;,&quot;google_ad_slot&quot;:&quot;XXXXXXXXXX&quot;,&quot;google_ad_format&quot;:&quot;728x90&quot;}
});
&lt;/script&gt;
</pre>
<p>Then you can obviously embed numerous other placements or gadgets all powered by a single JS embedding. Unfortunately the JS embedding is not asynchronous, but at least it&#8217;s better than having lots of AdSense JS calls throughout a page or even additional calls for your gadgets.</p>
<p><strong>Facebook Share / Facebook Like / Other <a href="http://developers.facebook.com/docs/plugins/">Facebook plugins</a>:<br />
</strong>Use the XFBML implementation described on the  various plugin pages; this implementation does interfere with page render and  positioning it after the &lt;body&gt; tag means that each of the plugins used  in a given page will load at the same time as soon as the scripts have loaded.  No need for multiple scripts, which have to be downloaded repeatedly and slow  down the page render etc etc.</p>
<p>Add  support of the XFBML markup to the document:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;!DOCTYPE html&gt; 
&lt;html xmlns=&quot;http://www.w3.org/1999/xhtml&quot; dir=&quot;ltr&quot; lang=&quot;en-US&quot;
        xmlns:x2=&quot;http://www.w3.org/2002/06/xhtml2&quot;
        xmlns:fb=&quot;http://www.facebook.com/2008/fbml&quot;&gt;
&lt;head&gt;
</pre>
<p>The embed itself:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;body&gt;
&lt;div id=&quot;fb-embed&quot;&gt;&lt;/div&gt; 
&lt;script&gt; 
window.fbAsyncInit = function() { FB.init({appId: \'XXXXXXXXXXXXXXX\', status: true, cookie: true, xfbml: true}); };
(function() {
	var e = document.createElement(\'script\'); e.async = true;
	e.src = document.location.protocol +
	\'//connect.facebook.net/en_US/all.js\';
	document.getElementById(\'fb-embed\').appendChild(e);
	}());
&lt;/script&gt;
</pre>
<p>Then place the Like Box itself where you desired:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;fb:like profile_id=&quot;XXXXXXXXXXXX&quot; href=&quot;http://domain.com/&quot; width=&quot;450&quot;&gt;&lt;/fb:like&gt;
</pre>
<p><strong><a href="http://www.meebo.com/websites/">Meebo  Bar</a>:<br />
</strong>Meebo has actually taken a <a href="https://bar.meebo.com/media/img/bar-performance.pdf">number of strides</a> (with the consult of Steve Souders as well) to improve the performance of their  meebo bar; still it&#8217;s something more for users to download and more JavaScript  to be run in your visitor&#8217;s browser, but I can now actually recommend this for  publishers looking to increase engagement and create new monetization opportunities  for their site. Their implementation is fully asynchronous and has a number of  optimizations compared to earlier version. The latest implementation  documentation at their site is the best reference.</p>
<p><strong><a href="http://www.openx.org/">OpenX</a>:<br />
</strong>The OpenX team has promised some an asynchronous  embedding code for their single page call (SPC) implementation, which basically  means that multiple ads in a given page can be requested without blocking the  page render and are requested at once instead of sequentially, however for the  moment, this is the best implementation I can recommend. It also uses iframes  to alleviate render-blocking issues as well some:</p>
<p>I  recommend adding this 1.3K of (<a href="http://closure-compiler.appspot.com/">closure  compiler</a> optimized) code directly in the &lt;head&gt; of the page to power  the widgets. It&#8217;s small enough that it is faster than making another HTTP  transaction (DNS lookup, connect, download, execute etc) for this purpose, the  original file is <a href="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2011/02/script.js">here</a>:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script&gt;var adPositions=[];function writeAdDiv(a,b,c){document.write(\'&lt;div class=&quot;banner&quot; id=&quot;\'+a+\'&quot; style=&quot;width:\'+b+&quot;px; height:&quot;+c+&quot;px; line-height:&quot;+c+\'px;&quot;&gt;&amp;nbsp;&lt;/div&gt;\');adPositions[a]=a}function OpenX_findPosX(a){var b=0;if(a.offsetParent)for(;a.offsetParent;){b+=a.offsetLeft;a=a.offsetParent}else if(a.x)b+=a.x;return b}function OpenX_findPosY(a){var b=0;if(a.offsetParent)for(;a.offsetParent;){b+=a.offsetTop;a=a.offsetParent}else if(a.y)b+=a.y;return b} function OpenX_moveAbove(a,b){var c=0;if(a.offsetHeight)c=a.offsetHeight;else if(a.clip&amp;&amp;a.clip.height)c=a.clip.height;else if(a.style&amp;&amp;a.style.pixelHeight)c=a.style.pixelHeight;if(window.XMLHttpRequest)if(!document.all){b.style.paddingTop=&quot;0px&quot;;b.style.paddingBottom=&quot;0px&quot;}if(c&gt;0)b.style.height=c+&quot;px&quot;;a.style.left=OpenX_findPosX(b)+&quot;px&quot;;a.style.top=OpenX_findPosY(b)+&quot;px&quot;} function OpenX_positionDivs(){for(var a in adPositions){var b=a+&quot;-Hidden&quot;;if(document.getElementById){targetZoneDivID=document.getElementById(a);sourceZoneDivID=document.getElementById(b)}else if(document.all){targetZoneDivID=document.all[a];sourceZoneDivID=document.all[b]}else if(document.layers){targetZoneDivID=document.layers[a];sourceZoneDivID=document.layers[b]}targetZoneDivID!=null&amp;&amp;sourceZoneDivID!=null&amp;&amp;OpenX_moveAbove(sourceZoneDivID,targetZoneDivID)}}window.onresize=function(){OpenX_positionDivs()};&lt;/script&gt;
</pre>
<p>The  SPC implementation is vital in making sure that the execution and transaction  times are as small as possible. So create the slot(s) in the page as follows:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;body&gt;
&lt;script&gt;var OA_zones = {&quot;728x90_Leaderboard&quot; : 1}&lt;/script&gt;
&lt;script src=&quot;http://openx-server.com/spcjs.php?id=1&quot;&gt;&lt;/script&gt;
</pre>
<p>Then place the slots in your HTML as appropriate:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script&gt;&lt;!--//&lt;![CDATA[
	writeAdDiv(\'button1\', 728, 90);
//]]&gt;--&gt;&lt;/script&gt;
</pre>
<p>And finally, in the footer of the document, make the call to draw the ad in the appropriate slot:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;div id=&quot;button1-Hidden&quot; style=&quot;position:absolute;left:-1000px;top:-1000px;&quot;&gt;
	&lt;script&gt;OA_show(&quot;728x90_Leaderboard&quot;);&lt;/script&gt;
&lt;/div&gt;
&lt;/body&gt;
</pre>
<p>Because  of the various use cases and implementations supported I do recommend OpenX,  but depending on the size and needs of your site/organization Google&#8217;s  offerings are far more robust and will eventually perform better than they do  now.</p>
<p><strong><a href="http://www.google.com/dfp/sb">Google  DoubleClick for Publishers</a> (formerly Google Ad manager):<br />
</strong>If your site is monetized with AdSense as well  as various types of ad formats or networks, Google DFP is a great solution,  however for now, it actually creates a negative experience for users depending  on the quantity and type of ads being displayed. Instead of embedding the  snippet in the &lt;head&gt; of the page, instead embed it after &lt;body&gt;  and make sure note that this implementation uses the single request command to  make the render more responsive:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;body&gt;
&lt;script src=&quot;http://partner.googleadservices.com/gampad/google_service.js&quot;&gt;&lt;/script&gt;
&lt;script&gt;GS_googleAddAdSenseService(&quot;ca-pub-XXXXXXXXXXXXXXXXX&quot;);GS_googleEnableAllServices();&lt;/script&gt;
&lt;script&gt;GA_googleAddSlot(&quot;ca-pub- XXXXXXXXXXXXXXXXX &quot;, &quot;slot-name&quot;);&lt;/script&gt;
&lt;script&gt;GA_googleUseSyncSRARendering();GA_googleFetchAds();&lt;/script&gt;
</pre>
<p>Then  place your ad slots as you normally would in your page template. I&#8217;m definitely  looking forward better performing implementation for Google DFP, ads are not  optional for many publishers today and ironically they are actually causing  publishers to <strong>lose</strong> money.</p>
<p><strong><a href="http://buysellads.com/">BuySellAds</a>:</strong><br />
If you monetize your site using BSA, and still have not switched to their <a href="http://blog.buysellads.com/2010/02/new-feature-non-blocking-asynchronous-ad-code/">asynchronous  embed code</a>, make sure you do, your users will appreciate seeing the content  they&#8217;re after without delay.</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script&gt;
(function(){
  var bsa = document.createElement(\'script\');
     bsa.type = \'text/javascript\';
     bsa.async = true;
     bsa.src = \'//s3.buysellads.com/ac/bsa.js\';
  (document.getElementsByTagName(\'head\')[0]||document.getElementsByTagName(\'body\')[0]).appendChild(bsa);
})();
&lt;/script&gt;
</pre>
<p>If  you don&#8217;t already use the asynchronous snippet, make sure you do!</p>
<p><strong><a href="http://www.google.com/analytics/">Google  Analytics</a>:</strong><br />
Google&#8217;s asynchronous tracking code has been out for some time, I recommend it  for lots of reasons, like:</p>
<ul>
<li>More accurate stats</li>
<li>Non-blocking user experience</li>
<li>Simplified implementation and optimized  execution</li>
<li>Capture partial page views</li>
</ul>
<p>So this is what the implementation looks like:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script&gt;
var _gaq = _gaq || [];
_gaq.push(
	[\'_setAccount\', \'UA-XXXXX-X\'],
	[\'_setDomainName\', \'domain.com\'],
	[\'_trackPageview\'] );
(function() {var ga = document.createElement(\'script\'); ga.type = \'text/javascript\'; ga.async = true;ga.src = (\'https:\' == document.location.protocol ? \'https://ssl\' : \'http://www\') + \'.google-analytics.com/ga.js\';document.getElementsByTagName(\'head\')[0] || document.getElementsByTagName(\'body\')[0]).appendChild(ga);})();
&lt;/script&gt;
&lt;/head&gt;
</pre>
<p><strong><a href="http://www.woopra.com/">Woopra</a>:</strong><br />
Woopra Analytics not only has a decent WordPress plugin, they also now have an  asynchronous tracking code implementation (which is not yet available in the  WordPress plugin at the time of this writing). Being that it&#8217;s actually asynchronous,  I recommend embedding it in the &lt;head&gt; of the page manually if you want to  capture partial page views:</p>
<pre class="brush: xml; title: ; notranslate">
&lt;script&gt;
(function(){
	var wsc=document.createElement(\'script\');
	wsc.type=\'text/javascript\';
	wsc.src=document.location.protocol+\'//static.woopra.com/js/woopra.js\';
	wsc.async=true;
	var ssc = document.getElementsByTagName(\'script\')[0];
	ssc.parentNode.insertBefore(wsc, ssc);
})();
&lt;/script&gt;
&lt;/head&gt;
</pre>
<p><strong>Wrapping Up:<br />
</strong>For those buttons, widgets, services etc not  covered one of the last remaining rules of thumb (within the scope of this  discussion) is to put all scripts that are not essential for functionality of  the site (like navigation, but hopefully that&#8217;s not the case) above  &lt;/body&gt; so that they&#8217;re not directly interfering with page render. Remember  all of the CSS and JS files that exist in &lt;head&gt; must be downloaded and  executed before the page can start to render. Note: your mileage may vary, but  it&#8217;s possible to realize asynchronous performance of some scripts by adding the  attribute async to the &lt;script&gt; tag with the value true. Keep in mind  that this make break a script so test for yourself.</p>
<p>There  are numerous other widgets, advertising networks, statistics and analytics  services available, if you don&#8217;t see a tip above for the one you use, then  reach out to them and find out if they have any performance tips (like  asynchronous JavaScript code). Also, don&#8217;t forget that if you are able to  minify scripts to reduce HTTP transactions, which will be a huge performance  win for scripts that support it.</p>
<p><strong>Bonus Tips for WordPress Users:</strong><br />
  <a href="http://jquery.com/">jQuery</a> is used in countless plugins and  themes. It&#8217;s often out-of-date and every new release includes bug fixes and more  importantly performance improvements. The following snippet is useful for your  header.php file, it will make sure that your site is always using the latest  version of jQuery without having to modify your theme. You&#8217;ll also benefit from  Google&#8217;s content delivery network and using a hostname other than your domain  name, meaning that the file will be pipelined (downloaded in parallel) with the  other files in the &lt;head&gt; of the page which is faster:</p>
<pre class="brush: php; title: ; notranslate">
&lt;?php
wp_deregister_script(\'jquery\');
wp_register_script(\'jquery\', \'http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js\');
wp_enqueue_script(\'jquery\');
?&gt;
</pre>
<p>Similarly,  if you have extensive use of <a href="http://code.google.com/p/swfobject/">swfobject</a> in your theme/plugins, a similar optimization can be applied thusly:</p>
<pre class="brush: php; title: ; notranslate">
&lt;?php
wp_deregister_script(\'swfobject\');
wp_register_script(\'swfobject\', \'http://ajax.googleapis.com/ajax/libs/swfobject/2/swfobject.js\');
wp_enqueue_script(\'swfobject\');
?&gt;
</pre>
<p>So  again, until jQuery reaches version 2 or swfobject reaches version 3, you will  never have to modify this code!</p>
<p>Have  a tip I didn&#8217;t mention? Let me know in the comments!</p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D8S9gY2WmME:qdSUS2InmRU:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D8S9gY2WmME:qdSUS2InmRU:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=D8S9gY2WmME:qdSUS2InmRU:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D8S9gY2WmME:qdSUS2InmRU:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=D8S9gY2WmME:qdSUS2InmRU:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D8S9gY2WmME:qdSUS2InmRU:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=D8S9gY2WmME:qdSUS2InmRU:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=D8S9gY2WmME:qdSUS2InmRU:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/D8S9gY2WmME" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:84:"http://www.w3-edge.com/weblog/2011/02/optimize-social-media-button-performance/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"97";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:79:"http://www.w3-edge.com/weblog/2011/02/optimize-social-media-button-performance/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:60:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Apple iPad, One Geeks Reaction";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://feedproxy.google.com/~r/W3EDGE/~3/KWICWCByriE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.w3-edge.com/weblog/2010/02/apple-ipad-reaction/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 08 Feb 2010 13:26:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:13:"Miscellaneous";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:10:"Technology";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"apple";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"geek";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:10:"innovation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:4:"ipad";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:19:"product development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://www.w3-edge.com/?p=651";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:306:"Companies today have a fine line to walk. Creating products that appeal to the lowest common denominator in terms of use cases (and consumer appeal) is the fundamental foothold upon which innovation stands. Apple has mastered that approach and we need to remember that their steps are conscientiously made.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:8904:"<p>I think <a href="http://profile.wpwidgets.net/plus/113493854651753327245">Mashable</a>&#8216;s Ben Parr made some solid points about <a href="http://mashable.com/2010/01/27/ipad/" rel="external nofollow">how Apple  introduces new products</a> into the marketplace. One thing he does not address is his opinion of the specific hardware spec&#8217;s that a hardcore geek would need to  see in an <a href="http://www.apple.com/ipad/" rel="external nofollow">Apple tablet</a>. After getting  over the fact that the development ecosystem is closed, the <a href="http://mashable.com/2010/01/07/apple-touchscreen-patent/" rel="external nofollow">Apple interface</a>, <a href="http://www.apple.com/itunes/" rel="external nofollow">iTunes</a> and the <a href="http://www.apple.com/iphone/iphone-3gs/app-store.html" rel="external nofollow">App&#8217; Store</a> are  essential pieces of the overall product value, that make it worth of attention.</p>
<p align="center"><img src="http://w3edge.w3totalcache.netdna-cdn.com/wp-content/uploads/2010/02/hardware-01-20100127-710x439.jpg" alt="" title="iPad" width="710" height="439" class="aligncenter size-large wp-image-662" style="border:0;" /></p>
<p>So what did I actually want to see  in terms of hardware? Let&#8217;s take a look:</p>
<ol>
<li>Albeit less essential (relatively speaking) <strong>wireless charging</strong> would certainly be a welcome feature. I don&#8217;t  mean that recent technology that <a href="http://www.ted.com/talks/eric_giler_demos_wireless_electricity.html" rel="external nofollow">powers  devices at a distance</a>, instead I&#8217;m referring to those pads that you put  your devices on that charges them. I&#8217;d like to invest in a <a href="http://www.powermat.com/us/mats/home-and-office-mat.html" rel="external nofollow">couple of those</a> and leave them around the house to keep devices juiced.</li>
<li>There are some truly <a href="http://www.emolabs.com/emoproducts/index.html" rel="external nofollow">innovative products</a> out there to provide much better audio without increasing weight or complexity  in devices. The iPad has a seemingly <strong>tiny mono speaker</strong>, that I&#8217;m confident is  going to leave me disappointed, whether giving a presentation or trying to  watch some <a href="http://www.ted.com/" rel="external nofollow">TED</a> videos.</li>
<li><strong>No camera</strong>?  That&#8217;s a good way to keep this from being a gift for non-tech savvy relatives  and being a living room fixture that actually stood a  chance of replacing the use of the mobile and landline phones (<a href="http://www.engadget.com/2010/01/27/apple-lifts-voip-over-cellular-restrictions-in-new-iphone-sdk/" rel="external nofollow">now  the Skype can make calls over 3G</a> or even <a href="http://about.skype.com/press/2010/01/new_era_in_face_to_face.html" rel="external nofollow">cumbersome  TVs</a>). No doubt that this is coming soon, but I think this was definitely a  foolish sacrifice for the first generation. Likely to be able to make the  battery life claims that are made without having to do too much research and  development or delaying release.</li>
<li><strong>HDMI</strong>,  without better audio, higher quality video etc, how am I going to enjoy the  videos etc that I happen to download or want to share on my iPad? So I can&#8217;t  pop over to a friend&#8217;s house and with a single cable pour out high definition  content into the flat screen TV that hangs on their wall? This is a real use  case even in business today. Not even a thought of this scenario? For shame.</li>
<li>I know the &#8220;<strong>stylus</strong>&#8221;  concept is a bit passé at this point, but not when it records what you&#8217;re  hearing while you make your notes, which are subsequently converted from  handwriting into actual documents. After all, <a title="unlock iphone 5" href="http://iphonefiveinfo.com/">apple</a> called this device the iPad right? This use case takes shape in nearly every  way you can imagine, and unlike <a href="http://www.livescribe.com/smartpen/index.html" rel="external nofollow">other products</a> that  exist, the data is already stored in a device (or easily synced) in such a way  that you can manipulate it easily.</li>
<li>The mobile landscape is changing with the  proliferation of free WIFI in communities and businesses, but the roll out of <strong>4G</strong> is also on the horizon by many service  providers as well. Granted, some mobile companies are admittedly removing the  bottlenecks from their 3G networks, but mobile standards must be backwards  compatible, so why not give a device that cannot be upgraded more longevity?</li>
<li>Only 802.11n support? What about the new &#8220;hub-less&#8221;  WIFI technology that allows <a href="http://www.engadget.com/2009/04/13/bluetooth-3-0-to-use-wifi-for-high-speed-file-transfers/" rel="external nofollow">wireless  devices to directly discover and interface with each other</a> at high speed?  Not having forward thinking features makes me think that this device is  supposed to be disposed of annually, I mean upgraded. And not the healthy upgrades  like swapping out modems or memory or disk, unhealthy ones where the entire  unit is tossed or sold on eBay if I somehow find the time.</li>
<li><strong>Bluetooth  3</strong>, where is that? There are already devices with the standard and most of  us gadget lovers already know that we still have a pairing and performance  issues with our Bluetooth networks as it is, even with the enhanced data rate  devices that are available now.</li>
<li>Video is actually key here, where is the <strong>1080p</strong>? Even <a href="http://www.youtube.com/" rel="external nofollow">youtube.com</a>, <a href="http://www.vimeo.com/" rel="external nofollow">vimeo.com</a> etc supports this standard now, how can this be missing today. The Simpson&#8217;s is  finally widescreen after 20 years, let&#8217;s keep taking steps forward.</li>
<li>One of my use cases is using the device for  travel, this includes in a car. However, I can&#8217;t use this for turn-by-turn  directions without a decent speaker, so I guess I will have to look at the  screen in that case? A bit dangerous. I guess this thing is going to remain in its  specially designed Apple carry case anyway since there&#8217;s <strong>no active GPS</strong>. <a href="http://www.garmin.com/garmin/cms/site/us/ontheroad/" rel="external nofollow">Garmin</a> can breath a sigh of relief.</li>
<li>The battery life is impressive, but at the  compromise (no doubt) of <strong>multi-tasking  support</strong>. So after completing that thought, the battery life is NOT  impressive. So where is multi-tasking support? Even my RIM BlackBerry 8800  could manage that even with its rubbish interface.</li>
</ol>
<p>For completeness I should mention that the lack of Flash  support is not a concern of mine, all of the <a href="http://youtube-global.blogspot.com/2010/01/introducing-youtube-html5-supported.html" rel="external nofollow">largest  videos sites</a> are supporting <a href="http://news.cnet.com/8301-27076_3-10439048-248.html?part=rss&amp;subj=news&amp;tag=2547-1_3-0-20" rel="external nofollow">HTML 5</a> as are the browsers that I love.</p>
<p>If having these features means that I have to spend more, I certainly  will. Knowing that subsequent operating system updates with richen my  productivity and allow for greater innovation in the app&#8217;s that are developed.  But what I won&#8217;t do is make compromises on these points unless I can find a  reason to compromise my use cases as well: presentations, travel, business  tasks, conferences/seminars etc. All of these uses cases (and more) demand a  device of the description I&#8217;ve made. We&#8217;ll see if Apple will ever cater to such  a small sector of their market, the hardcore.</p>
<div class="feedflare">
<a href="http://feeds.feedburner.com/~ff/W3EDGE?a=KWICWCByriE:hOAXAVyZZJ0:yIl2AUoC8zA"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=yIl2AUoC8zA" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=KWICWCByriE:hOAXAVyZZJ0:D7DqB2pKExk"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=KWICWCByriE:hOAXAVyZZJ0:D7DqB2pKExk" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=KWICWCByriE:hOAXAVyZZJ0:F7zBnMyn0Lo"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=KWICWCByriE:hOAXAVyZZJ0:F7zBnMyn0Lo" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=KWICWCByriE:hOAXAVyZZJ0:qj6IDK7rITs"><img src="http://feeds.feedburner.com/~ff/W3EDGE?d=qj6IDK7rITs" border="0"></img></a> <a href="http://feeds.feedburner.com/~ff/W3EDGE?a=KWICWCByriE:hOAXAVyZZJ0:gIN9vFwOqvQ"><img src="http://feeds.feedburner.com/~ff/W3EDGE?i=KWICWCByriE:hOAXAVyZZJ0:gIN9vFwOqvQ" border="0"></img></a>
</div><img src="http://feeds.feedburner.com/~r/W3EDGE/~4/KWICWCByriE" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://www.w3-edge.com/weblog/2010/02/apple-ipad-reaction/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"25";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:58:"http://www.w3-edge.com/weblog/2010/02/apple-ipad-reaction/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:28:"http://www.w3.org/1999/xhtml";a:1:{s:4:"meta";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"name";s:6:"robots";s:7:"content";s:7:"noindex";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:3:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:34:"http://feeds.feedburner.com/W3EDGE";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:28:"http://superfeedr.com/hubbub";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:4:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:6:"w3edge";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:6:"W3EDGE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:28:"http://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"feedFlare";a:4:{i:0;a:5:{s:4:"data";s:24:"Subscribe with My Yahoo!";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:74:"http://add.my.yahoo.com/rss?url=http%3A%2F%2Ffeeds.feedburner.com%2FW3EDGE";s:3:"src";s:59:"http://us.i1.yimg.com/us.yimg.com/i/us/my/addtomyyahoo4.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:21:"Subscribe with My AOL";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:78:"http://feeds.my.aol.com/add.jsp?url=http%3A%2F%2Ffeeds.feedburner.com%2FW3EDGE";s:3:"src";s:108:"http://o.aolcdn.com/favorites.my.aol.com/webmaster/ffclient/webroot/locale/en-US/images/myAOLButtonSmall.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:23:"Subscribe with Netvibes";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:84:"http://www.netvibes.com/subscribe.php?url=http%3A%2F%2Ffeeds.feedburner.com%2FW3EDGE";s:3:"src";s:44:"http://www.netvibes.com/img/add2netvibes.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:21:"Subscribe with Google";s:7:"attribs";a:1:{s:0:"";a:2:{s:4:"href";s:79:"http://fusion.google.com/add?feedurl=http%3A%2F%2Ffeeds.feedburner.com%2FW3EDGE";s:3:"src";s:51:"http://buttons.googlesyndication.com/fusion/add.gif";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:52:"http://backend.userland.com/creativeCommonsRssModule";a:1:{s:7:"license";a:1:{i:0;a:5:{s:4:"data";s:46:"http://creativecommons.org/licenses/by-sa/3.0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"1+OKtyELizAD2jF1FuOwb6YtcBM";s:13:"last-modified";s:29:"Mon, 16 Dec 2013 00:17:20 GMT";s:4:"date";s:29:"Mon, 16 Dec 2013 02:17:07 GMT";s:7:"expires";s:29:"Mon, 16 Dec 2013 02:17:07 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";}s:5:"build";s:14:"20130911090210";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1368, '_transient_timeout_feed_mod_4fee809661d1b035d98b93142a587416', '1387203428', 'no') ; 
INSERT INTO `wp_options` VALUES (1369, '_transient_feed_mod_4fee809661d1b035d98b93142a587416', '1387160228', 'no') ; 
INSERT INTO `wp_options` VALUES (1370, '_transient_timeout_dash_54e0612bb2ce53db0827d5e7c3c1b7dc', '1387203428', 'no') ; 
INSERT INTO `wp_options` VALUES (1371, '_transient_dash_54e0612bb2ce53db0827d5e7c3c1b7dc', '<h4>
	<a href="http://feedproxy.google.com/~r/W3EDGE/~3/dcqMeozVVyU/">Announcing W3 Total Cache Pro</a>
</h4>
<h4>
	<a href="http://feedproxy.google.com/~r/W3EDGE/~3/D6uNPwMc3MU/">Security &amp; W3 Total Cache 0.9.2.4</a>
</h4>
<h4>
	<a href="http://feedproxy.google.com/~r/W3EDGE/~3/uPZ-1anZcvs/">WPO &amp; GoDaddy: How to configure W3 Total Cache and APC</a>
</h4>
<h4>
	<a href="http://feedproxy.google.com/~r/W3EDGE/~3/roTCgklYEgQ/">W3 Total Cache Version 0.9.2.5</a>
</h4>
<h4>
	<a href="http://feedproxy.google.com/~r/W3EDGE/~3/2fKM3LtVHUk/">The Magic of Brand Building: Cultivating 3rd Party Credibility</a>
</h4>

<p style="text-align: center;">
	<a href="http://feeds.feedburner.com/W3EDGE" target="_blank">View Feed</a>
</p>
', 'no') ; 
INSERT INTO `wp_options` VALUES (1386, 'rewrite_rules', 'a:68:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1392, '_site_transient_timeout_browser_e5cb6a6276a8822c8b03a27bac3cfc6c', '1387837861', 'yes') ; 
INSERT INTO `wp_options` VALUES (1393, '_site_transient_browser_e5cb6a6276a8822c8b03a27bac3cfc6c', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.63";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1430, '_site_transient_timeout_browser_2a9e0170df24a3894a25ceeae8e8ea29', '1388006714', 'yes') ; 
INSERT INTO `wp_options` VALUES (1431, '_site_transient_browser_2a9e0170df24a3894a25ceeae8e8ea29', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:11:"34.0.1751.0";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1594, '_site_transient_timeout_browser_8b7535adeddc223aa9c8b2b378cdf189', '1389117435', 'yes') ; 
INSERT INTO `wp_options` VALUES (1595, '_site_transient_browser_8b7535adeddc223aa9c8b2b378cdf189', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.63";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1596, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1388523450', 'yes') ; 
INSERT INTO `wp_options` VALUES (1597, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1598, '_site_transient_timeout_theme_roots', '1388514484', 'yes') ; 
INSERT INTO `wp_options` VALUES (1599, '_site_transient_theme_roots', 'a:1:{s:5:"Roots";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1600, 'hmbkp_default_path', '/Applications/MAMP/htdocs/wordpress1/wp-content/backupwordpress-3470e7b009-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (1601, 'hmbkp_path', '/Applications/MAMP/htdocs/wordpress1/wp-content/backupwordpress-3470e7b009-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (1602, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1603, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1604, 'hmbkp_plugin_version', '2.3.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (1605, '_transient_timeout_hmbkp_plugin_data', '1388599302', 'no') ; 
INSERT INTO `wp_options` VALUES (1606, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":19:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:5:"2.3.3";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:37:"http://profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:39:"http://profiles.wordpress.org/humanmade";s:7:"willmot";s:37:"http://profiles.wordpress.org/willmot";s:13:"pauldewouters";s:43:"http://profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:38:"http://profiles.wordpress.org/joehoyle";s:7:"mattheu";s:37:"http://profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:39:"http://profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.3.3";s:6:"tested";s:5:"3.6.1";s:13:"compatibility";a:1:{s:3:"3.8";a:1:{s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}}s:6:"rating";d:91;s:11:"num_ratings";i:573;s:10:"downloaded";i:768330;s:12:"last_updated";s:10:"2013-08-22";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:30:"http://hmn.md/backupwordpress/";s:8:"sections";a:5:{s:11:"description";s:1284:"<p>BackUpWordPress will back up your entire site including your database and all your files on a schedule that suits you.</p>

<h4>Features</h4>

<ul>
<li>Manage multiple schedules.</li>
<li>Super simple to use, no setup required.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster back ups if they are available.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your back ups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:765:"<ol>
	<li>
		<img class=\'screenshot\' src=\'http://s-plugins.wordpress.org/backupwordpress/assets/screenshot-1.png?rev=602026\' alt=\'backupwordpress screenshot 1\' />
		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<img class=\'screenshot\' src=\'http://s-plugins.wordpress.org/backupwordpress/assets/screenshot-2.png?rev=602026\' alt=\'backupwordpress screenshot 2\' />
		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<img class=\'screenshot\' src=\'http://s-plugins.wordpress.org/backupwordpress/assets/screenshot-3.png?rev=602026\' alt=\'backupwordpress screenshot 3\' />
		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:27461:"<h4>2.3.3</h4>

<ul>
<li>Add missing colorbox assets</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error</li>
<li>Save and close as separate buttons</li>
<li>Fix bug that caused multiple notification emails</li>
<li>Fixes typo in database option name</li>
<li>Updated translations</li>
<li>Improve PHP docblocks</li>
<li>Make schedules class a singleton</li>
<li>Exclude popular backup plugin folders by default</li>
<li>Exclude version control folders by default</li>
<li>Fix broken localisation</li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4053:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.3.3.zip";s:4:"tags";a:10:{s:7:"archive";s:7:"archive";s:7:"back-up";s:7:"back up";s:6:"backup";s:6:"backup";s:7:"backups";s:7:"backups";s:8:"database";s:8:"database";s:2:"db";s:2:"db";s:5:"files";s:5:"files";s:9:"humanmade";s:9:"humanmade";s:6:"wp-cli";s:6:"wp-cli";s:3:"zip";s:3:"zip";}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `wp_options` VALUES (1607, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2777112206', 'no') ; 
INSERT INTO `wp_options` VALUES (1608, '_transient_hmbkp_schedule_default-1_filesize', '1590376', 'no') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=500 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (199 records)
#
 
INSERT INTO `wp_postmeta` VALUES (36, 4, '_edit_lock', '1386795116:1') ; 
INSERT INTO `wp_postmeta` VALUES (49, 4, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (50, 4, '_wp_page_template', 'template-custom.php') ; 
INSERT INTO `wp_postmeta` VALUES (84, 36, '_pfund_camp-location', '36') ; 
INSERT INTO `wp_postmeta` VALUES (85, 36, '_pfund_camp-title', '') ; 
INSERT INTO `wp_postmeta` VALUES (88, 36, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (89, 36, '_pfund_cause_id', '35') ; 
INSERT INTO `wp_postmeta` VALUES (90, 36, '_pfund_end-date', '2013-12-25') ; 
INSERT INTO `wp_postmeta` VALUES (91, 36, '_pfund_gift-goal', '25') ; 
INSERT INTO `wp_postmeta` VALUES (92, 36, '_pfund_gift-tally', '0') ; 
INSERT INTO `wp_postmeta` VALUES (93, 36, '_pfund_giver-tally', '1') ; 
INSERT INTO `wp_postmeta` VALUES (94, 36, '_edit_lock', '1381020881:1') ; 
INSERT INTO `wp_postmeta` VALUES (95, 35, '_edit_lock', '1381022431:1') ; 
INSERT INTO `wp_postmeta` VALUES (96, 35, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (99, 35, '_pfund_cause_image', '39') ; 
INSERT INTO `wp_postmeta` VALUES (100, 35, '_pfund_cause_description', 'This is isisisisisisis') ; 
INSERT INTO `wp_postmeta` VALUES (101, 35, '_pfund_cause_default_goal', '2000') ; 
INSERT INTO `wp_postmeta` VALUES (102, 44, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (103, 44, '_edit_lock', '1381022868:1') ; 
INSERT INTO `wp_postmeta` VALUES (104, 44, '_pfund_cause_description', 'Hello') ; 
INSERT INTO `wp_postmeta` VALUES (105, 44, '_pfund_cause_default_goal', '5000') ; 
INSERT INTO `wp_postmeta` VALUES (131, 53, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (132, 53, '_edit_lock', '1381028259:1') ; 
INSERT INTO `wp_postmeta` VALUES (170, 53, 'edd_price', '0.00') ; 
INSERT INTO `wp_postmeta` VALUES (171, 53, '_variable_pricing', '1') ; 
INSERT INTO `wp_postmeta` VALUES (172, 53, '_edd_price_options_mode', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (173, 53, 'edd_variable_prices', 'a:1:{i:0;a:4:{s:4:"name";s:8:"Donation";s:6:"amount";s:1:"0";s:5:"limit";s:0:"";s:6:"bought";s:1:"0";}}') ; 
INSERT INTO `wp_postmeta` VALUES (174, 53, 'edd_download_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (175, 53, '_edd_bundled_products', 'a:1:{i:0;s:2:"-1";}') ; 
INSERT INTO `wp_postmeta` VALUES (176, 53, '_edd_button_behavior', 'add_to_cart') ; 
INSERT INTO `wp_postmeta` VALUES (177, 53, 'campaign_goal', '2000.00') ; 
INSERT INTO `wp_postmeta` VALUES (178, 53, 'campaign_end_date', '2013-11-06 02:25:49') ; 
INSERT INTO `wp_postmeta` VALUES (179, 53, 'campaign_location', 'New York,NY') ; 
INSERT INTO `wp_postmeta` VALUES (180, 53, 'campaign_author', 'Michael') ; 
INSERT INTO `wp_postmeta` VALUES (181, 53, 'campaign_type', 'donation') ; 
INSERT INTO `wp_postmeta` VALUES (182, 53, '_campaign_physical', '1') ; 
INSERT INTO `wp_postmeta` VALUES (215, 53, 'campaign_norewards', '1') ; 
INSERT INTO `wp_postmeta` VALUES (216, 53, 'campaign_updates', 'New Items added daily') ; 
INSERT INTO `wp_postmeta` VALUES (219, 53, '_edd_download_earnings', '0') ; 
INSERT INTO `wp_postmeta` VALUES (220, 53, '_edd_download_sales', '0') ; 
INSERT INTO `wp_postmeta` VALUES (243, 74, 'campaign_goal', '10000.00') ; 
INSERT INTO `wp_postmeta` VALUES (244, 74, 'campaign_end_date', '2013-11-03 03:25:22') ; 
INSERT INTO `wp_postmeta` VALUES (245, 74, 'campaign_length', '28') ; 
INSERT INTO `wp_postmeta` VALUES (246, 74, '_campaign_physical', '1') ; 
INSERT INTO `wp_postmeta` VALUES (247, 74, 'campaign_norewards', '1') ; 
INSERT INTO `wp_postmeta` VALUES (248, 74, 'edd_variable_prices', 'a:1:{i:0;a:4:{s:4:"name";s:8:"Donation";s:6:"amount";s:1:"0";s:5:"limit";s:0:"";s:6:"bought";s:1:"0";}}') ; 
INSERT INTO `wp_postmeta` VALUES (249, 74, '_variable_pricing', '1') ; 
INSERT INTO `wp_postmeta` VALUES (250, 74, '_edd_price_options_mode', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (251, 74, '_edd_hide_purchase_link', '1') ; 
INSERT INTO `wp_postmeta` VALUES (252, 74, '_edit_lock', '1381029984:1') ; 
INSERT INTO `wp_postmeta` VALUES (253, 74, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (254, 74, 'edd_price', '0.00') ; 
INSERT INTO `wp_postmeta` VALUES (255, 74, 'edd_download_files', 'a:0:{}') ; 
INSERT INTO `wp_postmeta` VALUES (256, 74, '_edd_bundled_products', 'a:1:{i:0;s:2:"-1";}') ; 
INSERT INTO `wp_postmeta` VALUES (257, 74, '_edd_button_behavior', 'add_to_cart') ; 
INSERT INTO `wp_postmeta` VALUES (258, 74, 'campaign_location', 'New York,NY') ; 
INSERT INTO `wp_postmeta` VALUES (259, 74, 'campaign_type', 'donation') ; 
INSERT INTO `wp_postmeta` VALUES (280, 80, '_edd_payment_meta', 'a:6:{s:8:"currency";s:3:"USD";s:9:"downloads";s:98:"a:1:{i:0;a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}}";s:9:"user_info";s:151:"a:6:{s:2:"id";i:1;s:5:"email";s:22:"michael.wiss@gmail.com";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:8:"discount";s:0:"";s:7:"address";a:0:{}}";s:12:"cart_details";s:214:"a:1:{i:0;a:5:{s:4:"name";s:15:"Hungerthon 2013";s:2:"id";s:2:"74";s:11:"item_number";a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}s:5:"price";s:1:"0";s:8:"quantity";i:1;}}";s:3:"tax";i:0;s:9:"anonymous";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (281, 80, '_edd_payment_user_id', '1') ; 
INSERT INTO `wp_postmeta` VALUES (282, 80, '_edd_payment_user_email', 'michael.wiss@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (283, 80, '_edd_payment_user_ip', '::1') ; 
INSERT INTO `wp_postmeta` VALUES (284, 80, '_edd_payment_purchase_key', '441c07cb7483eb2f5f9d94316d29e6bd') ; 
INSERT INTO `wp_postmeta` VALUES (285, 80, '_edd_payment_total', '0') ; 
INSERT INTO `wp_postmeta` VALUES (286, 80, '_edd_payment_mode', 'live') ; 
INSERT INTO `wp_postmeta` VALUES (287, 80, '_edd_payment_gateway', 'paypal') ; 
INSERT INTO `wp_postmeta` VALUES (288, 81, 'campaign_goal', '9000') ; 
INSERT INTO `wp_postmeta` VALUES (289, 81, 'campaign_end_date', '2013-11-03 03:32:04') ; 
INSERT INTO `wp_postmeta` VALUES (290, 81, 'campaign_length', '28') ; 
INSERT INTO `wp_postmeta` VALUES (291, 81, '_campaign_physical', '1') ; 
INSERT INTO `wp_postmeta` VALUES (292, 81, 'campaign_norewards', '1') ; 
INSERT INTO `wp_postmeta` VALUES (293, 81, 'edd_variable_prices', 'a:1:{i:0;a:4:{s:4:"name";s:8:"Donation";s:6:"amount";i:0;s:5:"limit";N;s:6:"bought";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (294, 81, '_variable_pricing', '1') ; 
INSERT INTO `wp_postmeta` VALUES (295, 81, '_edd_price_options_mode', '1') ; 
INSERT INTO `wp_postmeta` VALUES (296, 81, '_edd_hide_purchase_link', 'on') ; 
INSERT INTO `wp_postmeta` VALUES (297, 81, '_edit_lock', '1381030343:1') ; 
INSERT INTO `wp_postmeta` VALUES (304, 84, '_edd_payment_meta', 'a:7:{s:8:"currency";s:3:"USD";s:9:"downloads";s:98:"a:1:{i:0;a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}}";s:9:"user_info";s:151:"a:6:{s:2:"id";i:1;s:5:"email";s:22:"michael.wiss@gmail.com";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:8:"discount";s:0:"";s:7:"address";a:0:{}}";s:12:"cart_details";s:214:"a:1:{i:0;a:5:{s:4:"name";s:15:"Hungerthon 2013";s:2:"id";s:2:"74";s:11:"item_number";a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}s:5:"price";s:1:"0";s:8:"quantity";i:1;}}";s:3:"tax";i:0;s:8:"shipping";a:6:{s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:13:"shipping_city";s:0:"";s:16:"shipping_country";s:0:"";s:14:"shipping_state";s:0:"";s:12:"shipping_zip";s:0:"";}s:9:"anonymous";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (305, 84, '_edd_payment_user_id', '1') ; 
INSERT INTO `wp_postmeta` VALUES (306, 84, '_edd_payment_user_email', 'michael.wiss@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (307, 84, '_edd_payment_user_ip', '::1') ; 
INSERT INTO `wp_postmeta` VALUES (308, 84, '_edd_payment_purchase_key', 'c68aa83c893f0114dea7d258ccd1f55e') ; 
INSERT INTO `wp_postmeta` VALUES (309, 84, '_edd_payment_total', '0') ; 
INSERT INTO `wp_postmeta` VALUES (310, 84, '_edd_payment_mode', 'live') ; 
INSERT INTO `wp_postmeta` VALUES (311, 84, '_edd_payment_gateway', 'paypal') ; 
INSERT INTO `wp_postmeta` VALUES (318, 89, '_edd_payment_meta', 'a:6:{s:8:"currency";s:3:"USD";s:9:"downloads";s:98:"a:1:{i:0;a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}}";s:9:"user_info";s:151:"a:6:{s:2:"id";i:1;s:5:"email";s:22:"michael.wiss@gmail.com";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:8:"discount";s:0:"";s:7:"address";a:0:{}}";s:12:"cart_details";s:214:"a:1:{i:0;a:5:{s:4:"name";s:15:"Hungerthon 2013";s:2:"id";s:2:"74";s:11:"item_number";a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}s:5:"price";s:1:"0";s:8:"quantity";i:1;}}";s:3:"tax";i:0;s:9:"anonymous";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (319, 89, '_edd_payment_user_id', '1') ; 
INSERT INTO `wp_postmeta` VALUES (320, 89, '_edd_payment_user_email', 'michael.wiss@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (321, 89, '_edd_payment_user_ip', '::1') ; 
INSERT INTO `wp_postmeta` VALUES (322, 89, '_edd_payment_purchase_key', '4857819b894b6b944d6382eb174271a0') ; 
INSERT INTO `wp_postmeta` VALUES (323, 89, '_edd_payment_total', '0') ; 
INSERT INTO `wp_postmeta` VALUES (324, 89, '_edd_payment_mode', 'live') ; 
INSERT INTO `wp_postmeta` VALUES (325, 89, '_edd_payment_gateway', 'paypal') ; 
INSERT INTO `wp_postmeta` VALUES (326, 91, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (327, 91, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (328, 91, '_menu_item_object_id', '91') ; 
INSERT INTO `wp_postmeta` VALUES (329, 91, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (330, 91, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (331, 91, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (332, 91, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (333, 91, '_menu_item_url', 'http://localhost/wordpress1/#accordion2') ; 
INSERT INTO `wp_postmeta` VALUES (335, 92, '_edd_payment_meta', 'a:6:{s:8:"currency";s:3:"USD";s:9:"downloads";s:98:"a:1:{i:0;a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}}";s:9:"user_info";s:151:"a:6:{s:2:"id";i:1;s:5:"email";s:22:"michael.wiss@gmail.com";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:8:"discount";s:0:"";s:7:"address";a:0:{}}";s:12:"cart_details";s:214:"a:1:{i:0;a:5:{s:4:"name";s:15:"Hungerthon 2013";s:2:"id";s:2:"74";s:11:"item_number";a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}s:5:"price";s:1:"0";s:8:"quantity";i:1;}}";s:3:"tax";i:0;s:9:"anonymous";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (336, 92, '_edd_payment_user_id', '1') ; 
INSERT INTO `wp_postmeta` VALUES (337, 92, '_edd_payment_user_email', 'michael.wiss@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (338, 92, '_edd_payment_user_ip', '::1') ; 
INSERT INTO `wp_postmeta` VALUES (339, 92, '_edd_payment_purchase_key', '1d5fbb4a0ac59b2d3ffb4ea398c75d24') ; 
INSERT INTO `wp_postmeta` VALUES (340, 92, '_edd_payment_total', '0') ; 
INSERT INTO `wp_postmeta` VALUES (341, 92, '_edd_payment_mode', 'live') ; 
INSERT INTO `wp_postmeta` VALUES (342, 92, '_edd_payment_gateway', 'paypal') ; 
INSERT INTO `wp_postmeta` VALUES (343, 95, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (344, 95, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (345, 95, '_menu_item_object_id', '95') ; 
INSERT INTO `wp_postmeta` VALUES (346, 95, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (347, 95, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (348, 95, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (349, 95, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (350, 95, '_menu_item_url', 'http://localhost/wordpress1/#mid') ; 
INSERT INTO `wp_postmeta` VALUES (352, 96, '_edd_payment_meta', 'a:6:{s:8:"currency";s:3:"USD";s:9:"downloads";s:98:"a:1:{i:0;a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}}";s:9:"user_info";s:151:"a:6:{s:2:"id";i:1;s:5:"email";s:22:"michael.wiss@gmail.com";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:8:"discount";s:0:"";s:7:"address";a:0:{}}";s:12:"cart_details";s:214:"a:1:{i:0;a:5:{s:4:"name";s:15:"Hungerthon 2013";s:2:"id";s:2:"74";s:11:"item_number";a:2:{s:2:"id";s:2:"74";s:7:"options";a:2:{s:8:"price_id";s:1:"0";s:6:"amount";s:1:"0";}}s:5:"price";s:1:"0";s:8:"quantity";i:1;}}";s:3:"tax";i:0;s:9:"anonymous";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (353, 96, '_edd_payment_user_id', '1') ; 
INSERT INTO `wp_postmeta` VALUES (354, 96, '_edd_payment_user_email', 'michael.wiss@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (355, 96, '_edd_payment_user_ip', '::1') ; 
INSERT INTO `wp_postmeta` VALUES (356, 96, '_edd_payment_purchase_key', '40213ad62f70c8fdad06fafa333ab3d5') ; 
INSERT INTO `wp_postmeta` VALUES (357, 96, '_edd_payment_total', '0') ; 
INSERT INTO `wp_postmeta` VALUES (358, 96, '_edd_payment_mode', 'live') ; 
INSERT INTO `wp_postmeta` VALUES (359, 96, '_edd_payment_gateway', 'paypal') ; 
INSERT INTO `wp_postmeta` VALUES (360, 97, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (361, 97, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (362, 97, '_menu_item_object_id', '97') ; 
INSERT INTO `wp_postmeta` VALUES (363, 97, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (364, 97, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (365, 97, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (366, 97, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (367, 97, '_menu_item_url', 'http://localhost/wordpress1/#nav') ; 
INSERT INTO `wp_postmeta` VALUES (398, 114, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (399, 114, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (400, 114, '_menu_item_object_id', '114') ; 
INSERT INTO `wp_postmeta` VALUES (401, 114, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (402, 114, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (403, 114, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (404, 114, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (405, 114, '_menu_item_url', 'http://localhost/wordpress1/#blurred') ; 
INSERT INTO `wp_postmeta` VALUES (406, 116, '_form', '<p>[text* your-name placeholder "First and Last Name"] </p>

<p>[email* your-email placeholder "Email Address"] </p>

<p>[text your-subject placeholder "Subject"] </p>

<p>[textarea your-message placeholder "Please leave us a short message."] </p>

<p>[submit "Send"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (407, 116, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:177:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Michael Wiss (http://localhost/wordpress1)";s:9:"recipient";s:22:"michael.wiss@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (408, 116, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:119:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Michael Wiss (http://localhost/wordpress1)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (409, 116, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";}') ; 
INSERT INTO `wp_postmeta` VALUES (410, 116, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (411, 116, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (412, 118, '_form', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (413, 118, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:177:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Michael Wiss (http://localhost/wordpress1)";s:9:"recipient";s:22:"michael.wiss@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (414, 118, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:119:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Michael Wiss (http://localhost/wordpress1)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (415, 118, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";}') ; 
INSERT INTO `wp_postmeta` VALUES (416, 118, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (417, 118, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (418, 127, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (419, 127, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (420, 127, '_menu_item_object_id', '127') ; 
INSERT INTO `wp_postmeta` VALUES (421, 127, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (422, 127, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (423, 127, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (424, 127, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (425, 127, '_menu_item_url', 'http://localhost/wordpress1/#green') ; 
INSERT INTO `wp_postmeta` VALUES (427, 128, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (428, 128, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (429, 128, '_menu_item_object_id', '128') ; 
INSERT INTO `wp_postmeta` VALUES (430, 128, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (431, 128, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (432, 128, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (433, 128, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (434, 128, '_menu_item_url', 'http://localhost/wordpress1/#services') ; 
INSERT INTO `wp_postmeta` VALUES (436, 129, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (437, 129, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (438, 129, '_menu_item_object_id', '129') ; 
INSERT INTO `wp_postmeta` VALUES (439, 129, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (440, 129, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (441, 129, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (442, 129, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (443, 129, '_menu_item_url', 'http://localhost/wordpress1/#map') ; 
INSERT INTO `wp_postmeta` VALUES (451, 134, '_wp_attached_file', 'Cinema_Display_27in.png') ; 
INSERT INTO `wp_postmeta` VALUES (452, 134, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:700;s:6:"height";i:556;s:4:"file";s:23:"Cinema_Display_27in.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:31:"Cinema_Display_27in-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:10:"wp_smushit";s:26:"Bad response from Smush.it";}s:6:"medium";a:5:{s:4:"file";s:31:"Cinema_Display_27in-300x238.png";s:5:"width";i:300;s:6:"height";i:238;s:9:"mime-type";s:9:"image/png";s:10:"wp_smushit";s:26:"Bad response from Smush.it";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:10:"wp_smushit";s:26:"Bad response from Smush.it";}') ; 
INSERT INTO `wp_postmeta` VALUES (465, 139, '_wp_attached_file', 'iPhone_5.png') ; 
INSERT INTO `wp_postmeta` VALUES (466, 139, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:300;s:6:"height";i:300;s:4:"file";s:12:"iPhone_5.png";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"iPhone_5-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:10:"wp_smushit";s:26:"Bad response from Smush.it";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:10:"wp_smushit";s:26:"Bad response from Smush.it";}') ; 
INSERT INTO `wp_postmeta` VALUES (467, 140, '_wp_attached_file', 'iPhone_5a.png') ; 
INSERT INTO `wp_postmeta` VALUES (468, 140, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:500;s:6:"height";i:500;s:4:"file";s:13:"iPhone_5a.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:21:"iPhone_5a-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:10:"wp_smushit";s:26:"Bad response from Smush.it";}s:6:"medium";a:5:{s:4:"file";s:21:"iPhone_5a-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:10:"wp_smushit";s:26:"Bad response from Smush.it";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:10:"wp_smushit";s:26:"Bad response from Smush.it";}') ; 
INSERT INTO `wp_postmeta` VALUES (469, 141, '_wp_attached_file', 'Michael-Wiss_2013.pdf') ; 
INSERT INTO `wp_postmeta` VALUES (476, 145, '_wp_attached_file', 'iPad.png') ; 
INSERT INTO `wp_postmeta` VALUES (477, 145, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:800;s:4:"file";s:8:"iPad.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"iPad-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"iPad-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (480, 147, '_wp_attached_file', 'Untitled-1.png') ; 
INSERT INTO `wp_postmeta` VALUES (481, 147, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1170;s:6:"height";i:470;s:4:"file";s:14:"Untitled-1.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"Untitled-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:22:"Untitled-1-300x120.png";s:5:"width";i:300;s:6:"height";i:120;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:23:"Untitled-1-1024x411.png";s:5:"width";i:1024;s:6:"height";i:411;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (487, 149, '_wp_attached_file', '121610-33-e1387401833667.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (488, 149, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1125;s:4:"file";s:28:"121610-33-e1387401833667.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"121610-33-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"121610-33-300x168.jpg";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"121610-33-1024x575.jpg";s:5:"width";i:1024;s:6:"height";i:575;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (489, 150, '_wp_attached_file', 'Blurred-city-lights488-e1387402563507.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (490, 150, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1329;s:4:"file";s:41:"Blurred-city-lights488-e1387402563507.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"Blurred-city-lights488-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"Blurred-city-lights488-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:35:"Blurred-city-lights488-1024x680.jpg";s:5:"width";i:1024;s:6:"height";i:680;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (491, 151, '_wp_attached_file', 'gg_shadow00-82620132-1024x576.png') ; 
INSERT INTO `wp_postmeta` VALUES (492, 151, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:576;s:4:"file";s:33:"gg_shadow00-82620132-1024x576.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:41:"gg_shadow00-82620132-1024x576-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:41:"gg_shadow00-82620132-1024x576-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (493, 149, '_edit_lock', '1387402611:1') ; 
INSERT INTO `wp_postmeta` VALUES (494, 149, '_wp_attachment_backup_sizes', 'a:1:{s:9:"full-orig";a:3:{s:5:"width";i:3556;s:6:"height";i:2000;s:4:"file";s:13:"121610-33.jpg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (495, 149, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (496, 150, '_edit_lock', '1387402589:1') ; 
INSERT INTO `wp_postmeta` VALUES (497, 150, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (498, 150, '_wp_attachment_backup_sizes', 'a:1:{s:9:"full-orig";a:3:{s:5:"width";i:3000;s:6:"height";i:1994;s:4:"file";s:26:"Blurred-city-lights488.jpg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (499, 151, '_edit_lock', '1387402631:1') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (54 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2013-09-18 23:45:13', '2013-09-18 23:45:13', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2013-09-18 23:45:13', '2013-09-18 23:45:13', '', 0, 'http://localhost/wordpress1/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2013-09-18 23:46:16', '2013-09-18 23:46:16', '<div class="container">
<div class="row">
<div class="text" >Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

</div></div</div>', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2013-11-18 22:46:31', '2013-11-18 22:46:31', '', 0, 'http://localhost/wordpress1/?page_id=4', -1, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2013-09-18 23:46:16', '2013-09-18 23:46:16', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arcu adipiscing imperdiet vitae sit amet neque. Integer eu lectus et nunc dictum sagittis. Curabitur commodo vulputate fringilla. Sed eleifend, arcu convallis adipiscing congue, dui turpis commodo magna, et vehicula sapien turpis sit amet nisi.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2013-09-18 23:46:16', '2013-09-18 23:46:16', '', 4, 'http://localhost/wordpress1/?p=5', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2013-09-19 20:43:02', '2013-09-19 20:43:02', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc<code>u adipiscing imperdiet vitae sit amet neque. Integer eu lectus et nunc dictum sagittis. Curabitur commodo vulputate fringilla. Sed eleifend, arcu convallis adipiscing congue, dui turpis commodo magna, et vehicula sapien turpis sit amet nisi.', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2013-09-19 20:43:02', '2013-09-19 20:43:02', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2013-09-19 21:33:55', '2013-09-19 21:33:55', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc<code>
</code>', 'Home', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2013-09-19 21:33:55', '2013-09-19 21:33:55', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2013-10-06 00:53:09', '2013-10-06 00:53:09', '', 'Causes Listing', '', 'publish', 'closed', 'closed', '', '_causes_listing', '', '', '2013-10-06 00:53:09', '2013-10-06 00:53:09', '', 0, 'http://localhost/wordpress1/postname/', 0, 'pfund_cause_list', '', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2013-10-06 00:53:09', '2013-10-06 00:53:09', '', 'Campaign Listing', '', 'publish', 'closed', 'closed', '', '_campaign_listing', '', '', '2013-10-06 00:53:09', '2013-10-06 00:53:09', '', 0, 'http://localhost/wordpress1/postname/', 0, 'pfund_campaign_list', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2013-10-06 00:53:09', '2013-10-06 00:53:09', '<ul>
	<li class="pfund-stat"><span class="highlight">$[pfund-gift-goal]</span>funding goal</li>
	<li class="pfund-stat"><span class="highlight">$[pfund-gift-tally]</span>raised</li>
	<li class="pfund-stat"><span class="highlight">[pfund-giver-tally]</span>givers</li>
	<li class="pfund-stat"><span class="highlight">[pfund-days-left]</span>days left</li>
	<li class="pfund-stat">$[pfund-camp-title]</li>
</ul>
<div style="clear: both;">

I have an event on [pfund-end-date] that I am involved with for my cause.

I am hoping to raise $[pfund-gift-goal] for my cause.

So far I have raised $[pfund-gift-tally]. If you would like to contribute to my cause, click on the donate button below:

[pfund-donate]

</div>
[pfund-edit]', 'Help Raise Money For My Cause', '', 'publish', 'closed', 'closed', '', 'sample-cause', '', '', '2013-10-06 01:20:23', '2013-10-06 01:20:23', '', 0, 'http://localhost/wordpress1/postname/', 0, 'pfund_cause', '', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2013-10-06 00:54:14', '2013-10-06 00:54:14', '', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2013-10-06 00:54:14', '2013-10-06 00:54:14', '', 0, 'http://localhost/wordpress1/?post_type=pfund_campaign&#038;p=36', 0, 'pfund_campaign', '', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2013-10-06 01:26:01', '2013-10-06 01:26:01', '<strong>[pfund-edit]</strong>

<strong>[pfund-donate]</strong>

<strong>[pfund-comments]</strong>

<strong>[pfund-donate]</strong>

<strong>[pfund-edit]</strong>

<strong>[pfund-giver-list]</strong>

<strong>[pfund-progress-bar]</strong>', 'new campaign', '', 'publish', 'closed', 'closed', '', 'new-campaign', '', '', '2013-10-06 01:26:01', '2013-10-06 01:26:01', '', 0, 'http://localhost/wordpress1/?post_type=pfund_cause&#038;p=44', 0, 'pfund_cause', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2013-10-06 02:27:44', '2013-10-06 02:27:44', 'donate to hungerthon', 'Hungerthon', '', 'publish', 'open', 'open', '', 'hungerthon', '', '', '2013-10-06 02:52:06', '2013-10-06 02:52:06', '', 0, 'http://localhost/wordpress1/?post_type=download&#038;p=53', 0, 'download', '', 1) ; 
INSERT INTO `wp_posts` VALUES (68, 1, '2013-10-06 02:43:37', '2013-10-06 02:43:37', 'donate to hungerthon', 'Hungerthon', 'New Items added daily', 'inherit', 'closed', 'closed', '', '53-autosave-v1', '', '', '2013-10-06 02:43:37', '2013-10-06 02:43:37', '', 53, 'http://localhost/wordpress1/53-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2013-10-06 03:26:11', '2013-10-06 03:26:11', 'Hungerthon 10', 'Hungerthon 2013', 'Hungerthon 10', 'publish', 'closed', 'closed', '', 'hungerthon-2013', '', '', '2013-10-06 03:26:11', '2013-10-06 03:26:11', '', 0, 'http://localhost/wordpress1/?post_type=download&#038;p=74', 0, 'download', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2013-10-06 03:29:00', '0000-00-00 00:00:00', '', ' ', '', 'pending', 'closed', 'closed', '', '', '', '', '2013-10-06 03:29:00', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress1/?post_type=edd_payment&p=80', 0, 'edd_payment', '', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2013-10-06 03:32:04', '0000-00-00 00:00:00', '<p>Hungerthon 10</p>', 'Hungerthon 10', 'Hungerthon 10', 'pending', 'closed', 'closed', '', '', '', '', '2013-10-06 03:32:04', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress1/?post_type=download&p=81', 0, 'download', '', 0) ; 
INSERT INTO `wp_posts` VALUES (84, 1, '2013-10-07 02:32:13', '0000-00-00 00:00:00', '', ' ', '', 'pending', 'closed', 'closed', '', '', '', '', '2013-10-07 02:32:13', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress1/?post_type=edd_payment&p=84', 0, 'edd_payment', '', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2013-10-08 23:31:54', '2013-10-08 23:31:54', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-10-08 23:31:54', '2013-10-08 23:31:54', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2013-10-11 01:49:31', '0000-00-00 00:00:00', '', ' ', '', 'pending', 'closed', 'closed', '', '', '', '', '2013-10-11 01:49:31', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress1/?post_type=edd_payment&p=89', 0, 'edd_payment', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2013-10-17 09:32:35', '2013-10-17 09:32:35', '', 'Resume', '', 'publish', 'closed', 'closed', '', 'main', '', '', '2013-12-20 19:50:35', '2013-12-20 19:50:35', '', 0, 'http://localhost/wordpress1/?p=91', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2013-10-18 13:38:36', '0000-00-00 00:00:00', '', ' ', '', 'pending', 'closed', 'closed', '', '', '', '', '2013-10-18 13:38:36', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress1/?post_type=edd_payment&p=92', 0, 'edd_payment', '', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2013-10-23 20:45:35', '2013-10-23 20:45:35', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc', '', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-10-23 20:45:35', '2013-10-23 20:45:35', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2013-10-23 20:46:28', '2013-10-23 20:46:28', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-10-23 20:46:28', '2013-10-23 20:46:28', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2013-10-24 02:24:02', '2013-10-24 02:24:02', '', 'Portfolio', '', 'publish', 'closed', 'closed', '', 'slider', '', '', '2013-12-20 19:50:35', '2013-12-20 19:50:35', '', 0, 'http://localhost/wordpress1/?p=95', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2013-10-24 02:28:47', '0000-00-00 00:00:00', '', ' ', '', 'pending', 'closed', 'closed', '', '', '', '', '2013-10-24 02:28:47', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress1/?post_type=edd_payment&p=96', 0, 'edd_payment', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2013-10-24 03:32:26', '2013-10-24 03:32:26', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2013-12-20 19:50:35', '2013-12-20 19:50:35', '', 0, 'http://localhost/wordpress1/?p=97', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2013-10-24 08:12:38', '2013-10-24 08:12:38', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-10-24 08:12:38', '2013-10-24 08:12:38', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2013-10-25 17:10:00', '2013-10-25 17:10:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

[rev_slider slider1]

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-10-25 17:10:00', '2013-10-25 17:10:00', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2013-10-25 17:39:47', '2013-10-25 17:39:47', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

[rev_slider slider1]
<?php putRevSlider("slider1","homepage") ?>

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-10-25 17:39:47', '2013-10-25 17:39:47', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2013-10-25 17:40:41', '2013-10-25 17:40:41', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

[rev_slider slider1]


Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-10-25 17:40:41', '2013-10-25 17:40:41', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (113, 1, '2013-11-04 19:12:59', '2013-11-04 19:12:59', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc




Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-11-04 19:12:59', '2013-11-04 19:12:59', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2013-11-04 19:24:26', '2013-11-04 19:24:26', '', 'Goals', '', 'publish', 'closed', 'closed', '', 'green', '', '', '2013-12-20 19:50:35', '2013-12-20 19:50:35', '', 0, 'http://localhost/wordpress1/?p=114', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2013-11-04 22:20:35', '2013-11-04 22:20:35', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc




Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-11-04 22:20:35', '2013-11-04 22:20:35', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2013-11-08 00:10:44', '2013-11-08 00:10:44', '<p>[text* your-name placeholder "First and Last Name"] </p>

<p>[email* your-email placeholder "Email Address"] </p>

<p>[text your-subject placeholder "Subject"] </p>

<p>[textarea your-message placeholder "Please leave us a short message."] </p>

<p>[submit "Send"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Michael Wiss (http://localhost/wordpress1)
michael.wiss@gmail.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Michael Wiss (http://localhost/wordpress1)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.
Number format seems invalid.
This number is too small.
This number is too large.
Your answer is not correct.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2013-11-10 04:42:24', '2013-11-10 04:42:24', '', 0, 'http://localhost/wordpress1/?post_type=wpcf7_contact_form&#038;p=116', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2013-11-08 00:16:58', '2013-11-08 00:16:58', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc




[contact-form-7 id="116" title="Contact form 1"]

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-11-08 00:16:58', '2013-11-08 00:16:58', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (118, 1, '2013-11-08 14:03:23', '2013-11-08 14:03:23', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Michael Wiss (http://localhost/wordpress1)
michael.wiss@gmail.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Michael Wiss (http://localhost/wordpress1)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.
Number format seems invalid.
This number is too small.
This number is too large.
Your answer is not correct.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.', 'first', '', 'publish', 'closed', 'closed', '', 'first', '', '', '2013-11-08 18:32:33', '2013-11-08 18:32:33', '', 0, 'http://localhost/wordpress1/?post_type=wpcf7_contact_form&#038;p=118', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2013-11-18 22:19:01', '2013-11-18 22:19:01', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc






Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-11-18 22:19:01', '2013-11-18 22:19:01', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2013-11-18 22:32:39', '2013-11-18 22:32:39', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc', 'Home', '', 'inherit', 'closed', 'closed', '', '4-autosave-v1', '', '', '2013-11-18 22:32:39', '2013-11-18 22:32:39', '', 4, 'http://localhost/wordpress1/4-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (123, 1, '2013-11-18 22:33:08', '2013-11-18 22:33:08', '<div class="id">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc</div>', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-11-18 22:33:08', '2013-11-18 22:33:08', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (124, 1, '2013-11-18 22:38:59', '2013-11-18 22:38:59', '<div class="id clearfix" >Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc</div>', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-11-18 22:38:59', '2013-11-18 22:38:59', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (125, 1, '2013-11-18 22:40:44', '2013-11-18 22:40:44', '<div class="id clearfix" >Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

</div>', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-11-18 22:40:44', '2013-11-18 22:40:44', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (126, 1, '2013-11-18 22:46:31', '2013-11-18 22:46:31', '<div class="container">
<div class="row">
<div class="text" >Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat, orci ac laoreet cursus, dolor sem luctus lorem, eget consequat magna felis a magna. Aliquam scelerisque condimentum ante, eget facilisis tortor lobortis in. In interdum venenatis justo eget consequat. Morbi commodo rhoncus mi nec pharetra. Aliquam erat volutpat. Mauris non lorem eu dolor hendrerit dapibus. Mauris mollis nisl quis sapien posuere consectetur. Nullam in sapien at nisi ornare bibendum at ut lectus. Pellentesque ut magna mauris. Nam viverra suscipit ligula, sed accumsan enim placerat nec. Cras vitae metus vel dolor ultrices sagittis. Duis venenatis augue sed risus laoreet congue ac ac leo. Donec fermentum accumsan libero sit amet iaculis. Duis tristique dictum enim, ac fringilla risus bibendum in. Nunc ornare, quam sit amet ultricies gravida, tortor mi malesuada urna, quis commodo dui nibh in lacus. Nunc vel tortor mi. Pellentesque vel urna a arc

</div></div</div>', 'Home', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2013-11-18 22:46:31', '2013-11-18 22:46:31', '', 4, 'http://localhost/wordpress1/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (127, 1, '2013-11-19 15:47:36', '2013-11-19 15:47:36', '', 'About', '', 'publish', 'closed', 'closed', '', 'box-outer', '', '', '2013-12-20 19:50:35', '2013-12-20 19:50:35', '', 0, 'http://localhost/wordpress1/?p=127', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (128, 1, '2013-11-19 15:52:10', '2013-11-19 15:52:10', '', 'Social', '', 'publish', 'closed', 'closed', '', 'social', '', '', '2013-12-20 19:50:35', '2013-12-20 19:50:35', '', 0, 'http://localhost/wordpress1/?p=128', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (129, 1, '2013-11-19 15:59:56', '2013-11-19 15:59:56', '', 'HQ', '', 'publish', 'closed', 'closed', '', 'hq', '', '', '2013-12-20 19:50:35', '2013-12-20 19:50:35', '', 0, 'http://localhost/wordpress1/?p=129', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (134, 1, '2013-12-13 17:00:21', '2013-12-13 17:00:21', '', 'Cinema_Display_27in', '', 'inherit', 'closed', 'closed', '', 'cinema_display_27in', '', '', '2013-12-13 17:00:21', '2013-12-13 17:00:21', '', 0, 'http://localhost/wordpress1/media/Cinema_Display_27in.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (139, 1, '2013-12-13 19:30:47', '2013-12-13 19:30:47', '', 'iPhone_5', '', 'inherit', 'closed', 'closed', '', 'iphone_5', '', '', '2013-12-13 19:30:47', '2013-12-13 19:30:47', '', 0, 'http://localhost/wordpress1/media/iPhone_5.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (140, 1, '2013-12-13 19:35:45', '2013-12-13 19:35:45', '', 'iPhone_5a', '', 'inherit', 'closed', 'closed', '', 'iphone_5a', '', '', '2013-12-13 19:35:45', '2013-12-13 19:35:45', '', 0, 'http://localhost/wordpress1/media/iPhone_5a.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (141, 1, '2013-12-13 20:39:41', '2013-12-13 20:39:41', '', 'Michael Wiss_2013', '', 'inherit', 'closed', 'closed', '', 'michael-wiss_2013', '', '', '2013-12-13 20:39:41', '2013-12-13 20:39:41', '', 0, 'http://localhost/wordpress1/media/Michael-Wiss_2013.pdf', 0, 'attachment', 'application/pdf', 0) ; 
INSERT INTO `wp_posts` VALUES (145, 1, '2013-12-16 22:36:57', '2013-12-16 22:36:57', '', 'iPad', '', 'inherit', 'closed', 'closed', '', 'ipad', '', '', '2013-12-16 22:36:57', '2013-12-16 22:36:57', '', 0, 'http://localhost/wordpress1/media/iPad.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (147, 1, '2013-12-16 23:10:41', '2013-12-16 23:10:41', '', 'Untitled-1', '', 'inherit', 'closed', 'closed', '', 'untitled-1', '', '', '2013-12-16 23:10:41', '2013-12-16 23:10:41', '', 0, 'http://localhost/wordpress1/media/Untitled-1.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (149, 1, '2013-12-18 20:46:04', '2013-12-18 20:46:04', '', '121610-33', '', 'inherit', 'closed', 'closed', '', '121610-33', '', '', '2013-12-18 20:46:04', '2013-12-18 20:46:04', '', 0, 'http://localhost/wordpress1/media/121610-33.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (150, 1, '2013-12-18 20:47:25', '2013-12-18 20:47:25', '', 'Blurred-city-lights488', '', 'inherit', 'closed', 'closed', '', 'blurred-city-lights488', '', '', '2013-12-18 20:47:25', '2013-12-18 20:47:25', '', 0, 'http://localhost/wordpress1/media/Blurred-city-lights488.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (151, 1, '2013-12-18 20:47:52', '2013-12-18 20:47:52', '', 'gg_shadow00-82620132-1024x576', '', 'inherit', 'closed', 'closed', '', 'gg_shadow00-82620132-1024x576', '', '', '2013-12-18 20:47:52', '2013-12-18 20:47:52', '', 0, 'http://localhost/wordpress1/media/gg_shadow00-82620132-1024x576.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (152, 1, '2013-12-31 17:57:15', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2013-12-31 17:57:15', '0000-00-00 00:00:00', '', 0, 'http://localhost/wordpress1/?p=152', 0, 'post', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_css`
#

DROP TABLE IF EXISTS `wp_revslider_css`;


#
# Table structure of table `wp_revslider_css`
#

CREATE TABLE `wp_revslider_css` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `handle` text NOT NULL,
  `settings` text,
  `hover` text,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_revslider_css (53 records)
#
 
INSERT INTO `wp_revslider_css` VALUES (1, '.tp-caption.medium_grey', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700","font-size":"20px","line-height":"20px","font-family":"Arial","padding":"2px 4px","margin":"0px","border-width":"0px","border-style":"none","background-color":"#888","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (2, '.tp-caption.small_text', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700","font-size":"14px","line-height":"20px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (3, '.tp-caption.medium_text', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700","font-size":"20px","line-height":"20px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (4, '.tp-caption.large_text', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700","font-size":"40px","line-height":"40px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (5, '.tp-caption.very_large_text', '{"hover":"false"}', '{"font-size":"60px","line-height":"60px","font-weight":"700","font-family":"Arial","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","text-shadow":"rgba(0, 0, 0, 0.498039) 0px 2px 5px","margin":"0px","white-space":"nowrap","letter-spacing":"-2px","border-width":"0px","border-color":"rgb(255, 255, 255)","border-style":"none"}', '{"font-size":"60px","line-height":"60px","font-weight":"700","font-family":"Arial, Helvetica, sans-serif","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","text-shadow":"rgba(0, 0, 0, 0.498039) 0px 2px 5px","margin":"0px","white-space":"nowrap","letter-spacing":"-2px","border-width":"0px","border-color":"rgb(255, 255, 255)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (6, '.tp-caption.very_big_white', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"800","font-size":"60px","line-height":"60px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap","padding":"0px 4px","padding-top":"1px","background-color":"#000"}') ; 
INSERT INTO `wp_revslider_css` VALUES (7, '.tp-caption.very_big_black', NULL, NULL, '{"position":"absolute","color":"#000","text-shadow":"none","font-weight":"700","font-size":"60px","line-height":"60px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap","padding":"0px 4px","padding-top":"1px","background-color":"#fff"}') ; 
INSERT INTO `wp_revslider_css` VALUES (8, '.tp-caption.modern_medium_fat', NULL, NULL, '{"position":"absolute","color":"#000","text-shadow":"none","font-weight":"800","font-size":"24px","line-height":"20px","font-family":"\\"Open Sans\\", sans-serif","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (9, '.tp-caption.modern_medium_fat_white', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"800","font-size":"24px","line-height":"20px","font-family":"\\"Open Sans\\", sans-serif","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (10, '.tp-caption.modern_medium_light', NULL, NULL, '{"position":"absolute","color":"#000","text-shadow":"none","font-weight":"300","font-size":"24px","line-height":"20px","font-family":"\\"Open Sans\\", sans-serif","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (11, '.tp-caption.modern_big_bluebg', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"800","font-size":"30px","line-height":"36px","font-family":"\\"Open Sans\\", sans-serif","padding":"3px 10px","margin":"0px","border-width":"0px","border-style":"none","background-color":"#4e5b6c","letter-spacing":"0"}') ; 
INSERT INTO `wp_revslider_css` VALUES (12, '.tp-caption.modern_big_redbg', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"300","font-size":"30px","line-height":"36px","font-family":"\\"Open Sans\\", sans-serif","padding":"3px 10px","padding-top":"1px","margin":"0px","border-width":"0px","border-style":"none","background-color":"#de543e","letter-spacing":"0"}') ; 
INSERT INTO `wp_revslider_css` VALUES (13, '.tp-caption.modern_small_text_dark', NULL, NULL, '{"position":"absolute","color":"#555","text-shadow":"none","font-size":"14px","line-height":"22px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (14, '.tp-caption.boxshadow', NULL, NULL, '{"-moz-box-shadow":"0px 0px 20px rgba(0, 0, 0, 0.5)","-webkit-box-shadow":"0px 0px 20px rgba(0, 0, 0, 0.5)","box-shadow":"0px 0px 20px rgba(0, 0, 0, 0.5)"}') ; 
INSERT INTO `wp_revslider_css` VALUES (15, '.tp-caption.black', NULL, NULL, '{"color":"#000","text-shadow":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (16, '.tp-caption.noshadow', NULL, NULL, '{"text-shadow":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (17, '.tp-caption.thinheadline_dark', NULL, NULL, '{"position":"absolute","color":"rgba(0,0,0,0.85)","text-shadow":"none","font-weight":"300","font-size":"30px","line-height":"30px","font-family":"\\"Open Sans\\"","background-color":"transparent"}') ; 
INSERT INTO `wp_revslider_css` VALUES (18, '.tp-caption.thintext_dark', NULL, NULL, '{"position":"absolute","color":"rgba(0,0,0,0.85)","text-shadow":"none","font-weight":"300","font-size":"16px","line-height":"26px","font-family":"\\"Open Sans\\"","background-color":"transparent"}') ; 
INSERT INTO `wp_revslider_css` VALUES (19, '.tp-caption.largeblackbg', '{"hover":"false"}', '""', '{"font-size":"50px","line-height":"70px","font-weight":"300","font-family":"Lato","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(0, 0, 0)","padding":"0px 20px","text-shadow":"none","border-width":"0px","border-color":"rgb(255, 255, 255)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (20, '.tp-caption.largepinkbg', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"300","font-size":"50px","line-height":"70px","font-family":"\\"Open Sans\\"","background-color":"#db4360","padding":"0px 20px","-webkit-border-radius":"0px","-moz-border-radius":"0px","border-radius":"0px"}') ; 
INSERT INTO `wp_revslider_css` VALUES (21, '.tp-caption.largewhitebg', NULL, NULL, '{"position":"absolute","color":"#000","text-shadow":"none","font-weight":"300","font-size":"50px","line-height":"70px","font-family":"\\"Open Sans\\"","background-color":"#fff","padding":"0px 20px","-webkit-border-radius":"0px","-moz-border-radius":"0px","border-radius":"0px"}') ; 
INSERT INTO `wp_revslider_css` VALUES (22, '.tp-caption.largegreenbg', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"300","font-size":"50px","line-height":"70px","font-family":"\\"Open Sans\\"","background-color":"#67ae73","padding":"0px 20px","-webkit-border-radius":"0px","-moz-border-radius":"0px","border-radius":"0px"}') ; 
INSERT INTO `wp_revslider_css` VALUES (23, '.tp-caption.excerpt', NULL, NULL, '{"font-size":"36px","line-height":"36px","font-weight":"700","font-family":"Arial","color":"#ffffff","text-decoration":"none","background-color":"rgba(0, 0, 0, 1)","text-shadow":"none","margin":"0px","letter-spacing":"-1.5px","padding":"1px 4px 0px 4px","width":"150px","white-space":"normal !important","height":"auto","border-width":"0px","border-color":"rgb(255, 255, 255)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (24, '.tp-caption.large_bold_grey', NULL, NULL, '{"font-size":"60px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(102, 102, 102)","text-decoration":"none","background-color":"transparent","text-shadow":"none","margin":"0px","padding":"1px 4px 0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (25, '.tp-caption.medium_thin_grey', NULL, NULL, '{"font-size":"34px","line-height":"30px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(102, 102, 102)","text-decoration":"none","background-color":"transparent","padding":"1px 4px 0px","text-shadow":"none","margin":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (26, '.tp-caption.small_thin_grey', NULL, NULL, '{"font-size":"18px","line-height":"26px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(117, 117, 117)","text-decoration":"none","background-color":"transparent","padding":"1px 4px 0px","text-shadow":"none","margin":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (27, '.tp-caption.lightgrey_divider', NULL, NULL, '{"text-decoration":"none","background-color":"rgba(235, 235, 235, 1)","width":"370px","height":"3px","background-position":"initial initial","background-repeat":"initial initial","border-width":"0px","border-color":"rgb(34, 34, 34)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (28, '.tp-caption.large_bold_darkblue', NULL, NULL, '{"font-size":"58px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(52, 73, 94)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (29, '.tp-caption.medium_bg_darkblue', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(52, 73, 94)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (30, '.tp-caption.medium_bold_red', NULL, NULL, '{"font-size":"24px","line-height":"30px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(227, 58, 12)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (31, '.tp-caption.medium_light_red', NULL, NULL, '{"font-size":"21px","line-height":"26px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(227, 58, 12)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (32, '.tp-caption.medium_bg_red', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(227, 58, 12)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (33, '.tp-caption.medium_bold_orange', NULL, NULL, '{"font-size":"24px","line-height":"30px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(243, 156, 18)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (34, '.tp-caption.medium_bg_orange', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(243, 156, 18)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (35, '.tp-caption.grassfloor', NULL, NULL, '{"text-decoration":"none","background-color":"rgba(160, 179, 151, 1)","width":"4000px","height":"150px","border-width":"0px","border-color":"rgb(34, 34, 34)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (36, '.tp-caption.large_bold_white', NULL, NULL, '{"font-size":"58px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (37, '.tp-caption.medium_light_white', NULL, NULL, '{"font-size":"30px","line-height":"36px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (38, '.tp-caption.mediumlarge_light_white', NULL, NULL, '{"font-size":"34px","line-height":"40px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (39, '.tp-caption.mediumlarge_light_white_center', NULL, NULL, '{"font-size":"34px","line-height":"40px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"#ffffff","text-decoration":"none","background-color":"transparent","padding":"0px 0px 0px 0px","text-align":"center","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (40, '.tp-caption.medium_bg_asbestos', '{"hover":"false"}', '""', '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Arial Black\\", Gadget, sans-serif","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(127, 140, 141)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (41, '.tp-caption.medium_light_black', NULL, NULL, '{"font-size":"30px","line-height":"36px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (42, '.tp-caption.large_bold_black', NULL, NULL, '{"font-size":"58px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (43, '.tp-caption.mediumlarge_light_darkblue', NULL, NULL, '{"font-size":"34px","line-height":"40px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(52, 73, 94)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (44, '.tp-caption.small_light_white', NULL, NULL, '{"font-size":"17px","line-height":"28px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (45, '.tp-caption.roundedimage', NULL, NULL, '{"border-width":"0px","border-color":"rgb(34, 34, 34)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (46, '.tp-caption.large_bg_black', NULL, NULL, '{"font-size":"40px","line-height":"40px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(0, 0, 0)","padding":"10px 20px 15px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (47, '.tp-caption.mediumwhitebg', NULL, NULL, '{"font-size":"30px","line-height":"30px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"rgb(255, 255, 255)","padding":"5px 15px 10px","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (48, '.tp-caption.very_large_text1', '{"hover":"false"}', '""', '{"font-size":"100px","line-height":"1em","font-weight":"bold","font-family":"Lato, sans-serif","color":"rgb(214, 209, 191)","text-decoration":"none","background-color":"transparent","letter-spacing":"3px","text-shadow":"rgb(231, 231, 231) 0px 0px 0px, rgb(216, 216, 216) 1px 1px 0px, rgb(202, 202, 202) 2px 2px 0px, rgb(187, 187, 187) 3px 3px 0px, rgb(173, 173, 173) 4px 4px 0px, rgb(158, 158, 158) 5px 5px 0px, rgb(144, 144, 144) 6px 6px 0px, rgba(0, 0, 0, 0.6) 7px 7px 6px, rgba(0, 0, 0, 0.498039) 7px 7px 1px, rgba(0, 0, 0, 0.2) 0px 0px 6px","border-width":"0px","border-color":"rgb(255, 249, 214)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (49, '.tp-caption.very_large_text2', '{"hover":"false"}', '""', '{"font-size":"100px","line-height":"1em","font-weight":"bold","color":"#F52555","font":"bold 52px Helvetica, Arial, Sans-Serif","text-shadow":"1px 1px #FB5A48,                 2px 2px #FB5A48,                 3px 3px #FB5A48","-webkit-transition":"all 0.12s ease-out","-moz-transition":"all 0.12s ease-out","-ms-transition":"all 0.12s ease-out","-o-transition":"all 0.12s ease-out","background-color":"transparent","text-decoration":"none","font-family":"Arial, sans-serif","border-width":"0px","border-color":"rgb(237, 109, 83)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (50, '.tp-caption.very_large_text3', '{"hover":"false"}', '""', '{"font-size":"100px","line-height":"1em","font-weight":"bold","font-family":"Arial, sans-serif","color":"#5E3448","text-decoration":"none","background-color":"transparent","text-shadow":"rgb(11, 11, 11) 0px 0px 0px, rgb(24, 24, 24) 1px 1px 0px, rgb(43, 43, 43) 2px 2px 0px, rgb(187, 187, 187) 3px 3px 0px, rgb(173, 173, 173) 4px 4px 0px, rgb(158, 158, 158) 5px 5px 0px, rgb(144, 144, 144) 6px 6px 0px, rgba(0, 0, 0, 0.6) 7px 7px 6px, rgba(0, 0, 0, 0.498039) 7px 7px 1px, rgba(0, 0, 0, 0.2) 0px 0px 6px","border-width":"0px","border-color":"rgb(11, 24, 43)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (51, '.tp-caption.very_large_text4', '{"hover":"false"}', '""', '{"font-size":"100px","line-height":"1em","font-weight":"bold","color":"#5E3448","font":"bold 52px Helvetica, Arial, Sans-Serif","text-shadow":"1px 1px #A35A7D,                 2px 2px #A35A7D,                 3px 3px #A35A7D","-webkit-transition":"all 0.12s ease-out","-moz-transition":"all 0.12s ease-out","-ms-transition":"all 0.12s ease-out","-o-transition":"all 0.12s ease-out","background-color":"transparent","text-decoration":"none","border-width":"0px","border-color":"rgb(255, 255, 255)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (52, '.tp-caption.very_large_text1A', '{"hover":"false"}', '""', '{"font-size":"135px","line-height":"1em","font-weight":"bold","font-family":"Lato, sans-serif","color":"rgb(214, 209, 191)","text-decoration":"none","background-color":"transparent","letter-spacing":"3px","text-shadow":"rgb(231, 231, 231) 0px 0px 0px, rgb(216, 216, 216) 1px 1px 0px, rgb(202, 202, 202) 2px 2px 0px, rgb(187, 187, 187) 3px 3px 0px, rgb(173, 173, 173) 4px 4px 0px, rgb(158, 158, 158) 5px 5px 0px, rgb(144, 144, 144) 6px 6px 0px, rgba(0, 0, 0, 0.6) 7px 7px 6px, rgba(0, 0, 0, 0.498039) 7px 7px 1px, rgba(0, 0, 0, 0.2) 0px 0px 6px","border-width":"0px","border-color":"rgb(255, 249, 214)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (53, '.tp-caption.largegreenbg1', '{"hover":"false"}', '""', '{"font-size":"50px","line-height":"70px","font-weight":"300","font-family":"Montserrat","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(103, 174, 115)","padding":"0px 20px","text-shadow":"none","border-width":"0px","border-color":"rgb(255, 255, 255)","border-style":"none"}') ;
#
# End of data contents of table wp_revslider_css
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_layer_animations`
#

DROP TABLE IF EXISTS `wp_revslider_layer_animations`;


#
# Table structure of table `wp_revslider_layer_animations`
#

CREATE TABLE `wp_revslider_layer_animations` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `handle` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_revslider_layer_animations (2 records)
#
 
INSERT INTO `wp_revslider_layer_animations` VALUES (1, 'Skew From Short Right', '{"movex":"0","movey":"0","movez":"0","rotationx":"0","rotationy":"0","rotationz":"0","scalex":"100","scaley":"100","skewx":"0","skewy":"0","captionopacity":"0","captionperspective":"600","originx":"30","originy":"50"}') ; 
INSERT INTO `wp_revslider_layer_animations` VALUES (2, 'Skew From Short Right1', '{"movex":"310","movey":"0","movez":"0","rotationx":"0","rotationy":"0","rotationz":"0","scalex":"100","scaley":"100","skewx":"-43","skewy":"-89","captionopacity":"0","captionperspective":"-429","originx":"-90","originy":"-100"}') ;
#
# End of data contents of table wp_revslider_layer_animations
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_settings`
#

DROP TABLE IF EXISTS `wp_revslider_settings`;


#
# Table structure of table `wp_revslider_settings`
#

CREATE TABLE `wp_revslider_settings` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `general` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_revslider_settings (0 records)
#

#
# End of data contents of table wp_revslider_settings
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_sliders`
#

DROP TABLE IF EXISTS `wp_revslider_sliders`;


#
# Table structure of table `wp_revslider_sliders`
#

CREATE TABLE `wp_revslider_sliders` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `alias` tinytext,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_revslider_sliders (1 records)
#
 
INSERT INTO `wp_revslider_sliders` VALUES (2, 'slider1', 'slider1', '{"title":"slider1","alias":"slider1","shortcode":"[rev_slider slider1]","source_type":"gallery","post_types":"post","post_category":"category_1","post_sortby":"ID","posts_sort_direction":"DESC","max_slider_posts":"30","excerpt_limit":"55","slider_template_id":"","posts_list":"","slider_type":"fullwidth","fullscreen_offset_container":"","fullscreen_min_height":"","full_screen_align_force":"off","auto_height":"on","force_full_width":"off","width":"960","height":"620","responsitive_w1":"940","responsitive_sw1":"770","responsitive_w2":"780","responsitive_sw2":"500","responsitive_w3":"510","responsitive_sw3":"310","responsitive_w4":"0","responsitive_sw4":"0","responsitive_w5":"0","responsitive_sw5":"0","responsitive_w6":"0","responsitive_sw6":"0","delay":"3000","shuffle":"off","lazy_load":"on","use_wpml":"off","stop_slider":"off","stop_after_loops":0,"stop_at_slide":2,"load_googlefont":"true","google_font":["<link href=\\\\\'http:\\/\\/fonts.googleapis.com\\/css?family=PT+Sans+Narrow:400,700\\\\\' rel=\\\\\'stylesheet\\\\\' type=\\\\\'text\\/css\\\\\'>","<link href=\\\\\'http:\\/\\/fonts.googleapis.com\\/css?family=Lato\\\\\' rel=\\\\\'stylesheet\\\\\' type=\\\\\'text\\/css\\\\\'>","<link href=\\\\\'http:\\/\\/fonts.googleapis.com\\/css?family=Open+Sans\\\\\' rel=\\\\\'stylesheet\\\\\' type=\\\\\'text\\/css\\\\\'>","<link href=\\\\\'http:\\/\\/fonts.googleapis.com\\/css?family=Open+Sans:700,800\\\\\' rel=\\\\\'stylesheet\\\\\' type=\\\\\'text\\/css\\\\\'>","<link href=\\\\\'http:\\/\\/fonts.googleapis.com\\/css?family=Montserrat:400,700\\\\\' rel=\\\\\'stylesheet\\\\\' type=\\\\\'text\\/css\\\\\'>"],"position":"center","margin_top":0,"margin_bottom":0,"margin_left":0,"margin_right":0,"shadow_type":"0","show_timerbar":"hide","padding":0,"background_color":"#E9E9E9","background_dotted_overlay":"none","show_background_image":"true","background_image":"http:\\/\\/localhost\\/wordpress1\\/media\\/121610-33-e1387401833667.jpg","bg_fit":"cover","bg_repeat":"no-repeat","bg_position":"center top","touchenabled":"on","stop_on_hover":"off","navigaion_type":"none","navigation_arrows":"none","navigation_style":"round","navigaion_always_on":"false","hide_thumbs":200,"navigaion_align_hor":"center","navigaion_align_vert":"bottom","navigaion_offset_hor":"0","navigaion_offset_vert":20,"leftarrow_align_hor":"left","leftarrow_align_vert":"center","leftarrow_offset_hor":20,"leftarrow_offset_vert":0,"rightarrow_align_hor":"right","rightarrow_align_vert":"center","rightarrow_offset_hor":20,"rightarrow_offset_vert":0,"thumb_width":100,"thumb_height":50,"thumb_amount":5,"hide_slider_under":0,"hide_defined_layers_under":0,"hide_all_layers_under":0,"hide_arrows_on_mobile":"on","hide_bullets_on_mobile":"on","hide_thumbs_on_mobile":"on","hide_thumbs_under_resolution":0,"start_with_slide":"1","first_transition_type":"fade","first_transition_duration":300,"first_transition_slot_amount":7,"reset_transitions":"","reset_transition_duration":0,"0":"Execute settings on all slides","jquery_noconflict":"off","js_to_body":"true","output_type":"none","template":"false","1":{"1":"<link href=\\\\\'http:\\/\\/fonts.googleapis.com\\/css?family=Lato\\\\\' rel=\\\\\'stylesheet\\\\\' type=\\\\\'text\\/css\\\\\'>"},"2":{"2":"<link href=\\\\\'http:\\/\\/fonts.googleapis.com\\/css?family=Open+Sans\\\\\' rel=\\\\\'stylesheet\\\\\' type=\\\\\'text\\/css\\\\\'>"},"3":{"3":"<link href=\\\\\'http:\\/\\/fonts.googleapis.com\\/css?family=Open+Sans:700,800\\\\\' rel=\\\\\'stylesheet\\\\\' type=\\\\\'text\\/css\\\\\'>"},"4":{"4":"<link href=\\\\\'http:\\/\\/fonts.googleapis.com\\/css?family=Montserrat:400,700\\\\\' rel=\\\\\'stylesheet\\\\\' type=\\\\\'text\\/css\\\\\'>"}}') ;
#
# End of data contents of table wp_revslider_sliders
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_slides`
#

DROP TABLE IF EXISTS `wp_revslider_slides`;


#
# Table structure of table `wp_revslider_slides`
#

CREATE TABLE `wp_revslider_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `slide_order` int(11) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_revslider_slides (4 records)
#
 
INSERT INTO `wp_revslider_slides` VALUES (8, 2, 1, '{"background_type":"image","image":"http:\\/\\/localhost\\/wordpress1\\/media\\/121610-33-e1387401833667.jpg","image_id":"149","title":"Slide","state":"published","date_from":"","date_to":"","slide_transition":"zoomout","0":"Choose Image","slot_amount":7,"transition_rotation":0,"transition_duration":100,"delay":"","enable_link":"false","link_type":"regular","link":"","link_open_in":"same","slide_link":"nothing","link_pos":"front","slide_thumb":"","slide_bg_color":"#E7E7E7","slide_bg_external":"","bg_fit":"cover","bg_fit_x":"100","bg_fit_y":"100","bg_repeat":"no-repeat","bg_position":"center top","bg_position_x":"0","bg_position_y":"0","kenburn_effect":"off","kb_start_fit":"100","kb_end_fit":"100","bg_end_position":"center top","kb_duration":"9000","kb_easing":"Linear.easeNone","0":"Choose Image"}', '[{"text":"MODERN","type":"text","left":14,"top":105,"animation":"sft","easing":"easeInExpo","speed":300,"align_hor":"center","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"very_large_text1","time":300,"endtime":"","endspeed":300,"endanimation":"auto","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":462,"height":100,"serial":"0","endTimeFinal":8700,"endSpeedFinal":300,"realEndTime":9000,"timeLast":8700,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"WEB","type":"text","left":-9,"top":-59,"animation":"lfb","easing":"SlowMo.ease","speed":500,"align_hor":"center","align_vert":"middle","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"largeblackbg","time":800,"endtime":"","endspeed":300,"endanimation":"stl","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":104,"height":70,"serial":"1","endTimeFinal":8500,"endSpeedFinal":300,"realEndTime":9000,"timeLast":8200,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"DEVELOPMENT","type":"text","left":0,"top":0,"animation":"lfr","easing":"SlowMo.ease","speed":300,"align_hor":"center","align_vert":"middle","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"medium_bg_asbestos","time":1100,"endtime":"","endspeed":300,"endanimation":"auto","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":144,"height":20,"serial":"2","endTimeFinal":8700,"endSpeedFinal":300,"realEndTime":9000,"timeLast":7900,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"style":"","text":"Image 6","type":"image","image_url":"http:\\/\\/localhost\\/wordpress1\\/media\\/iPhone_5.png","left":56,"top":11,"animation":"customin-1","easing":"Power3.easeInOut","speed":300,"align_hor":"center","align_vert":"bottom","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","time":1400,"endtime":"","endspeed":300,"endanimation":"auto","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":300,"height":300,"serial":"3","endTimeFinal":8700,"endSpeedFinal":300,"realEndTime":9000,"timeLast":7600,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""}]') ; 
INSERT INTO `wp_revslider_slides` VALUES (9, 2, 3, '{"background_type":"image","image":"http:\\/\\/localhost\\/wordpress1\\/media\\/gg_shadow00-82620132-1024x576.png","image_id":"151","title":"Slide","state":"published","date_from":"","date_to":"","slide_transition":"random","0":"Choose Image","slot_amount":7,"transition_rotation":0,"transition_duration":300,"delay":"","enable_link":"false","link_type":"regular","link":"","link_open_in":"same","slide_link":"nothing","link_pos":"front","slide_thumb":"","slide_bg_color":"#E7E7E7","slide_bg_external":"","bg_fit":"cover","bg_fit_x":"100","bg_fit_y":"100","bg_repeat":"no-repeat","bg_position":"center top","bg_position_x":"0","bg_position_y":"0","kenburn_effect":"off","kb_start_fit":"100","kb_end_fit":"100","bg_end_position":"center top","kb_duration":"9000","kb_easing":"Linear.easeNone","0":"Choose Image"}', '[{"style":"","text":"Image 1","type":"image","image_url":"http:\\/\\/localhost\\/wordpress1\\/media\\/Cinema_Display_27in.png","left":320,"top":125,"animation":"skewfromleftshort","easing":"Power3.easeInOut","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","time":500,"endtime":"","endspeed":300,"endanimation":"ltt","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":700,"height":556,"serial":"0","endTimeFinal":8700,"endSpeedFinal":300,"realEndTime":9000,"timeLast":8500,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"style":"","text":"Image 3","type":"image","image_url":"http:\\/\\/localhost\\/wordpress1\\/media\\/iPhone_5.png","left":-74,"top":-17,"animation":"lfl","easing":"Sine.easeIn","speed":300,"align_hor":"right","align_vert":"bottom","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","time":800,"endtime":"","endspeed":300,"endanimation":"fadeout","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":300,"height":300,"serial":"1","endTimeFinal":8700,"endSpeedFinal":300,"realEndTime":9000,"timeLast":8200,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"Development","type":"text","left":20,"top":531,"animation":"tp-fade","easing":"SlowMo.ease","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"largeblackbg","time":1700,"endtime":"5500","endspeed":300,"endanimation":"fadeout","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":299,"height":70,"serial":"2","endTimeFinal":5500,"endSpeedFinal":300,"realEndTime":5800,"timeLast":4100,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"Agnostic","type":"text","left":19,"top":451,"animation":"tp-fade","easing":"SlowMo.ease","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"largeblackbg","time":1400,"endtime":"5000","endspeed":300,"endanimation":"fadeout","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":163,"height":40,"serial":"3","endTimeFinal":5000,"endSpeedFinal":300,"realEndTime":5300,"timeLast":3900,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"Device","type":"text","left":16,"top":366,"animation":"tp-fade","easing":"SlowMo.ease","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"largeblackbg","time":1100,"endtime":"4500","endspeed":300,"endanimation":"fadeout","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":127,"height":40,"serial":"4","endTimeFinal":4500,"endSpeedFinal":300,"realEndTime":4800,"timeLast":3700,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""}]') ; 
INSERT INTO `wp_revslider_slides` VALUES (10, 2, 4, '{"background_type":"image","image":"http:\\/\\/localhost\\/wordpress1\\/media\\/Blurred-city-lights488.jpg","image_id":"142","title":"Slide","state":"published","date_from":"","date_to":"","slide_transition":"parallaxtotop","0":"Choose Image","slot_amount":7,"transition_rotation":0,"transition_duration":300,"delay":"","enable_link":"false","link_type":"regular","link":"","link_open_in":"same","slide_link":"nothing","link_pos":"front","slide_thumb":"","slide_bg_color":"#E7E7E7","slide_bg_external":"","bg_fit":"cover","bg_fit_x":"100","bg_fit_y":"100","bg_repeat":"no-repeat","bg_position":"center top","bg_position_x":"0","bg_position_y":"0","kenburn_effect":"off","kb_start_fit":"100","kb_end_fit":"100","bg_end_position":"center top","kb_duration":"3000","kb_easing":"Linear.easeNone","0":"Choose Image"}', '[{"text":"Html5","type":"text","left":732,"top":175,"animation":"lfl","easing":"Power1.easeIn","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"very_big_black","time":500,"endtime":"2500","endspeed":300,"endanimation":"stt","endeasing":"Power1.easeOut","corner_left":"nothing","corner_right":"nothing","width":166,"height":60,"serial":"0","endTimeFinal":2500,"endSpeedFinal":300,"realEndTime":2800,"timeLast":2300,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"Css3","type":"text","left":755,"top":260,"animation":"lfl","easing":"Power1.easeIn","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"very_big_black","time":800,"endtime":"2000","endspeed":300,"endanimation":"stt","endeasing":"Power1.easeOut","corner_left":"nothing","corner_right":"nothing","width":142,"height":60,"serial":"1","endTimeFinal":2000,"endSpeedFinal":300,"realEndTime":2300,"timeLast":1500,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"Wordpress","type":"text","left":586,"top":353,"animation":"lfl","easing":"Power1.easeIn","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"very_big_black","time":1100,"endtime":"2100","endspeed":300,"endanimation":"stt","endeasing":"Power1.easeOut","corner_left":"nothing","corner_right":"nothing","width":313,"height":60,"serial":"2","endTimeFinal":2100,"endSpeedFinal":300,"realEndTime":2400,"timeLast":1300,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"Command Line","type":"text","left":21,"top":173,"animation":"lfr","easing":"Power3.easeInOut","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"largegreenbg1","time":1400,"endtime":"","endspeed":300,"endanimation":"fadeout","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":353,"height":70,"serial":3,"endTimeFinal":2700,"endSpeedFinal":300,"realEndTime":3000,"timeLast":1600,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""}]') ; 
INSERT INTO `wp_revslider_slides` VALUES (11, 2, 2, '{"background_type":"trans","title":"Slide","state":"published","date_from":"","date_to":"","slide_transition":"random","0":"Choose Image","slot_amount":7,"transition_rotation":0,"transition_duration":300,"delay":"","enable_link":"false","link_type":"regular","link":"","link_open_in":"same","slide_link":"nothing","link_pos":"front","slide_thumb":"","image_id":"","slide_bg_color":"#E7E7E7","slide_bg_external":"","bg_fit":"cover","bg_fit_x":"100","bg_fit_y":"100","bg_repeat":"no-repeat","bg_position":"center top","bg_position_x":"0","bg_position_y":"0","kenburn_effect":"off","kb_start_fit":"100","kb_end_fit":"100","bg_end_position":"center top","kb_duration":"9000","kb_easing":"Linear.easeNone","image":"","0":"Choose Image"}', '[{"type":"video","style":"","video_type":"youtube","video_width":960,"video_height":620,"video_data":{"id":"PIf-_2u-u5o","video_type":"youtube","title":"NEW YORK, TIMES SQUARE, AERIAL, NIGHT","author":"Footage File","link":"https:\\/\\/www.youtube.com\\/watch?v=PIf-_2u-u5o&feature=youtube_gdata","description":"030001, 2010, NEW YORK, TIMES SQUARE, AERIAL, NIGHT, HD., http:\\/\\/www.myfootage.com\\/details.php?gid=58&sgid=&pid=19344","desc_small":"030001, 2010, NEW YORK, TIMES SQUARE, AERIAL, NIGHT, HD., http:\\/\\/www.myfootage.com\\/details.php?gid=58&sgid=&pid=19344","thumb_small":{"url":"https:\\/\\/i1.ytimg.com\\/vi\\/PIf-_2u-u5o\\/default.jpg","width":120,"height":90},"thumb_medium":{"url":"https:\\/\\/i1.ytimg.com\\/vi\\/PIf-_2u-u5o\\/mqdefault.jpg","width":320,"height":180},"thumb_big":{"url":"https:\\/\\/i1.ytimg.com\\/vi\\/PIf-_2u-u5o\\/hqdefault.jpg","width":480,"height":360},"width":"320","height":"240","args":"?modestbranding=1;hd=1&wmode=opaque&controls=0&showinfo=0;rel=0;","previewimage":"","autoplay":true,"autoplayonlyfirsttime":false,"nextslide":false,"forcerewind":false,"fullwidth":true,"videoloop":false,"controls":true,"mute":false,"cover":false,"dotted":"none","ratio":"16:9"},"video_id":"PIf-_2u-u5o","video_title":"NEW YORK, TIMES SQUARE, AERIAL, NIGHT","video_image_url":"https:\\/\\/i1.ytimg.com\\/vi\\/PIf-_2u-u5o\\/mqdefault.jpg","video_args":"?modestbranding=1;hd=1&wmode=opaque&controls=0&showinfo=0;rel=0;","text":"Youtube: NEW YORK, TIMES SQUARE, AERIAL, NIGHT","left":0,"top":0,"align_hor":"left","align_vert":"top","animation":"tp-fade","easing":"Power3.easeInOut","speed":300,"hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","time":100,"endtime":"","endspeed":300,"endanimation":"auto","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":-1,"height":-1,"serial":"0","endTimeFinal":2700,"endSpeedFinal":300,"realEndTime":3000,"timeLast":2900,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"MICHAEL WISS","type":"text","left":-1,"top":0,"animation":"customin-1","easing":"Power3.easeInOut","speed":300,"align_hor":"center","align_vert":"middle","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"very_large_text1","time":150,"endtime":"","endspeed":300,"endanimation":"auto","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":751,"height":100,"serial":"1","endTimeFinal":8700,"endSpeedFinal":300,"realEndTime":9000,"timeLast":8600,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"NYC BASED","type":"text","left":129,"top":83,"animation":"skewfromleftshort","easing":"Power3.easeInOut","speed":300,"align_hor":"right","align_vert":"middle","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"very_large_text","time":1000,"endtime":"4500","endspeed":300,"endanimation":"skewtoleft","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":334,"height":60,"serial":"2","endTimeFinal":4500,"endSpeedFinal":300,"realEndTime":4800,"timeLast":3800,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""},{"text":"Web Developer","type":"text","left":433,"top":423,"animation":"sfb","easing":"Power3.easeInOut","speed":300,"align_hor":"left","align_vert":"top","hiddenunder":false,"resizeme":true,"link":"","link_open_in":"same","link_slide":"nothing","scrollunder_offset":"","style":"large_text","time":1500,"endtime":"5000","endspeed":300,"endanimation":"str","endeasing":"nothing","corner_left":"nothing","corner_right":"nothing","width":261,"height":40,"serial":"3","endTimeFinal":5000,"endSpeedFinal":300,"realEndTime":5300,"timeLast":3800,"alt":"","scaleX":"","scaleY":"","scaleProportional":false,"attrID":"","attrClasses":"","attrTitle":"","attrRel":""}]') ;
#
# End of data contents of table wp_revslider_slides
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (8 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (91, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (95, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (97, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (114, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (127, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (128, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (129, 2, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (7 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'nav_menu', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'edd_log_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'edd_log_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'edd_log_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 6, 'edd_log_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'edd_log_type', '', 0, 0) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (7 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Primary Navigation', 'primary-navigation', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'sale', 'sale', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'file_download', 'file_download', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'gateway_error', 'gateway_error', 0) ; 
INSERT INTO `wp_terms` VALUES (6, 'api_request', 'api_request', 0) ; 
INSERT INTO `wp_terms` VALUES (7, 'preapproval', 'preapproval', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (21 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'midnight') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '152') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'nav_menu_recently_edited', '2') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'wp_user-settings', 'editor=html&unfold=1&mfold=o&imgsize=full&libraryContent=browse') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'wp_user-settings-time', '1386953179') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'closedpostboxes_dashboard', 'a:1:{i:0;s:21:"dashboard_quick_press";}') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'metaboxhidden_dashboard', 'a:0:{}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'admin', '$P$Bv07MOc60vpkqumKde8r/ullLebYHr.', 'admin', 'michael.wiss@gmail.com', '', '2013-09-18 23:45:13', '', 0, 'admin') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza`
#

DROP TABLE IF EXISTS `wp_wpgmza`;


#
# Table structure of table `wp_wpgmza`
#

CREATE TABLE `wp_wpgmza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `address` varchar(700) NOT NULL,
  `description` mediumtext NOT NULL,
  `pic` varchar(700) NOT NULL,
  `link` varchar(700) NOT NULL,
  `icon` varchar(700) NOT NULL,
  `lat` varchar(100) NOT NULL,
  `lng` varchar(100) NOT NULL,
  `anim` varchar(3) NOT NULL,
  `title` varchar(700) NOT NULL,
  `infoopen` varchar(3) NOT NULL,
  `category` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpgmza (1 records)
#
 
INSERT INTO `wp_wpgmza` VALUES (2, 1, '4615 9th ave, brooklyn, ny 11220', '', '', '', '', '40.64153690000001', '-73.99941669999998', '', '', '', 0) ;
#
# End of data contents of table wp_wpgmza
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_categories`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza_categories`
#

DROP TABLE IF EXISTS `wp_wpgmza_categories`;


#
# Table structure of table `wp_wpgmza_categories`
#

CREATE TABLE `wp_wpgmza_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `category_icon` varchar(700) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpgmza_categories (0 records)
#

#
# End of data contents of table wp_wpgmza_categories
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_maps`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza_maps`
#

DROP TABLE IF EXISTS `wp_wpgmza_maps`;


#
# Table structure of table `wp_wpgmza_maps`
#

CREATE TABLE `wp_wpgmza_maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_title` varchar(50) NOT NULL,
  `map_width` varchar(6) NOT NULL,
  `map_height` varchar(6) NOT NULL,
  `map_start_lat` varchar(700) NOT NULL,
  `map_start_lng` varchar(700) NOT NULL,
  `map_start_location` varchar(700) NOT NULL,
  `map_start_zoom` int(10) NOT NULL,
  `default_marker` varchar(700) NOT NULL,
  `type` int(10) NOT NULL,
  `alignment` int(10) NOT NULL,
  `directions_enabled` int(10) NOT NULL,
  `styling_enabled` int(10) NOT NULL,
  `styling_json` mediumtext NOT NULL,
  `active` int(1) NOT NULL,
  `kml` varchar(700) NOT NULL,
  `bicycle` int(10) NOT NULL,
  `traffic` int(10) NOT NULL,
  `dbox` int(10) NOT NULL,
  `dbox_width` varchar(10) NOT NULL,
  `listmarkers` int(10) NOT NULL,
  `listmarkers_advanced` int(10) NOT NULL,
  `filterbycat` tinyint(1) NOT NULL,
  `ugm_enabled` int(10) NOT NULL,
  `fusion` varchar(100) NOT NULL,
  `map_width_type` varchar(3) NOT NULL,
  `map_height_type` varchar(3) NOT NULL,
  `mass_marker_support` int(10) NOT NULL,
  `ugm_access` int(10) NOT NULL,
  `order_markers_by` int(10) NOT NULL,
  `order_markers_choice` int(10) NOT NULL,
  `show_user_location` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_wpgmza_maps (1 records)
#
 
INSERT INTO `wp_wpgmza_maps` VALUES (1, 'My first map', '100', '500', '40.643560', '-74.009345', '40.643559981257546,-74.0093450268555', 13, '', 1, 2, 0, 0, '', 0, '', 0, 0, 0, '', 0, 0, 0, 0, '', '\\%', 'px', 1, 0, 0, 0, 0) ;
#
# End of data contents of table wp_wpgmza_maps
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_maps`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_polygon`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza_polygon`
#

DROP TABLE IF EXISTS `wp_wpgmza_polygon`;


#
# Table structure of table `wp_wpgmza_polygon`
#

CREATE TABLE `wp_wpgmza_polygon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `polydata` longtext NOT NULL,
  `linecolor` varchar(7) NOT NULL,
  `fillcolor` varchar(7) NOT NULL,
  `opacity` varchar(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpgmza_polygon (0 records)
#

#
# End of data contents of table wp_wpgmza_polygon
# --------------------------------------------------------

# WordPress : http://localhost/wordpress1 MySQL database backup
#
# Generated: Tuesday 31. December 2013 18:01 UTC
# Hostname: localhost
# Database: `wordpress1`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_ai_contact`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_cntctfrm_field`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_field_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_fields`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_forms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_styles`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_customcontactforms_user_data`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_categories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_maps`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_polygon`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_wpgmza_polylines`
# --------------------------------------------------------


#
# Delete any existing table `wp_wpgmza_polylines`
#

DROP TABLE IF EXISTS `wp_wpgmza_polylines`;


#
# Table structure of table `wp_wpgmza_polylines`
#

CREATE TABLE `wp_wpgmza_polylines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `polydata` longtext NOT NULL,
  `linecolor` varchar(7) NOT NULL,
  `linethickness` varchar(3) NOT NULL,
  `opacity` varchar(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_wpgmza_polylines (0 records)
#

#
# End of data contents of table wp_wpgmza_polylines
# --------------------------------------------------------

